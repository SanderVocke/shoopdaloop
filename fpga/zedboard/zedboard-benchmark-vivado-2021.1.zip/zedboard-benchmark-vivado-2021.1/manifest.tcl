set bench_output [file dirname [file normalize [info script]]]
set bench_warmup 72
set bench_fabric_mhz 100.0
set bench_statistics {status completed_quanta measured_quanta total_cycles last_cycles min_cycles max_cycles wall_cycles read_bursts write_bursts read_bytes write_bytes address_stall_cycles response_stall_cycles output_words output_digest}
