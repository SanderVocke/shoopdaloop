ZedBoard autonomous 64-loop benchmark, Q=32
Vivado 2021.1 SW Build 3247384, IP Build 3246043; XC7Z020-CLG484-1.

This build generated its bitstream with zero DRC errors and is fully routed.
100 MHz setup timing remains unclosed: WNS -0.425 ns. No physical board testing
has been performed. This package records that build; it is not timing qualified.

Set the ZedBoard to JTAG boot. From this extracted directory, start a local
hardware server in another terminal:

    hw_server -s TCP:127.0.0.1:3121

Initialize the PS clocks, DDR and HP0 and program the PL (both CPUs stay halted):

    xsdb load.tcl .

Run 1000 quanta, including 72 warmup quanta; save the snapshot to results.json:

    vivado -mode batch -source control.tcl -tclargs . measure 1000 72 0 10000000

The packaged manifest is portable and contains the values used by control.tcl.
The hardware workload is embedded in bench.bit. There is no audio correctness
scoreboard. See the repository fpga/zedboard/README.md for controls and counters.

Source branch: tmp/zedboard-fpga-timing
Repository: https://github.com/SanderVocke/shoopdaloop
Artifact hashes and pinned tool/catalog sources: build-provenance.json.
