"""Retain interrupted optional benchmark evidence without claiming completed results."""
import argparse,hashlib,io,json,tarfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--directory',type=Path,required=True);p.add_argument('--runner-log',type=Path,required=True);p.add_argument('--label',required=True);a=p.parse_args()
out=Path('docs/fpga/measurements/area-experiments');archive=out/(a.label+'-raw.tar.gz');assert not archive.exists()
manifest=json.loads((a.directory/'manifest.json').read_text());assert manifest['complete'] is False
cancellation=json.loads((a.directory/'cancellation.json').read_text());assert cancellation['completed'] is False
members={'replay/archive-cancelled-benchmark.py':Path(__file__).read_bytes(),'logs/runner.log':a.runner_log.read_bytes()}
for path in sorted(a.directory.rglob('*')):
 if path.is_file() and path.suffix in ['.json','.log']:members['partial/'+str(path.relative_to(a.directory))]=path.read_bytes()
assert not (a.directory/'mixed-on-delay7.json').exists()
with tarfile.open(archive,'x:gz') as t:
 for n,b in sorted(members.items()):
  info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;t.addfile(info,io.BytesIO(b))
hashes={n:hashlib.sha256(b).hexdigest() for n,b in members.items()}
with tarfile.open(archive) as t:assert hashes=={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t.getmembers()}
(out/(a.label+'-retention.json')).write_text(json.dumps(dict(archive=archive.name,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members_sha256=hashes,scope='Deliberate cancellation of optional long run after complete route rejects candidate; no complete extended result or coverage claim',reason=cancellation['reason']),indent=2)+'\n')
print('Retained cancelled run without completed-result claim')
