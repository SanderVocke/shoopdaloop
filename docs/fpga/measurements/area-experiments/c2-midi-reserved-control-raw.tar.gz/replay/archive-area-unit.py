"""Retain a standalone operation/protocol trial with its exact HDL and fixture."""
import argparse,hashlib,io,json,re,statistics,subprocess,tarfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--result',type=Path,required=True);p.add_argument('--source-root',type=Path,required=True);p.add_argument('--label',required=True);p.add_argument('--fixture-revision',required=True);p.add_argument('--fixture',action='append',default=[]);p.add_argument('--log',action='append',type=Path,default=[]);a=p.parse_args()
assert re.fullmatch(r'[a-zA-Z0-9_-]+',a.label)
out=Path('/workspace/shoopdaloop/docs/fpga/measurements/area-experiments'); paths={suffix:out/(a.label+suffix) for suffix in ['-summary.json','-raw.tar.gz','-retention.json']}; assert not any(p.exists() for p in paths.values())
data=json.loads(a.result.read_bytes());models=data['provenance']['models'];assert models
members={'samples/'+a.result.name:a.result.read_bytes(),'replay/archive-area-unit.py':Path(__file__).read_bytes()}
for model in models:
 for path,expected in model['sources_sha256'].items():
  raw=(a.source_root/path).read_bytes();assert hashlib.sha256(raw).hexdigest()==expected,path
  key='source/'+path;assert key not in members or members[key]==raw;members[key]=raw
for path in a.fixture:members['fixture/'+path]=subprocess.check_output(['git','show',a.fixture_revision+':'+path])
for i,path in enumerate(a.log):members[f'logs/{i}-{path.name}']=path.read_bytes()
summary={key:value for key,value in data.items() if key not in ['measurements','memory','provenance']};summary.update(label=a.label,fixture_revision=a.fixture_revision,models=models,retention=paths['-retention.json'].name)
if 'measurements' in data:
 summary['populations']={}
 for kind in dict.fromkeys(r['kind'] for r in data['measurements']):
  rows=[r for r in data['measurements'] if r['kind']==kind];cycles=[r['admission_through_cleanup_cycles'] for r in rows]
  summary['populations'][kind]={'count':len(rows),'min':min(cycles),'median':statistics.median(cycles),'max':max(cycles),**{key:sum(r[key] for r in rows) for key in ['axi_reads','axi_writes']}}
with tarfile.open(paths['-raw.tar.gz'],'x:gz') as tar:
 for name,raw in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;tar.addfile(info,io.BytesIO(raw))
hashes={name:hashlib.sha256(raw).hexdigest() for name,raw in sorted(members.items())}
with tarfile.open(paths['-raw.tar.gz']) as tar:assert hashes=={m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in tar.getmembers()}
paths['-retention.json'].write_text(json.dumps({'archive':paths['-raw.tar.gz'].name,'archive_sha256':hashlib.sha256(paths['-raw.tar.gz'].read_bytes()).hexdigest(),'members_sha256':hashes},indent=2)+'\n');paths['-summary.json'].write_text(json.dumps(summary,indent=2)+'\n');print(paths['-summary.json'])
