set_param general.maxThreads 2
foreach label {c1 leaf} {
    open_checkpoint source/${label}.dcp
    set counts [dict create]
    foreach cell [get_cells -hierarchical -filter {REF_NAME == CARRY4}] {
        set prefix [join [lrange [split [get_property NAME $cell] /] 0 end-1] /]
        dict incr counts $prefix
    }
    set out [open ${label}_carry.rpt w]
    puts $out "hierarchy\tCARRY4"
    foreach prefix [lsort [dict keys $counts]] {
        puts $out "$prefix\t[dict get $counts $prefix]"
    }
    close $out
    close_design
}
exit 0
