"""Retain exact unit samples, source inputs, fixture and derived cycle populations."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import statistics
import subprocess
import tarfile

p = argparse.ArgumentParser()
p.add_argument('--results', type=Path, required=True)
p.add_argument('--source-root', type=Path, required=True)
p.add_argument('--label', required=True)
p.add_argument('--fixture-revision', default='9aaf6f9e')
args = p.parse_args()
out = Path('/workspace/shoopdaloop/docs/fpga/measurements/area-experiments')
archive = out/f'{args.label}-raw.tar.gz'
summary_path = out/f'{args.label}-summary.json'
retention_path = out/f'{args.label}-retention.json'
assert not any(x.exists() for x in [archive, summary_path, retention_path])
members = {'replay/archive-translation-unit.py': Path(__file__).read_bytes()}
summary = {'label': args.label, 'fixture_revision': args.fixture_revision, 'cases': {}}
for width in [32, 64]:
    result = args.results/f'axi{width}.json'
    data = result.read_bytes()
    d = json.loads(data)
    assert d['axi_data_width'] == width and len(d['measurements']) == 2348
    members[f'samples/axi{width}.json'] = data
    populations = {}
    for kind in dict.fromkeys(row['kind'] for row in d['measurements']):
        rows = [r for r in d['measurements'] if r['kind'] == kind]
        cycles = [r['cycles'] for r in rows]
        populations[kind] = {'count': len(rows), 'min': min(cycles),
            'median': statistics.median(cycles), 'max': max(cycles),
            **{key: sum(r[key] for r in rows) for key in ['hits', 'misses', 'fills', 'writebacks']}}
    summary['cases'][str(width)] = {'scope': d['scope'], 'validation': d['validation'],
        'parameters': d['provenance']['models'][0]['parameters'], 'populations': populations}
    for model in d['provenance']['models']:
        for path, digest in model['sources_sha256'].items():
            raw = (args.source_root/path).read_bytes()
            assert hashlib.sha256(raw).hexdigest() == digest, path
            name = 'source/'+path
            assert name not in members or members[name] == raw
            members[name] = raw
for file in ['src/rust/rt_fpga_testbench/src/suites/metadata.rs',
             'src/rust/rt_fpga_testbench/examples/metadata_translation_area.rs']:
    members['fixture/'+file] = subprocess.check_output(['git', 'show', f'{args.fixture_revision}:{file}'])
with tarfile.open(archive, 'x:gz') as tar:
    for name, raw in sorted(members.items()):
        info = tarfile.TarInfo(name); info.size = len(raw); info.mode = 0o644
        tar.addfile(info, io.BytesIO(raw))
hashes = {name: hashlib.sha256(raw).hexdigest() for name, raw in sorted(members.items())}
with tarfile.open(archive) as tar:
    assert hashes == {m.name: hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in tar.getmembers()}
retention_path.write_text(json.dumps({'archive': archive.name,
    'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'members_sha256': hashes}, indent=2)+'\n')
summary['retention'] = retention_path.name
summary_path.write_text(json.dumps(summary, indent=2)+'\n')
print(summary_path)
