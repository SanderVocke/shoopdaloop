"""Prepare a sibling that uses accepted packet fields instead of a fourth copy."""
import argparse
from pathlib import Path
import subprocess

p = argparse.ArgumentParser()
p.add_argument('--base', required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
s = subprocess.check_output(['git', 'show', a.base+':fpga/midi/rtl/midi_store.sv'], text=True)

def change(old, new):
    global s
    assert s.count(old) == 1, old
    s = s.replace(old, new)

change('payload [0:3];', '''payload [0:2];
    wire [31:0] append_payload_word = record_word[1:0]==3
        ? {6'b0,length,packet} : payload[record_word[1:0]];''')
change("payload[3]<={6'b0,length,packet};", '')
change('record_address,payload[record_word[1:0]],APPEND_PAYLOAD_NEXT)', 'record_address,append_payload_word,APPEND_PAYLOAD_NEXT)')
change('                payload[record_word[1:0]]<=data_word;', '                if (record_word[1:0]!=3) payload[record_word[1:0]]<=data_word;')
assert not a.output.exists()
a.output.parent.mkdir(parents=True, exist_ok=True)
a.output.write_text(s)
print(a.output)
