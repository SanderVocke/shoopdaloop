"""Verify actual payload FFs in frozen checkpoints, cross-checked with Vivado."""
from pathlib import Path
import collections,csv,hashlib,io,json,re,tarfile,zipfile
root=Path('/workspace/shoopdaloop');work=root/'work/area-experiments';out=root/'docs/fpga/measurements/area-experiments'
label='s5-payload-lifetime-cells';members={'replay/inspect-payload-edif.py':Path(__file__).read_bytes()};results={}
instance=re.compile(r'^\s*\(instance (?:(?:\(rename ([^\s()]+) "([^"]*)"\))|([^\s()]+)) \(viewref netlist \(cellref ([^\s()]+)',re.M)
for role,name in [('control','s5-cold-descriptor'),('candidate','s5-payload-lifetime')]:
 dcp=work/(name+'-opt/post_opt.dcp')
 with dcp.open('rb') as f:dcp_sha=hashlib.file_digest(f,'sha256').hexdigest()
 with zipfile.ZipFile(dcp) as z:raw=z.read('session_context.edf')
 s=raw.decode();cells=list(re.finditer(r'^   \(cell ([^\s()]+)',s,re.M));matches=[i for i,m in enumerate(cells) if m.group(1)=='midi_store'];assert len(matches)==1
 i=matches[0];assert i+1<len(cells);cell=s[cells[i].start():cells[i+1].start()]
 rows=[(m.group(2) or m.group(3) or m.group(1),m.group(4)) for m in instance.finditer(cell)]
 assert len(rows)==len(set(n for n,p in rows))
 ff={n:p for n,p in rows if p.startswith('FD')}
 payload={n:p for n,p in ff.items() if re.fullmatch(r'payload_reg\[\d+\]\[\d+\]',n)}
 groups=collections.Counter(re.match(r'payload_reg\[(\d+)\]',n)[1] for n in payload)
 assert dict(groups)==({'0':32,'1':32,'2':32,'3':32} if role=='control' else {'0':32,'1':32,'2':32})
 if role=='control':
  path=work/'setup/s5-descriptor-cell-query/candidate-primitives.csv';data=path.read_bytes();members['vivado/C6-candidate-primitives.csv']=data
  refs={r['name'].split('/midi/content/',1)[1]:r['primitive'] for r in csv.DictReader(io.StringIO(data.decode())) if r['primitive'].startswith('FD') and '/midi/content/' in r['name'] and '/' not in r['name'].split('/midi/content/',1)[1]}
  assert ff==refs,'EDIF FF population must exactly match completed Vivado query'
 members['netlists/'+role+'-midi_store.edf']=cell.encode()
 buffer=io.StringIO();w=csv.writer(buffer);w.writerow(['name','primitive']);w.writerows(sorted(rows));members['cells/'+role+'.csv']=buffer.getvalue().encode()
 results[role]=dict(dcp=str(dcp),dcp_sha256=dcp_sha,full_edif_sha256=hashlib.sha256(raw).hexdigest(),midi_store_cell_sha256=hashlib.sha256(cell.encode()).hexdigest(),direct_instances=len(rows),direct_ff=len(ff),payload_ff=len(payload),payload_words=dict(groups))
summary=dict(control='C6 RTL7eba4933',candidate='bbfaa8ad100f0f0b8c833a188246ea74f2beeea1',method='Parse frozen post_optDCP EDIF midi_store cell; validate every control directFD instance name/type exactly against completed Vivado2021.1 checkpointquery, not just totalcount',results=results,payload_bank_ff_delta=results['candidate']['payload_ff']-results['control']['payload_ff'],connected_opt_ff_delta=-37,attribution='Payload bank128to96FF accounts for32of37connectedFF reduction. Remaining5FF are outside this payload bank; do not attribute all37 to the removed copy.',retention=label+'-retention.json')
for name in ['query.tcl','console.log','run.log','control-primitives.csv']:
 p=work/'setup/s5-payload-cell-query'/name
 if p.exists():members['interrupted-optional-vivado-query/'+name]=p.read_bytes()
summary['interrupted_optional_query']='Stopped137 to restoreDocker vfs diskheadroom while mainroute continued. Partialquery is not qualifyingevidence; exact completed controlquery + frozen EDIF inspection above provide verification.'
members['replay/cache-cleanup-19.json']=(work/'setup/cache-cleanup-19.json').read_bytes()
archive=out/(label+'-raw.tar.gz');assert not archive.exists()
with tarfile.open(archive,'x:gz') as t:
 for n,b in sorted(members.items()):
  info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;t.addfile(info,io.BytesIO(b))
hashes={n:hashlib.sha256(b).hexdigest() for n,b in members.items()}
with tarfile.open(archive) as t:assert hashes=={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t.getmembers()}
(out/(label+'-retention.json')).write_text(json.dumps(dict(archive=archive.name,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members_sha256=hashes),indent=2)+'\n')
(out/(label+'-summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
print('Verified actual payload bank128 ->96FF; all controlFD instances exactly match Vivado')
