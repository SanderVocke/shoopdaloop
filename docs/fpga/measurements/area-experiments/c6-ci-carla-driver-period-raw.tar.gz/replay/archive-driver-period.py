from pathlib import Path
import hashlib,io,json,tarfile
repo=Path('/workspace/area-base-integration')
setup=Path('/workspace/shoopdaloop/work/area-experiments/setup')
out=repo/'docs/fpga/measurements/area-experiments'
label='c6-ci-carla-driver-period'
members={}
for name in ['integration-c5-driver-period-original.log','integration-c5-driver-period-original-quiet.log','integration-c6-driver-period-supported.log','integration-c6-driver-period-supported-2.log','integration-c6-driver-period-supported-quiet.log','integration-c6-driver-period-build.log','integration-c6-driver-period-build-2.log','integration-c6-driver-period-build-lib.log']:
 members['logs/'+name]=(setup/name).read_bytes()
for name in ['src/rust/shoop_host/tests/jack.rs','src/rust/shoop_host/tests/support/shutdown.rs','src/rust/shoop_rt_host_native/src/remote_carla.rs']:
 members['source/'+name]=(repo/name).read_bytes()
members['replay/archive-driver-period.py']=Path(__file__).read_bytes()
archive=out/(label+'-raw.tar.gz');assert not archive.exists()
with tarfile.open(archive,'x:gz') as t:
 for name,data in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;t.addfile(info,io.BytesIO(data))
hashes={n:hashlib.sha256(b).hexdigest() for n,b in members.items()}
with tarfile.open(archive) as t:
 assert hashes=={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t.getmembers()}
(out/(label+'-retention.json')).write_text(json.dumps(dict(archive=archive.name,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members_sha256=hashes),indent=2)+'\n')
summary=dict(scope='New-base native integration only; no FPGA HDL/source change',integration_parent='84b3f4cf385cc72b785b8de049b45c50ed9d2ad1',runtime='Verified pinned430-fileCarla artifact14773879496; SHOOP_REQUIRE_CARLA_TESTS=1; identity in c4-ci-carla-on-demand',contract='Native Carla provider partitions large driver periods into blocks capped at8192. Driver96kHz/16384frames is supported; expected buffering24576frames.',checks=['Both InProcess/Socket and Subprocess/SharedMemory with actual16-channel track/bus Carla XML and48k-to96k retiming','Preserve original playback amplitude tolerance0.02dB; verify final supported period confirms/completes without fatal/failed switch','Additional fresh capture uses uniqueTransferId4. All32stored audio channels match exactly, including frames2048, MIDIframes/bytes and three processor checkpoints','Keep original readiness timeout and cleanup deadline unchanged'],result='1passed;7filtered;104.52sec, required actual runtime; no skip',earlier_attempts=['Original quiet test reproduces same obsolete Refused expectation asCI: actualConfirmed','First edit reused transfer3; identity guard rejected, corrected to4','Next run passed new media assertions but exceeded unchanged cleanup deadline while FPGA compilation overlapped; exact code quiet retry passed. Contention remains a qualification limitation, not proof of universal cleanup bound.'],validation=['cargo fmt --all','check_shoop_test_usage.py passed','RUSTFLAGS=-Dwarnings cargo build --locked -p shoop_host --lib passed','Full binary build ran out of disk/linkerBusError. Logs retained; caches reclaimed. Full workspace/CI qualification remains Stage11.'],retention=label+'-retention.json',pending=['Full selected/integration-headCI qualification','Broader driver failure/rollback behavior remains covered separately; this now-supported request no longer claims to exercise rollback'])
(out/(label+'-summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
p=out/'c3-ci-integration.md'
p.write_text(p.read_text()+'''\nThe driver-period fixture now checks the supported 96 kHz / 16,384-frame\ntransition. The provider caps each Carla batch at 8,192 frames and advertises\n24,576 frames of buffering. Both hosting modes retain their original playback\ntolerance, and an additional fresh archive verifies every stored audio sample,\nMIDI frame/byte and processor checkpoint. The unchanged test deadlines pass in\na quiet run (104.52 seconds). One earlier run exceeded cleanup while FPGA\ncompilation overlapped; its failure is retained alongside the pass. Formatting,\ntest policy and warning-denying host-library build pass. A broader binary build\nexhausted disk; its logs and cache recovery remain recorded. See\n`c6-ci-carla-driver-period-*`. Full selected-head integration CI is still pending.\n''')
print('Archived verified driver-period result')
