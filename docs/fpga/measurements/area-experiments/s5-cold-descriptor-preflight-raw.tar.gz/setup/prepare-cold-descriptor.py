"""Prepare a separate, not yet selected MIDI descriptor staging experiment."""
import argparse
import re
import subprocess
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--base', required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
base = a.base
path = 'fpga/midi/rtl/midi_store.sv'
source = subprocess.check_output(['git', 'show', base+':'+path], text=True)

def replace(old, new):
    global source
    assert source.count(old) == 1, old
    source = source.replace(old, new)

replace('    reg [31:0] desc [0:15];', '''    reg [31:0] desc [0:12];
    (* ram_style = "distributed" *) reg [31:0] descriptor_cold [0:3];
    reg [31:0] descriptor_cold_data;
    reg [2:0] descriptor_cold_valid;
    wire descriptor_is_cold = cursor[3:0]==10 || cursor[3:0]==11 || cursor[3:0]==14;
    wire [1:0] descriptor_cold_write_index = cursor[3:0]==10 ? 0 : cursor[3:0]==11 ? 1 : 2;
    wire [1:0] descriptor_cold_read_index = cursor[3:0]==9 ? 0 : cursor[3:0]==10 ? 1 : 2;
    wire [1:0] descriptor_cold_address = phase==LOADED_VIEW
        ? descriptor_cold_write_index : descriptor_cold_read_index;
    wire [3:0] descriptor_hot_index = cursor[3:0]<10 ? cursor[3:0]
        : cursor[3:0]==12 ? 10 : cursor[3:0]==13 ? 11 : 12;
    wire [31:0] descriptor_word = descriptor_is_cold
        ? (descriptor_cold_valid[descriptor_cold_write_index] ? descriptor_cold_data : 32'b0)
        : desc[descriptor_hot_index];
    always @(posedge clk) begin
        if (!reset && phase==LOADED_VIEW && descriptor_is_cold)
            descriptor_cold[descriptor_cold_address] <= data_word;
        if (phase==SAVED_VIEW && (cursor==9 || cursor==10 || cursor==13))
            descriptor_cold_data <= descriptor_cold[descriptor_cold_address];
    end''')
replace('                desc[cursor[3:0]]<=data_word;', '''                if (descriptor_is_cold) descriptor_cold_valid[descriptor_cold_write_index]<=1;
                else desc[descriptor_hot_index]<=data_word;''')
replace('arena_base,desc[cursor[3:0]],SAVED_VIEW)', 'arena_base,descriptor_word,SAVED_VIEW)')
replace('            phase<=IDLE;formatted<=0;', '            descriptor_cold_valid<=0;\n            phase<=IDLE;formatted<=0;')
replace('desc[9]<=frames[63:32];desc[10]<=0;desc[11]<=0;', 'desc[9]<=frames[63:32];descriptor_cold_valid<=0;')
replace(' : 32\'(MAX_EVENTS);desc[14]<=0;desc[15]<=0;', ' : 32\'(MAX_EVENTS);desc[15]<=0;')
indices = {12: 10, 13: 11, 15: 12}
source = re.sub(r'desc\[(\d+)\]', lambda m: 'desc['+str(indices.get(int(m[1]), int(m[1])))+']', source)
out = a.output
out.parent.mkdir(parents=True, exist_ok=True)
assert not out.exists()
out.write_text(source)
print(out)
