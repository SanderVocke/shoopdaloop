"""Create an immutable simulation source and link the existing DDR simulator."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

p = argparse.ArgumentParser()
p.add_argument('--revision', required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
root = Path('/workspace/shoopdaloop')
revision = subprocess.check_output(['git', 'rev-parse', a.revision+'^{commit}'], text=True).strip()
out = a.output.resolve()
assert out.is_relative_to(root/'work/area-experiments') and not out.exists()
archive = subprocess.check_output(['git', 'archive', revision, 'fpga'])
out.mkdir(parents=True)
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
    tar.extractall(out, filter='data')
hashes = {str(path.relative_to(out)): hashlib.sha256(path.read_bytes()).hexdigest()
    for path in sorted((out/'fpga').rglob('*')) if path.suffix in ['.sv', '.svh']}
assert len(hashes) >= 38
(out/'snapshot-provenance.json').write_text(json.dumps(dict(revision=revision, sha256=hashes), indent=2)+'\n')
runtime = root/'work/dramsim3'
libraries = [runtime/'build/libshoop_dram.so', runtime/'build/libdramsim3.so']
assert all(path.is_file() for path in libraries)
(out/'work').mkdir()
(out/'work/dramsim3').symlink_to(runtime, target_is_directory=True)
config = out/'fpga/axi_memory/configs/zynq7010-ddr3-1066-x16.ini'
(out/'dramsim3-runtime-link.json').write_text(json.dumps(dict(
    link=str(out/'work/dramsim3'), target=str(runtime),
    libraries_sha256={str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in libraries},
    config=str(config.relative_to(out)), config_sha256=hashlib.sha256(config.read_bytes()).hexdigest(),
    scope='Existing pinned DRAMsim3 runtime and unchanged simulation config; no board DDR timing qualification'), indent=2)+'\n')
print(revision, len(hashes), out)
