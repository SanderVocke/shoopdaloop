"""Compare retained controls without conflating logical results and clocks."""
import json
from pathlib import Path
import hashlib
import subprocess

root = Path('/workspace/shoopdaloop')
work = root/'work/area-experiments'
out = root/'docs/fpga/measurements/area-experiments/s4-iterative-capacity-unit-performance.json'
assert not out.exists()
results = []
control_revision = '10cddabdbfe015f8a64c1105449aa5634be2f2fc'

def load(path):
    return json.loads(path.read_bytes())

def rows_equal(a, b, clock_fields):
    assert len(a) == len(b)
    for i, (x, y) in enumerate(zip(a, b)):
        xx = {k: v for k, v in x.items() if k not in clock_fields}
        yy = {k: v for k, v in y.items() if k not in clock_fields}
        assert xx == yy, (i, xx, yy)

def verify_control(data):
    for model in data['provenance']['models']:
        for path, sha in model['sources_sha256'].items():
            raw = subprocess.check_output(['git', 'show', control_revision+':'+path], cwd=root)
            assert hashlib.sha256(raw).hexdigest() == sha, path

for width in [32, 64]:
    a = load(work/f's3-path-context-width-axi{width}.json')
    b = load(work/f's4-iterative-capacity-width/axi{width}.json')
    verify_control(a)
    assert len(a['cases']) == len(b['cases'])
    for i, (x, y) in enumerate(zip(a['cases'], b['cases'])):
        rows_equal(x['measurements'], y['measurements'], ['cycles'])
        results.append(dict(kind='width', axi_width=width, case=i,
            rows=len(x['measurements']), exact_noncycle_fields=True,
            control_cycles_total=sum(r['cycles'] for r in x['measurements']),
            candidate_cycles_total=sum(r['cycles'] for r in y['measurements'])))
    a = load(work/f's3-path-context-directory-axi{width}.json')
    b = load(work/f's4-iterative-capacity-directory/axi{width}.json')
    verify_control(a)
    rows_equal(a['measurements'], b['measurements'], ['cycles'])
    rows_equal(a['setup'], b['setup'], ['cycles'])
    results.append(dict(kind='directory', axi_width=width,
        rows=len(a['measurements']), exact_noncycle_fields=True,
        control_cycles_total=sum(r['cycles'] for r in a['measurements']),
        candidate_cycles_total=sum(r['cycles'] for r in b['measurements']),
        setup_cycles=dict(control=a['setup_cycles'], candidate=b['setup_cycles'],
            delta=b['setup_cycles']-a['setup_cycles'])))

a = load(work/'s3-path-context-store-operations.json')
b = load(work/'s4-iterative-capacity-store-operations.json')
verify_control(a)
rows_equal(a['measurements'], b['measurements'],
    ['accepted_through_done_cycles', 'admission_through_cleanup_cycles'])
assert a['memory'] == b['memory']
assert a['allocated_blocks'] == b['allocated_blocks']
results.append(dict(kind='public_store', rows=len(a['measurements']),
    exact_noncycle_fields=True, final_memory_exact=True,
    control_cycles_total=sum(r['admission_through_cleanup_cycles'] for r in a['measurements']),
    candidate_cycles_total=sum(r['admission_through_cleanup_cycles'] for r in b['measurements'])))
out.write_text(json.dumps(dict(control=control_revision,
    candidate='0e6247004fabc2b6e8c70bfdca113ab73548268a',
    control_audio_sources_verified=True, cases=results), indent=2)+'\n')
print(json.dumps(results, indent=2))
