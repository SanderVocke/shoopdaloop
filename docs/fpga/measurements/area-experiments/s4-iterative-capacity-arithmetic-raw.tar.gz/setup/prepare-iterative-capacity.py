"""Prepare one bounded node/capacity add-subtract unit; no worktree edits."""
import argparse
from pathlib import Path
import re
import subprocess
p=argparse.ArgumentParser();p.add_argument('--revision',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();assert not a.output.exists()
s=subprocess.check_output(['git','show',a.revision+':fpga/media_store/rtl/media_metadata.sv'],text=True)
def change(old,new):
 global s
 assert s.count(old)==1,(old,s.count(old));s=s.replace(old,new)
change('CHECK_TREE, COUNT_NODES, CAPACITY,','CHECK_TREE, COUNT_NODES, COUNT_CEIL, COUNT_SUM, COUNT_FREE, COUNT_AVAILABLE, CAPACITY,')
change('    reg capacity_grow, capacity_insufficient;', '''    reg capacity_grow, capacity_insufficient;
    reg [32:0] count_n;
    reg [28:0] count_acc;
    reg [LEVEL_BITS-1:0] count_step;
    reg count_existing;
    wire [33:0] count_left = phase==COUNT_CEIL ? {1'b0,count_n}
        : phase==COUNT_SUM ? {5'b0,count_acc} : phase==COUNT_FREE ? 34'(TABLE_PAGES)
        : phase==COUNT_AVAILABLE ? unallocated_pages[33:0]
        : phase==CAPACITY ? required_nodes[33:0] : available[33:0];
    wire [33:0] count_right = phase==COUNT_CEIL ? 34'd15
        : phase==COUNT_SUM ? {1'b0,count_n} : phase==COUNT_FREE ? {2'b0,high_water}
        : phase==COUNT_AVAILABLE ? {2'b0,free_pages}
        : phase==CAPACITY ? existing_nodes[33:0] : additional[33:0];
    wire count_subtract = phase==COUNT_FREE || phase==CAPACITY || phase==CHECK_CAPACITY;
    wire [33:0] count_result = count_left+(count_right^{34{count_subtract}})+34'(count_subtract);''')
s,n=re.subn(r'    function automatic \[63:0\] nodes\(input \[31:0\] count\);.*?    endfunction\n','',s,flags=re.S);assert n==1
change('            unallocated_pages <= 0;', '            count_n<=0;count_acc<=0;count_step<=0;count_existing<=0;\n            unallocated_pages <= 0;')
old='''                COUNT_NODES: begin
                    required_nodes <= nodes(new_count);
                    existing_nodes <= nodes(used);
                    capacity_grow <= new_count > used;
                    unallocated_pages <= 64'(TABLE_PAGES)-{32'b0,high_water};
                    phase <= CAPACITY;
                end
                CAPACITY: begin
                    additional <= capacity_grow ? required_nodes-existing_nodes : 64'b0;
                    available <= unallocated_pages+{32'b0,free_pages};
                    phase <= CHECK_CAPACITY;
                end
                CHECK_CAPACITY: begin
                    capacity_insufficient <= additional > available;
                    phase <= WALK;
                end'''
new='''                COUNT_NODES: begin
                    count_n<={1'b0,new_count};count_acc<=0;count_step<=0;count_existing<=0;
                    capacity_grow<=new_count>used;
                    if(new_count<=used) begin
                        required_nodes<=0;existing_nodes<=0;unallocated_pages<=0;available<=0;
                        phase<=CAPACITY;
                    end else phase<=COUNT_CEIL;
                end
                COUNT_CEIL: begin count_n<=33'(count_result>>4);phase<=COUNT_SUM;end
                COUNT_SUM: begin
                    count_acc<=count_result[28:0];
                    if(count_step==LEVEL_BITS'(LEVELS-1)) begin
                        if(!count_existing && used!=0) begin
                            required_nodes<={35'b0,count_result[28:0]};count_existing<=1;
                            count_n<={1'b0,used};count_acc<=0;count_step<=0;phase<=COUNT_CEIL;
                        end else begin
                            if(count_existing) existing_nodes<={35'b0,count_result[28:0]};
                            else begin required_nodes<={35'b0,count_result[28:0]};existing_nodes<=0;end
                            phase<=COUNT_FREE;
                        end
                    end else begin count_step<=count_step+1'b1;phase<=COUNT_CEIL;end
                end
                COUNT_FREE: begin
                    unallocated_pages<={{30{count_result[33]}},count_result};phase<=COUNT_AVAILABLE;
                end
                COUNT_AVAILABLE: begin
                    available<={{30{count_result[33]}},count_result};phase<=CAPACITY;
                end
                CAPACITY: begin
                    additional<=capacity_grow ? {30'b0,count_result} : 64'b0;
                    phase<=CHECK_CAPACITY;
                end
                CHECK_CAPACITY: begin
                    capacity_insufficient<=capacity_grow && !available[63] && count_result[33];
                    phase<=WALK;
                end'''
change(old,new)
change('    reg capacity_grow, capacity_insufficient;', "    wire unused_capacity_bits = &{1'b0,required_nodes,existing_nodes,unallocated_pages,additional,available};\n    reg capacity_grow, capacity_insufficient;")
if 'wire [63:0] saved_page_address = ' in s:
    change('    wire [63:0] saved_page_address = page_address(path_page[saved_path_level]);', "    wire [63:0] saved_page_address = page_address(path_page[saved_path_level]);\n    wire unused_page_alignment = &{1'b0,saved_page_address[5:0]};")
if 'input [1:0] op, input [63:0] address,' in s:
    change("        begin bank <= which; cache_opcode <= op; cache_address <= RELATIVE_BITS'(address); cache_data <= data; resume <= next; phase <= CACHE_SEND; end", "        reg unused_address_bits;\n        begin\n            unused_address_bits = &{1'b0,address};\n            bank <= which; cache_opcode <= op; cache_address <= RELATIVE_BITS'(address); cache_data <= data; resume <= next; phase <= CACHE_SEND;\n        end")
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(s);print(a.output)
