"""Independent big-integer oracle versus proposed bounded ALU arithmetic (not RTL)."""
import hashlib,itertools,json,random
from pathlib import Path
U32=(1<<32)-1;U64=(1<<64)-1;U34=(1<<34)-1

def reference_nodes(n,levels):
 return sum((n+16**k-1)//16**k for k in range(1,levels+1))
def alu(a,b,subtract=False):return (a+(b^U34 if subtract else b)+int(subtract))&U34
def extend(x):return x | (U64^U34) if x&(1<<33) else x

def iterative_nodes(n,levels):
 acc=0
 for _ in range(levels):
  n=(alu(n,15)>>4)&((1<<33)-1);acc=alu(acc,n)&((1<<29)-1)
 return acc

def check(n,used,pages,high,free,levels):
 required=reference_nodes(n,levels);existing=reference_nodes(used,levels)
 assert required < 1<<29 and existing < 1<<29
 unallocated=(pages-high)&U64;available=(unallocated+free)&U64
 additional=required-existing if n>used else 0
 expected=additional>available
 if n<=used:
  assert not expected;return
 r=iterative_nodes(n,levels);e=iterative_nodes(used,levels) if used else 0
 assert (r,e)==(required,existing)
 u=extend(alu(pages,high,True));a=extend(alu(u&U34,free));extra=alu(r,e,True)
 result=not bool(a&(1<<63)) and bool(alu(a&U34,extra,True)&(1<<33))
 assert (u,a,extra,result)==(unallocated,available,additional,expected),(n,used,pages,high,free,levels)

positions=[0,1,2,14,15,16,17,255,256,257,65535,65536,(1<<31)-1,U32-1,U32]
boundary=0
for levels,pages,n,used in itertools.product(range(1,9),[1,17,(1<<31)-1],positions,positions):
 for high,free in itertools.product(sorted({0,pages-1,pages,pages+1,(1<<31)-1,U32}),[0,1,17,(1<<31)-1,U32]):
  check(n,used,pages,high,free,levels);boundary+=1
seed=20261123;rng=random.Random(seed);random_cases=100000
for _ in range(random_cases):check(rng.getrandbits(32),rng.getrandbits(32),rng.randint(1,(1<<31)-1),rng.getrandbits(32),rng.getrandbits(32),rng.randint(1,8))
summary={'scope':'Arithmetic preparation only; no production RTL applied or hardware optimization claimed.','boundary_cases':boundary,'random_cases':random_cases,'seed':seed,'maximum_nodes_u32_levels8':reference_nodes(U32,8),'unit_bits':34,'preserved':'Unsigned64 underflow/wrap and capacity refusal for all checked cases; node totals against direct closed-form big integers','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
out=Path('work/area-experiments/setup/iterative-capacity-draft2/arithmetic-preflight.json');assert not out.exists();out.write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
