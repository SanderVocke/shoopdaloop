set_param general.maxThreads 2
foreach label {control candidate} {
    open_checkpoint /${label}/post_opt.dcp
    set cells [get_cells -hier -filter {NAME =~ *midi/content/* && IS_PRIMITIVE == 1}]
    if {[llength $cells] < 100} {error "Unexpected MIDI store scope"}
    set output [open /analysis/${label}-primitives.csv w]
    puts $output "name,primitive"
    foreach cell [lsort -dictionary $cells] {
        puts $output "[get_property NAME $cell],[get_property REF_NAME $cell]"
    }
    close $output
    close_design
}
exit 0
