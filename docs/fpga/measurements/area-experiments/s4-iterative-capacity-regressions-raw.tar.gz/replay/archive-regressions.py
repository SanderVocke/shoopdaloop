"""Retain completed suite logs and exact replay inputs for an area experiment."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

p = argparse.ArgumentParser()
p.add_argument('--label', required=True)
p.add_argument('--candidate', required=True)
p.add_argument('--control', required=True)
p.add_argument('--command', required=True)
p.add_argument('--log', type=Path, required=True)
p.add_argument('--source-root', type=Path, required=True)
p.add_argument('--input', type=Path, action='append', default=[])
p.add_argument('--expect', type=int, required=True)
a = p.parse_args()
log = a.log.read_text()
suites = {}
current = None
for line in log.splitlines():
    match = re.search(r'Running tests/(\w+)\.rs ', line)
    if match:
        current = match[1]
    match = re.search(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored; 0 measured; \d+ filtered out; finished in ([\d.]+)s', line)
    if match:
        assert current is not None and current not in suites
        suites[current] = dict(passed=int(match[1]), seconds=float(match[2]))
assert sum(s['passed'] for s in suites.values()) == a.expect, suites
assert not re.search(r'test result: FAILED|panicked at|error: test failed', log)
out = Path('docs/fpga/measurements/area-experiments')
paths = {s: out/(a.label+s) for s in ['-raw.tar.gz', '-retention.json', '-summary.json']}
assert not any(p.exists() for p in paths.values())
members = {'logs/'+a.log.name: a.log.read_bytes(), 'replay/archive-regressions.py': Path(__file__).read_bytes()}
fixtures = subprocess.check_output(['git', 'archive', a.candidate,
    'src/rust/rt_fpga_testbench', 'Cargo.toml', 'Cargo.lock'])
with tarfile.open(fileobj=io.BytesIO(fixtures)) as tar:
    for item in tar.getmembers():
        if item.isfile():
            members['fixture/'+item.name] = tar.extractfile(item).read()
snapshot = json.loads((a.source_root/'snapshot-provenance.json').read_bytes())
assert snapshot['revision'] == a.candidate
members['snapshot-provenance.json'] = (a.source_root/'snapshot-provenance.json').read_bytes()
for path in sorted((a.source_root/'fpga').rglob('*')):
    if path.suffix in ['.sv', '.svh']:
        members['source/'+str(path.relative_to(a.source_root))] = path.read_bytes()
assert snapshot['sha256'] == {
    n.removeprefix('source/'): hashlib.sha256(b).hexdigest()
    for n, b in members.items() if n.startswith('source/')}
for path in a.input:
    name = 'replay/'+str(path.relative_to(Path('work/area-experiments')))
    assert name not in members
    members[name] = path.read_bytes()
hashes = {n: hashlib.sha256(b).hexdigest() for n, b in sorted(members.items())}
with tarfile.open(paths['-raw.tar.gz'], 'x:gz') as tar:
    for n, b in sorted(members.items()):
        info = tarfile.TarInfo(n); info.size = len(b); info.mode = 0o644
        tar.addfile(info, io.BytesIO(b))
with tarfile.open(paths['-raw.tar.gz']) as tar:
    assert hashes == {m.name: hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in tar.getmembers()}
paths['-retention.json'].write_text(json.dumps(dict(archive=paths['-raw.tar.gz'].name,
    archive_sha256=hashlib.sha256(paths['-raw.tar.gz'].read_bytes()).hexdigest(),
    members_sha256=hashes), indent=2)+'\n')
paths['-summary.json'].write_text(json.dumps(dict(candidate_revision=a.candidate,
    control_revision=a.control, command=a.command, suites=suites,
    environment='Rust1.100.0 Verilator5.032 RUSTFLAGS=-D warnings; pinned DRAMsim3 runtime linked under snapshot/work; walltimes include compilation',
    source_snapshot=snapshot, retention=paths['-retention.json'].name), indent=2)+'\n')
print(json.dumps(suites, indent=2))
