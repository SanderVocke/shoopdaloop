import csv,hashlib,json,os,statistics,subprocess
from pathlib import Path
os.sched_setaffinity(0,{0});out=Path('work/read-overwrite-micro-results');out.mkdir(exist_ok=True);names=['base','read-overwrite'];metas={n:json.loads((Path('work/stereo-chunk-results')/f'{n}-native.json').read_text()) for n in names}
for field in ['rustc','flags','command']:assert metas['base'][field]==metas['read-overwrite'][field]
changed=[p for p,h in metas['base']['source_sha256'].items() if metas['read-overwrite']['source_sha256'][p]!=h];assert changed==['src/rust/rt_runtime/src/audio_refs.rs'],changed
for m in metas.values():assert hashlib.sha256(Path(m['binary']).read_bytes()).hexdigest()==m['binary_sha256']
rows=[]
for rep in range(6):
 for name in names[rep%2:]+names[:rep%2]:
  path=out/f'{rep}-{name}.csv';assert not path.exists()
  path.write_text(subprocess.check_output([metas[name]['binary']],text=True))
  for r in csv.DictReader(path.read_text().splitlines()):r.update(candidate=name,repeat=rep);rows.append(r)
 print('rotation',rep,'correctness passed',flush=True)
(out/'native-results.json').write_text(json.dumps(rows,indent=2)+'\n')
for frames in [1,32,128]:
 for channels in [1,2,3]:
  for gain in ['unity','constant','ramp']:
   for op in ['read','peak','accumulate']:
    a=[statistics.median(float(r['ns_per_quantum']) for r in rows if r['candidate']==name and int(r['frames'])==frames and int(r['channels'])==channels and r['gain']==gain and r['operation']==op) for name in names]
    print(frames,channels,gain,op,*[round(x,2) for x in a],round((a[1]/a[0]-1)*100,2),flush=True)
