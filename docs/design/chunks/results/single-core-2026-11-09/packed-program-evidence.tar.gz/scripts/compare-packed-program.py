import csv,hashlib,itertools,json,math,os,statistics,subprocess
from pathlib import Path
os.sched_setaffinity(0,{0});out=Path('work/packed-program-results');out.mkdir(exist_ok=True)
names=['packed-descriptors','packed-program'];meta={n:json.loads(Path('work/callback-visitor-builds',n+'.json').read_text()) for n in names};binaries={n:Path('work/bin/offline-'+n) for n in names}
for field in ['command','rustc','cargo_lock_sha256','benchmark_sha256','flags']:assert all(m[field]==meta[names[0]][field] for m in meta.values()),field
for n in names[1:]:
 changed={p for p,h in meta[names[0]]['all_crate_rust_hashes'].items() if meta[n]['all_crate_rust_hashes'][p]!=h};assert changed=={'src/rust/rt_runtime/src/executor_compact.rs'},changed
for n,p in binaries.items():assert hashlib.sha256(p.read_bytes()).hexdigest()==meta[n]['binary_sha256']
(out/'builds.json').write_text(json.dumps(meta,indent=2)+'\n');rows=[];modes=['current','chunks','chunks-descriptors','compact']
for rep in range(6):
 shift=(rep//2)%len(names);order=names[shift:]+names[:shift]
 if rep%2:order=order[::-1]
 mode_order=modes[rep%len(modes):]+modes[:rep%len(modes)]
 for buffer in [32,256]:
  for scene in ['idle','play','record']:
   for mode in mode_order:
    current=[]
    for name in order:
     path=out/f'{rep}-{buffer}-{scene}-{mode}-{name}.csv';assert not path.exists()
     raw=subprocess.check_output([str(binaries[name]),mode,scene,str(buffer),'8','512' if buffer==32 else '64','48000'],text=True);path.write_text(raw)
     r=next(csv.DictReader(raw.splitlines()));assert r['mode']==mode and r['scenario']==scene
     r.update(candidate=name,repeat=rep,within_mode_order=order.index(name));rows.append(r);current.append(r)
     (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
    values=[float(r['checksum']) for r in current];assert all(math.isclose(v,values[0],rel_tol=1e-6,abs_tol=1e-8) for v in values)
    assert len({r['arena_materializations'] for r in current})==1,'logical work changed'
 print('rotation',rep,'passed; within each mode:',order,flush=True)
for buffer in [32,256]:
 for mode in modes:
  for scene in ['idle','play','record']:
   vals=[]
   for name in names:
    a=[r for r in rows if int(r['buffer'])==buffer and r['mode']==mode and r['scenario']==scene and r['candidate']==name];assert len(a)==6
    vals.append((name,statistics.median(int(r['p50_ns']) for r in a),statistics.median(int(r['p99_ns']) for r in a)))
   print('SUMMARY',buffer,mode,scene,vals,flush=True)
for n,p in binaries.items():assert hashlib.sha256(p.read_bytes()).hexdigest()==meta[n]['binary_sha256']
