from pathlib import Path
p=Path('src/rust/rt_runtime/src/executor_compact.rs');s=p.read_text();Path('work/executor_compact.before_packed_program.rs').write_text(s)
a=s.index('struct Route {');b=s.index('pub(super) struct Program {',a);head=s[a:b];head=head.replace(': usize',': u32');s=s[:a]+head+s[b:]
s=s.replace('struct Route {','// Prepared edge/wire counts are bounded by Config\'s portable i32::MAX limits.\nstruct Route {',1)
s=s.replace('wire: wire(edge, &self.bases),','wire: wire(edge, &self.bases) as u32,').replace('port: edge.destination.port as usize,','port: edge.destination.port as u32,').replace('first: begin,','first: begin as u32,').replace('end: self.inputs.len(),','end: self.inputs.len() as u32,').replace('output: self.bases[step.node.slot() as usize],','output: self.bases[step.node.slot() as usize] as u32,').replace('outputs: slot.ports.audio_outputs,','outputs: slot.ports.audio_outputs as u32,')
a=s.index('            for index in 0..program.operations.len() {');b=s.index('            for index in 0..program.outputs.len() {',a);r=s[a:b]
for field in ['outputs','output','first','end']:r=r.replace('op.'+field,field)
needle='                let op = program.operations[index];\n';assert r.count(needle)==1;r=r.replace(needle,needle+'''                let (first, end, output, outputs) = (
                    op.first as usize,
                    op.end as usize,
                    op.output as usize,
                    op.outputs as usize,
                );
''',1);s=s[:a]+r+s[b:]
s=s.replace('route.wire < program.host','(route.wire as usize) < program.host').replace('program.wires[route.wire]','program.wires[route.wire as usize]').replace('program.source(route.wire,','program.source(route.wire as usize,').replace('[route.port]','[route.port as usize]').replace('audio.output(route.port)','audio.output(route.port as usize)')
p.write_text(s);print('applied only private packed program indices')
