import csv,hashlib,json,os,re,subprocess
from pathlib import Path
os.sched_setaffinity(0,{0});out=Path('work/steady-delta');out.mkdir(exist_ok=True)
meta=json.loads(Path('work/pgo/generate.json').read_text());binary=Path(meta['binary']);assert hashlib.sha256(binary.read_bytes()).hexdigest()==meta['binary_sha256']
profdata=Path(os.environ['RUSTUP_HOME'])/'toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin/llvm-profdata'
pattern=re.compile(r'^  (.*):\n    Hash: (0x[0-9a-f]+)\n    Counters: (\d+)\n(?:    Function count: [^\n]*\n)?    Block counts: \[([^\]]*)\]',re.M)
summary=[];evidence=[]
for mode in ['current','compact']:
 for scene in ['idle','play','record']:
  profiles={}
  for callbacks in [4,512]:
   name=f'{mode}-{scene}-{callbacks}';path=out/(name+'.profraw');assert not path.exists()
   args=['taskset','-c','0',str(binary),mode,scene,'32','8',str(callbacks),'48000']
   env={**os.environ,'LLVM_PROFILE_FILE':str(path.resolve())}
   row=next(csv.DictReader(subprocess.check_output(args,env=env,text=True).splitlines()));row={k:row[k] for k in ['mode','scenario','buffer','tracks','callbacks','checksum','arena_materializations']}
   dump=subprocess.check_output([str(profdata),'show','--all-functions','--counts',str(path)],text=True);(out/(name+'.txt')).write_text(dump)
   functions={}
   for fn,code,n,counters in pattern.findall(dump):
    values=[int(x) for x in counters.split(',') if x.strip()];assert len(values)==int(n),(fn,n,values);functions[fn]=(code,values)
   total=int(re.search(r'Total functions: (\d+)',dump).group(1));assert len(functions)==total,(len(functions),total)
   profiles[callbacks]=functions;evidence.append(dict(command=args,output_without_timings=row,profile_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
  assert profiles[4].keys()==profiles[512].keys()
  entries=[]
  for fn,(code,small) in profiles[4].items():
   code2,large=profiles[512][fn];assert code==code2 and len(small)==len(large)
   delta=[b-a for a,b in zip(small,large)]
   if any(delta) and any(c in fn for c in ['rt_runtime','shoop_loops','shoop_rt_engine']):entries.append(dict(function=fn,max_positive_delta=max(delta),max_delta_per_extra_callback=max(delta)/508,negative_counters=sum(x<0 for x in delta),counter_deltas=delta))
   if 'ResourceStore3new' in fn:assert all(x==0 for x in delta),'initialization did not cancel'
  entries.sort(key=lambda r:r['max_positive_delta'],reverse=True);summary.append(dict(mode=mode,scenario=scene,functions=entries))
  print(mode,scene,'top steady-processing count deltas (not time):',flush=True)
  for r in entries[:12]:print(round(r['max_delta_per_extra_callback'],2),r['function'],flush=True)
(out/'results.json').write_text(json.dumps(dict(purpose='diagnostic counter subtraction; includes per-callback controller work; all instrumented timings discarded; not a valid PGO profile',instrumented_build=meta,evidence=evidence,cases=summary),indent=2)+'\n')
