import csv,hashlib,json,math,os,statistics,subprocess
from pathlib import Path
os.sched_setaffinity(0,{0})
out=Path('work/dense-lookup-repeat-results');out.mkdir(exist_ok=True)
binaries={n:'work/bin/offline-'+n for n in ['packed-descriptors','dense-lookup']}
meta={n:json.loads(Path('work/callback-visitor-builds',n+'.json').read_text()) for n in binaries}
for field in ['command','rustc','cargo_lock_sha256','benchmark_sha256','flags']:
 assert all(m[field]==meta['packed-descriptors'][field] for m in meta.values()), field
for n,p in binaries.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==meta[n]['binary_sha256']
changed=[p for p,h in meta['packed-descriptors']['all_crate_rust_hashes'].items() if meta['dense-lookup']['all_crate_rust_hashes'][p]!=h]
assert set(changed)=={'src/rust/shoop_loops/src/topology.rs'},changed
(out/'builds.json').write_text(json.dumps(meta,indent=2)+'\n')
rows=[];cases=[(m,n) for m in ['current','compact'] for n in binaries]
for rep in range(6):
 order=cases[rep%len(cases):]+cases[:rep%len(cases)]
 for buffer in [32,256]:
  for scenario in ['idle','play','record']:
   for mode,name in order:
    path=out/f'{rep}-{buffer}-{scenario}-{mode}-{name}.csv'
    if path.exists():raw=path.read_text()
    else:
     raw=subprocess.check_output([binaries[name],mode,scenario,str(buffer),'8','512' if buffer==32 else '64','48000'],text=True);path.write_text(raw)
    r=next(csv.DictReader(raw.splitlines()));r.update(candidate=name,repeat=rep);rows.append(r)
    (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
 for buffer in [32,256]:
  for mode in ['current','compact']:
   for scenario in ['idle','play','record']:
    vals=[float(r['checksum']) for r in rows if int(r['buffer'])==buffer and r['scenario']==scenario and r['mode']==mode];assert all(math.isclose(v,vals[0],rel_tol=1e-6,abs_tol=1e-8) for v in vals)
 print('rotation',rep,'passed',flush=True)
for buffer in [32,256]:
 for mode in ['current','compact']:
  for scenario in ['idle','play','record']:
   for name in binaries:
    a=[r for r in rows if int(r['buffer'])==buffer and r['scenario']==scenario and r['mode']==mode and r['candidate']==name]
    print('SUMMARY',buffer,mode,scenario,name,'p50',statistics.median(int(r['p50_ns']) for r in a),'p99',statistics.median(int(r['p99_ns']) for r in a),flush=True)
for n,p in binaries.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==meta[n]['binary_sha256']
