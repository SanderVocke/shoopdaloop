from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=json.loads(Path('work/verified-builds/native-packed-thin-one.json').read_text())
hashes={p:h(p) for p in base['all_crate_rust_hashes']};changed=[p for p,sha in base['all_crate_rust_hashes'].items() if hashes[p]!=sha];assert changed==['src/rust/shoop_loops/src/topology.rs'],changed
assert h('Cargo.lock')==base['cargo_lock_sha256'];assert subprocess.check_output(['rustc','-Vv'],text=True)==base['rustc'];assert not os.environ.get('RUSTFLAGS')
env={**os.environ,'CARGO_PROFILE_RELEASE_LTO':'thin','CARGO_PROFILE_RELEASE_CODEGEN_UNITS':'1'}
for c in ['rt_runtime','shoop_loops','shoop_rt_engine','shoop_host']:os.utime(f'src/rust/{c}/src/lib.rs',None)
out=Path('work/native-dense-lookup');out.mkdir(exist_ok=True);start=time.monotonic()
with (out/'build.log').open('w') as f:subprocess.run(base['command'],env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
assert hashes=={p:h(p) for p in hashes};dest=Path('work/bin/host-dense-lookup-thin-one');assert not dest.exists();shutil.copyfile('target/release/shoop_host',dest);shutil.copymode('target/release/shoop_host',dest)
info=dict(base,variant='dense-lookup-thin-one',all_crate_rust_hashes=hashes,source_hashes={p:h(p) for p in set(base['source_hashes'])|set(changed)},binary=str(dest),binary_sha256=h(dest),binary_bytes=dest.stat().st_size,build_seconds=time.monotonic()-start)
(out/'build.json').write_text(json.dumps(info,indent=2)+'\n');print(info['binary_sha256'],info['binary_bytes'],flush=True)
