from pathlib import Path
import hashlib,json,re,sys
p=max(Path('target/aarch64-unknown-linux-gnu/release/deps').glob('shoop_rt_engine-*.ll'),key=lambda p:p.stat().st_mtime);nodes={}
for line in p.open():
 m=re.match(r'!(\d+) = (.*)',line)
 if m:nodes[m.group(1)]=m.group(2).strip()
def attr(text,key):
 m=re.search(r'\b'+key+r': !(\d+)',text);return m.group(1) if m else None
def name(key):
 text=nodes.get(key,'');m=re.search(r'name: "([^"]*)"',text);return m.group(1) if m else ''
def number(text,key,default=0):
 m=re.search(r'\b'+key+r': (\d+)',text);return int(m.group(1)) if m else default
def refs(key):return re.findall(r'!(\d+)',nodes.get(key,''))
result=[]
for key,text in nodes.items():
 if 'DICompositeType(' not in text:continue
 n=name(key)
 if n not in ['EngineNode','HostedProcessor','StripInput','StripOutput','LoopFader','BusMixer','LoopNode'] and not (n.startswith('Slot<') and 'EngineNode' in n):continue
 if not number(text,'size'):continue
 fields=[];tags=[]
 for member in refs(attr(text,'elements')):
  m=nodes.get(member,'')
  if 'DW_TAG_member' in m:fields.append(dict(name=name(member),offset=number(m,'offset')//8,bytes=number(m,'size')//8,type=name(attr(m,'baseType'))))
  if 'DW_TAG_variant_part' in m:
   tag=nodes.get(attr(m,'discriminator'),'');tags.append(dict(offset=number(tag,'offset')//8,bytes=number(tag,'size')//8,metadata=tag))
 result.append(dict(name=n,bytes=number(text,'size')//8,fields=fields,tags=tags,metadata=text))
path=Path(sys.argv[1]);assert not path.exists();path.write_text(json.dumps(dict(ir=str(p),ir_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),types=result),indent=2)+'\n')
for t in result:
 if t['name']=='EngineNode' or t['name'].startswith('Slot<'):print(t['name'][:100],t['bytes'],'tags',t['tags'],'fields',[(f['name'],f['offset'],f['bytes']) for f in t['fields']])
