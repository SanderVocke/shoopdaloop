import csv,hashlib,json,math,os,statistics,subprocess
from pathlib import Path
os.sched_setaffinity(0,{0});out=Path('work/pgo/holdout');out.mkdir(exist_ok=True)
binaries={'thin-one':'work/bin/standalone-lto-thin-one','pgo':'work/bin/standalone-pgo-balanced'}
meta={'thin-one':json.loads(Path('work/thinlto-builds/thin-one.json').read_text()),'pgo':json.loads(Path('work/pgo/balanced.json').read_text())}
for field in ['command','rustc','all_crate_rust_hashes','standalone_hashes']:assert meta['thin-one'][field]==meta['pgo'][field],field
for n,p in binaries.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==meta[n]['binary_sha256']
(out/'builds.json').write_text(json.dumps(meta,indent=2)+'\n');rows=[]
cases=[(mode,n) for mode in ['current','compact'] for n in binaries]
for rep in range(4):
 for tracks in [1,4]:
  for buffer in [32,256]:
   for scenario in ['idle','play','record']:
    order=cases[rep%len(cases):]+cases[:rep%len(cases)]
    for mode,name in order:
     path=out/f'{rep}-{tracks}-{buffer}-{scenario}-{mode}-{name}.csv';assert not path.exists()
     raw=subprocess.check_output([binaries[name],mode,scenario,str(buffer),str(tracks),'512' if buffer==32 else '64','48000'],text=True);path.write_text(raw)
     r=next(csv.DictReader(raw.splitlines()));r.update(candidate=name,repeat=rep);rows.append(r)
     (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
  for buffer in [32,256]:
   for mode in ['current','compact']:
    for scenario in ['idle','play','record']:
     vals=[float(r['checksum']) for r in rows if int(r['buffer'])==buffer and r['scenario']==scenario and r['mode']==mode and int(r['tracks'])==tracks];assert all(math.isclose(v,vals[0],rel_tol=1e-6,abs_tol=1e-8) for v in vals)
 print('rotation',rep,'passed sample/capture assertions',flush=True)
for tracks in [1,4]:
 for buffer in [32,256]:
  for mode in ['current','compact']:
   for scenario in ['idle','play','record']:
    vals=[]
    for name in binaries:
     a=[r for r in rows if int(r['buffer'])==buffer and r['scenario']==scenario and r['mode']==mode and r['candidate']==name and int(r['tracks'])==tracks]
     vals.append((name,statistics.median(int(r['p50_ns']) for r in a),statistics.median(int(r['p99_ns']) for r in a)))
    print('SUMMARY',tracks,buffer,mode,scenario,vals,'change%',round((vals[1][1]/vals[0][1]-1)*100,2),flush=True)
