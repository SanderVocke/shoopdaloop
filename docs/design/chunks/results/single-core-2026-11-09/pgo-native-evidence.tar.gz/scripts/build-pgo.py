import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
root=Path.cwd();out=root/'work/pgo';out.mkdir(exist_ok=True);raw=out/'raw';raw.mkdir(exist_ok=True)
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
base=json.loads(Path('work/thinlto-builds/thin-one.json').read_text())
hashes={str(p):h(p) for c in ['rt_runtime','shoop_loops','shoop_rt_engine'] for p in sorted(Path('src/rust',c).rglob('*.rs'))};assert hashes==base['all_crate_rust_hashes']
standalone={p:h(p) for p in base['standalone_hashes']};assert standalone==base['standalone_hashes']
command=base['command'];env={**os.environ,'CARGO_PROFILE_RELEASE_LTO':'thin','CARGO_PROFILE_RELEASE_CODEGEN_UNITS':'1'};assert not env.get('RUSTFLAGS')
def build(name,flags):
 assert hashes=={p:h(p) for p in hashes}
 e=dict(env,RUSTFLAGS=flags)
 for crate in ['rt_runtime','shoop_loops','shoop_rt_engine']:os.utime(f'src/rust/{crate}/src/lib.rs',None)
 start=time.monotonic()
 with (out/f'{name}-build.log').open('w') as f:subprocess.run(command,env=e,stdout=f,stderr=subprocess.STDOUT,check=True)
 assert hashes=={p:h(p) for p in hashes}
 dest=Path('work/bin')/f'standalone-pgo-{name}';assert not dest.exists()
 shutil.copyfile('target/release/pi5_audio_benchmark',dest);shutil.copymode('target/release/pi5_audio_benchmark',dest)
 info=dict(base,variant='pgo-'+name,flags={k:e.get(k,'') for k in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_PROFILE_RELEASE_LTO','CARGO_PROFILE_RELEASE_CODEGEN_UNITS']},binary=str(dest),binary_sha256=h(dest),binary_bytes=dest.stat().st_size,build_seconds=time.monotonic()-start)
 (out/f'{name}.json').write_text(json.dumps(info,indent=2)+'\n');print('built',name,info['binary_sha256'],flush=True);return dest
instrumented=build('generate','-Cprofile-generate='+str(raw))
training=[]
for mode in ['current','chunks','chunks-descriptors','compact']:
 for scenario in ['idle','play','record']:
  for buffer in [32,256]:
   args=[str(instrumented),mode,scenario,str(buffer),'8','512' if buffer==32 else '64','48000']
   e=dict(env,LLVM_PROFILE_FILE=str(raw/f'{mode}-{scenario}-{buffer}-%p.profraw'))
   output=subprocess.check_output(['taskset','-c','0']+args,env=e,text=True)
   (out/f'train-{mode}-{scenario}-{buffer}.csv').write_text(output);training.append(args)
   print('trained',mode,scenario,buffer,flush=True)
sysroot=subprocess.check_output(['rustc','--print','sysroot'],text=True).strip();profdata=Path(sysroot)/'lib/rustlib/x86_64-unknown-linux-gnu/bin/llvm-profdata'
assert profdata.exists();profiles=sorted(p for p in raw.glob('*.profraw') if not p.name.startswith('default_'));assert len(profiles)==24
merged=out/'balanced.profdata';subprocess.run([str(profdata),'merge','-o',str(merged)]+[str(p) for p in profiles],check=True)
(out/'training.json').write_text(json.dumps(dict(commands=training,profiles={str(p):h(p) for p in profiles},merged_sha256=h(merged),profdata_version=subprocess.check_output([str(profdata),'--version'],text=True)),indent=2)+'\n')
build('balanced','-Cprofile-use='+str(merged))
