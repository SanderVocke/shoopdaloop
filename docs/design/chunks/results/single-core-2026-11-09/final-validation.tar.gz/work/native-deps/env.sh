export PKG_CONFIG_PATH="/workspace/shoopdaloop/work/native-deps/root/usr/lib/x86_64-linux-gnu/pkgconfig:/workspace/shoopdaloop/work/native-deps/root/usr/share/pkgconfig${PKG_CONFIG_PATH:+:$PKG_CONFIG_PATH}"
export LD_LIBRARY_PATH="/workspace/shoopdaloop/work/native-deps/root/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export LIBRARY_PATH="/workspace/shoopdaloop/work/native-deps/root/usr/lib/x86_64-linux-gnu${LIBRARY_PATH:+:$LIBRARY_PATH}"
