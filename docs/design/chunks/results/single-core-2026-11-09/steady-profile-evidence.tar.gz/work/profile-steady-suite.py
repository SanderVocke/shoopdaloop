import subprocess
for repeat in range(12):
 for mode in ['compact','current']:
  for scene in ['idle','play','record']:
   subprocess.run(['python3','work/profile-steady.py',f'steady-{repeat}-{mode}-{scene}',mode,scene],check=True)
 print('rotation',repeat,'complete',flush=True)
