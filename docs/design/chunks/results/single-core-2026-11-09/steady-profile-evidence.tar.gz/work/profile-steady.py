import csv, hashlib, io, json, os, pathlib, signal, subprocess, sys, time
R=pathlib.Path('/workspace/shoopdaloop'); W=R/'work/perf'; P=W/'root/usr/bin/perf'
name=sys.argv[1]; mode=sys.argv[2]; scene=sys.argv[3]; count=int(sys.argv[4]) if len(sys.argv)>4 else 512
D=W/name; D.mkdir(exist_ok=False)
ctl=D/'control'; ack=D/'ack'
os.mkfifo(ctl,0o600); os.mkfifo(ack,0o600)
env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','LD_LIBRARY_PATH':str(W/'root/usr/lib/x86_64-linux-gnu'),'DEBUGINFOD_URLS':'','PERF_BUILDID_DIR':str(W/'buildid'),'PERF_CONFIG':'/dev/null','AUDIO_PERF_CONTROL_PATH':str(ctl),'AUDIO_PERF_ACK_PATH':str(ack)}
cmd=['taskset','-c','0',str(P),'record','--all-user','--user-callchains','--per-thread','--no-inherit','--no-buildid-cache','-e','cpu-clock:u','-F','1999','--call-graph','dwarf,8192','-m','256','--delay=-1',f'--control=fifo:{ctl},{ack}','-o',str(D/'perf.data'),'--',str(R/'work/bin/perf-steady-pgo-v2'),mode,scene,'32','8',str(count),'48000']
(D/'command.json').write_text(json.dumps({'command':cmd,'environment':env,'purpose':'Diagnostic samples only; instrumented timing fields discarded; enabled after warmup and disabled before telemetry flush.'},indent=2))
start=time.monotonic()
with (D/'record.log').open('w') as log:
 p=subprocess.Popen(cmd,env=env,stdout=subprocess.PIPE,stderr=log,text=True,start_new_session=True)
 try: out,_=p.communicate(timeout=35)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGKILL); p.wait(); raise
assert p.returncode==0,(p.returncode,(D/'record.log').read_text())
rows=list(csv.DictReader(io.StringIO(out))); assert len(rows)==1, out
row=rows[0]
for field in ['p50_ns','p99_ns','max_ns']: del row[field]
(D/'validation.json').write_text(json.dumps(row,indent=2))
for task,args in [('report',['report','--stdio','--no-children','--sort','symbol','--percent-limit','0.5','--call-graph','none']),('stacks',['script','--ns'])]:
 with (D/(task+'.txt')).open('w') as output, (D/(task+'.log')).open('w') as errors:
  result=subprocess.run(['taskset','-c','0',str(P),*args,'-i',str(D/'perf.data')],env=env,stdout=output,stderr=errors,timeout=30)
 assert result.returncode==0,task
print(json.dumps({'name':name,'validation':row,'seconds':round(time.monotonic()-start,2)}))
