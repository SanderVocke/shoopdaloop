from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
out=Path('work/perf');name='perf-steady-pgo-v2';h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=json.loads(Path('work/pgo/balanced.json').read_text());assert all(h(p)==sha for p,sha in base['all_crate_rust_hashes'].items())
harness={str(p):h(p) for p in Path('work/perf-harness').rglob('*') if p.is_file()};source={p:h(p) for p in base['all_crate_rust_hashes']}
env={**os.environ,'CARGO_PROFILE_RELEASE_LTO':'thin','CARGO_PROFILE_RELEASE_CODEGEN_UNITS':'1','RUSTFLAGS':base['flags']['RUSTFLAGS']+' -C debuginfo=2'}
cmd=['taskset','-c','0','cargo','build','--locked','--offline','--release','-j','1','--manifest-path','work/perf-harness/Cargo.toml','--target-dir','target'];start=time.monotonic()
with (out/(name+'-build.log')).open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
assert source=={p:h(p) for p in source};assert harness=={p:h(p) for p in harness}
dest=Path('work/bin')/name;assert not dest.exists();shutil.copyfile('target/release/pi5_audio_benchmark',dest);shutil.copymode('target/release/pi5_audio_benchmark',dest)
info=dict(command=cmd,source_hashes=source,harness_hashes=harness,binary=str(dest),binary_sha256=h(dest),flags=env['RUSTFLAGS'],release_lto='thin',release_codegen_units=1,seconds=time.monotonic()-start,purpose='diagnostic only; FIFO markers exclude initialization and post-run validation, includes per-callback controller work; no timing ranking')
(out/(name+'-build.json')).write_text(json.dumps(info,indent=2)+'\n');print(dest,info['binary_sha256'],flush=True)
