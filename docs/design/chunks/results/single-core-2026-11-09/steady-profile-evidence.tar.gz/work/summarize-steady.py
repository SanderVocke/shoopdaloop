from pathlib import Path
import collections,json,re,subprocess
root=Path('work/perf');binary=Path('work/bin/perf-steady-pgo-v2')
nm=subprocess.check_output(['nm','-n',str(binary)],text=True);symbols={p[2]:int(p[0],16) for line in nm.splitlines() if len(p:=line.split())==3 and re.fullmatch('[0-9a-fA-F]+',p[0])}
results={}
for mode in ['compact','current']:
 for scene in ['idle','play','record']:
  counts=collections.Counter();sites=collections.Counter();lost=[]
  paths=sorted(root.glob(f'steady-*-{mode}-{scene}'))
  for path in paths:
   report=(path/'report.txt').read_text();lost.append(int(re.search(r'Total Lost Samples: (\d+)',report)[1]))
   for chunk in (path/'stacks.txt').read_text().split('\n\n'):
    lines=chunk.splitlines()
    if len(lines)<2:continue
    m=re.match(r'\s+[0-9a-f]+ (.+) \((.+)\)',lines[1])
    if not m:continue
    symbol=m[1];base,_,offset=symbol.partition('+0x');counts[base]+=1
    if base in symbols:sites[symbols[base]+int(offset or '0',16)]+=1
  total=sum(counts.values());lines=[]
  for symbol,n in counts.most_common(15):lines.append({'symbol':symbol,'samples':n,'percent':round(n/total*100,2)})
  addresses=[address for address,n in sites.most_common(25)]
  p=subprocess.check_output(['addr2line','-e',str(binary),'-f','-C',*[hex(a) for a in addresses]],text=True).splitlines()
  top_sites=[{'address':hex(a),'samples':sites[a],'function':p[i*2],'location':p[i*2+1]} for i,a in enumerate(addresses)]
  results[f'{mode}-{scene}']={'runs':len(paths),'samples':total,'lost':sum(lost),'top_functions':lines,'top_sites':top_sites}
  print(mode,scene,'samples',total,'lost',sum(lost))
  for item in lines[:8]:print(item['percent'],item['symbol'])
  for item in top_sites[:7]:print('SITE',item)
(root/'steady-summary.json').write_text(json.dumps(results,indent=2))
