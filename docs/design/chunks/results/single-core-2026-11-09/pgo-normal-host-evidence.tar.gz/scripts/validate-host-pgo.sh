#!/bin/bash
set -euo pipefail
source work/env.sh
taskset -c 0 python3 scripts/benchmark_audio_chunks.py --host work/bin/host-pgo-balanced --launcher work/bin/packed-chunk_benchmark --output work/pgo-host/validation-workflows --modes current compact --callbacks 64 --repeats 1 --warmup .1 --host-cpu 0 --scenarios idle record:silence record play record-play shared continue grab churn ramps > work/pgo-host/validation-workflows.log 2>&1
for mode in current compact; do
  taskset -c 0 python3 work/compare-native-v2.py --candidates thin-one=work/bin/host-packed-thin-one pgo=work/bin/host-pgo-balanced --launcher work/bin/density-dense_chunk_benchmark --output work/pgo-host/validation-$mode --mode $mode --callbacks 256 --buffer 32 --repeats 4 --dense --scenarios idle play record grab > work/pgo-host/validation-$mode.log 2>&1
done
