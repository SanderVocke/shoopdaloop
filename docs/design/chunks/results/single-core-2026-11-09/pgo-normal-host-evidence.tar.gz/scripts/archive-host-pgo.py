from pathlib import Path
import json,shutil,statistics,tarfile
src=Path('work/pgo-host');out=Path('docs/design/chunks/results/single-core-2026-11-09')
for name in ['generate','balanced','training']:shutil.copyfile(src/(name+'.json'),out/('pgo-host-'+name+'.json'))
lines=['\n\n## Normal-host PGO validation\n','\nAll20 workflows pass. Four rotated dense comparisons use the SAME default-built\nlaunchers and CPU0 for both hosts; 256-callback windows at host buffer32/Q32.\n','\n| Mode / scenario | ThinLTO/CGU1 p50 / p99 us | PGO p50 / p99 us | p50 change |\n| --- | ---: | ---: | ---: |\n']
for mode in ['compact','current']:
 rows=json.loads((src/('validation-'+mode)/'results.json').read_text());shutil.copyfile(src/('validation-'+mode)/'results.json',out/('pgo-native-'+mode+'.json'))
 for scenario in ['idle','play','record','grab']:
  values=[]
  for candidate in ['thin-one','pgo']:
   a=[r for r in rows if r['candidate']==candidate and r['scenario']==scenario];assert len(a)==4
   values.append([statistics.median(r[k] for r in a) for k in ['p50_us','p99_us']])
  old,new=values;delta=(new[0]/old[0]-1)*100
  lines.append(f'| {mode} {scenario} | {old[0]:.3f} / {old[1]:.3f} | {new[0]:.3f} / {new[1]:.3f} | {delta:.1f}% |\n')
lines.append('''
Normal-host PGO confirms a throughput gain: Compact5–18% and Current6–10% beyond
ThinLTO/CGU1. Compactplay/record and Currentrecord p99 regress in this short screen;
no worst-case claim. ELF11,322,264bytes vs12,706,368 (~11% smaller). Retain this as
the strongest tested native build choice; repository compiler defaults remain
unchanged. Source is exactly the packed baseline. The36 application training
profiles cover20 workflows plus16 dense cases across all4 modes, excluding build
tool profiles. The environment reconnect interrupted the first profile-use build;
logs were preserved and the hash-checked saved profile resumed successfully.
Actual Pi performance remains unmeasured; its packaged PGO profile is independently
trained on ARM execution counts and is not the native host profile.
''')
p=Path('docs/design/chunks/OPTIMIZATION_LOG.md');s=p.read_text();s=s.replace('| Balanced PGO + packed source + ThinLTO/CGU1 |','| Normal-host PGO + packed source + ThinLTO/CGU1 | 20 workflows pass; four rotated native comparisons: Compact p50 5–18%, Current 6–10% below thin/one; executable 11% smaller | Strongest tested native build; p99 mixed; Pi candidate independently trained and unmeasured |\n| Balanced PGO + packed source + ThinLTO/CGU1 |',1);s=s.replace('''Experiment 25: balanced profile-guided optimization on the retained packed source
with ThinLTO/CGU1. Train all four backends across idle/play/record and buffers32/256,
then compare the uninstrumented result and check held-out density. No production
source or repository compiler-profile defaults are changed for this experiment.''','''Next: reuse cached no-live-request eligibility for delayed-transition queries
between previews, with transactional resolver oracles and a fresh callback screen.
Queued independent directions: power-of-two quantum alignment masks, and checked
dense-slot topology lookup with the existing search as fallback. PGO validation
is complete for the native host; no repository compiler defaults are changed.''');s+=''.join(lines);p.write_text(s)
with tarfile.open(out/'pgo-normal-host-evidence.tar.gz','w:gz') as tar:
 for p in sorted(src.rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(src)))
 for name in ['pgo-host.py','validate-host-pgo.sh','archive-host-pgo.py']:tar.add(Path('work')/name,arcname='scripts/'+name)
with Path('work/README.txt').open('a') as f:f.write('''
LATEST: normalhostPGO COMPLETE. host-pgo-balanced SHA84b77c0b...,11,322,264bytes;
20workflowsPASS,4rotpairednativeCompact5–18%p50better,Current6–10%beyondthin1.
Tailsmixed, noWCETclaim. Sourceexactpacked, defaultsunchanged. AllhostPGOprofiles+
metadata+rawdata archived pgo-normal-host-evidence.tar.gz; topbesttableupdated.
Active ARMbaseline buildsession91873 (shoop_loopsCortexA76emit-asm-Dwarnings), BEFORE
preroutingcacheexperiment. No performancebenchrunning. NextarchivebaselineASM,
applystagedoracletestONLY; ensureoldcodepasses, thennewresolverbranch+looptests.
''')
print('normal-host evidence and best list updated')
