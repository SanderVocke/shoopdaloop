from pathlib import Path
import difflib
out=Path('work/quantum-mask-staged');out.mkdir(exist_ok=True)
changes={}
p=Path('src/rust/rt_runtime/src/quantum.rs');s=p.read_text();new=s.replace('frame.0 % self.0 as u64 == 0','frame.0 & (self.0 as u64 - 1) == 0').replace('let remainder = frame.0 % q;','let remainder = frame.0 & (q - 1);');assert new!=s;changes[str(p)]=(s,new)
p=Path('src/rust/shoop_loops/src/resolver/compact.rs');s=p.read_text();old='''            if state.content_length % q != 0
                || state.position % q != 0
                || state.capture_frames % q != 0
''';new=s.replace(old,'''            if (state.content_length | state.position | state.capture_frames) & (q - 1) != 0
''');assert new!=s;changes[str(p)]=(s,new)
patch=''
for p,(before,after) in changes.items():
 (out/Path(p).name).write_text(after)
 patch+=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+p,tofile='b/'+p))
(out/'candidate.patch').write_text(patch)
print('staged only; no production changes. Valid Quantum is private u16, constructors accept only 1/16/32/64/128.')
