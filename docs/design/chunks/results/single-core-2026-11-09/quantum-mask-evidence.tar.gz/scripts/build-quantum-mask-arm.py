from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
out=Path('work/quantum-mask-arm');out.mkdir(exist_ok=True);meta=json.loads(Path('work/pi5-audio-bench/builds.json').read_text());base=meta['variants']['packed-descriptors'];h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert subprocess.check_output(['rustc','-Vv'],text=True)==meta['compiler'];assert h('Cargo.lock')==meta['cargo_lock_sha256'];assert h('work/pi5-harness/Cargo.lock')==meta['standalone_lock_sha256']
for p,sha in meta['standalone_harness_hashes'].items():assert h(Path('work/pi5-harness')/p)==sha
hashes={p:h(p) for p in base['all_crate_rust_hashes']};changed=[p for p,sha in base['all_crate_rust_hashes'].items() if hashes[p]!=sha];assert set(changed)=={'src/rust/rt_runtime/src/quantum.rs','src/rust/shoop_loops/src/resolver/compact.rs'},changed
sysroot=subprocess.check_output(['rustc','--print','sysroot'],text=True).strip()
env={**os.environ,'RUSTFLAGS':meta['flags'],'CARGO_TARGET_AARCH64_UNKNOWN_LINUX_MUSL_LINKER':sysroot+'/lib/rustlib/x86_64-unknown-linux-gnu/bin/rust-lld'}
assert not env.get('CARGO_PROFILE_RELEASE_LTO') and not env.get('CARGO_PROFILE_RELEASE_CODEGEN_UNITS')
for crate in ['rt_runtime','shoop_loops','shoop_rt_engine']:os.utime(f'src/rust/{crate}/src/lib.rs',None)
start=time.monotonic()
with (out/'build.log').open('w') as f:subprocess.run(meta['command'],env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
assert hashes=={p:h(p) for p in hashes};dest=Path('work/bin/arm-quantum-mask');assert not dest.exists();source=Path('target/aarch64-unknown-linux-musl/release/pi5_audio_benchmark');shutil.copyfile(source,dest);shutil.copymode(source,dest)
b=dest.read_bytes();assert b[:6]==b'\x7fELF\x02\x01' and int.from_bytes(b[18:20],'little')==183
phoff=int.from_bytes(b[32:40],'little');phsize=int.from_bytes(b[54:56],'little');phnum=int.from_bytes(b[56:58],'little');assert all(int.from_bytes(b[phoff+i*phsize:phoff+i*phsize+4],'little')!=3 for i in range(phnum))
info=dict(base,binary=str(dest),binary_sha256=h(dest),binary_bytes=len(b),all_crate_rust_hashes=hashes,source_hashes={p:h(p) for p in set(base['source_hashes'])|set(changed)},release_lto=False,release_codegen_units=16,command=meta['command'],flags=meta['flags'],compiler=meta['compiler'],seconds=time.monotonic()-start)
(out/'build.json').write_text(json.dumps(info,indent=2)+'\n');print(dest,info['binary_sha256'],flush=True)
