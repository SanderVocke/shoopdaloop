import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
root=Path.cwd();out=root/'work/pgo-host-borrowed';out.mkdir(exist_ok=True);raw=out/'raw';raw.mkdir(exist_ok=True)
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
base=json.loads(Path('work/verified-builds/native-packed-thin-one.json').read_text())
assert {p for p,v in base['all_crate_rust_hashes'].items() if h(p)!=v}=={'src/rust/rt_runtime/src/executor_compact.rs'}
assert h('Cargo.lock')==base['cargo_lock_sha256']
assert subprocess.check_output(['rustc','-Vv'],text=True)==base['rustc']
all_hashes={str(p):h(p) for p in sorted(Path('src/rust').rglob('*.rs'))}
env={**os.environ,'CARGO_PROFILE_RELEASE_LTO':'thin','CARGO_PROFILE_RELEASE_CODEGEN_UNITS':'1'};assert not env.get('RUSTFLAGS')
env.pop('CARGO_ENCODED_RUSTFLAGS',None)
command=base['command'][:base['command'].index('--example')] # Only the host is needed; measured launchers are immutable default builds.
def build(name,flags):
 assert all_hashes=={p:h(p) for p in all_hashes}
 e=dict(env,RUSTFLAGS=flags)
 for c in ['rt_runtime','shoop_loops','shoop_rt_engine','shoop_host']:os.utime(f'src/rust/{c}/src/lib.rs',None)
 start=time.monotonic()
 with (out/f'{name}-build.log').open('w') as f:subprocess.run(command,env=e,stdout=f,stderr=subprocess.STDOUT,check=True)
 assert all_hashes=={p:h(p) for p in all_hashes}
 dest=Path('work/bin')/f'host-borrowed-pgo-{name}';assert not dest.exists()
 shutil.copyfile('target/release/shoop_host',dest);shutil.copymode('target/release/shoop_host',dest)
 info=dict(base,variant='host-borrowed-pgo-'+name,all_crate_rust_hashes={p:all_hashes[p] for p in base['all_crate_rust_hashes']},source_hashes={p:h(p) for p in base['source_hashes']},all_workspace_rust_hashes=all_hashes,flags={k:e.get(k,'') for k in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_PROFILE_RELEASE_LTO','CARGO_PROFILE_RELEASE_CODEGEN_UNITS']},binary=str(dest),binary_sha256=h(dest),binary_bytes=dest.stat().st_size,build_seconds=time.monotonic()-start)
 (out/f'{name}.json').write_text(json.dumps(info,indent=2)+'\n');print('built',name,info['binary_sha256'],flush=True)
if sys.argv[1]=='generate':build('generate','-Cprofile-generate='+str(raw))
elif sys.argv[1]=='train':
 e=dict(env,LLVM_PROFILE_FILE=str(raw/'host-training-%p.profraw'))
 jobs=[('workflows',['taskset','-c','0','python3','scripts/benchmark_audio_chunks.py','--host','work/bin/host-borrowed-pgo-generate','--launcher','work/bin/packed-chunk_benchmark','--output',str(out/'training-workflows'),'--modes','current','compact','--callbacks','64','--repeats','1','--warmup','.1','--host-cpu','0','--scenarios','idle','record:silence','record','play','record-play','shared','continue','grab','churn','ramps'])]
 for mode in ['current','chunks','chunks-descriptors','compact']:
  jobs.append((mode,['taskset','-c','0','python3','work/compare-native-v2.py','--candidates','generate=work/bin/host-borrowed-pgo-generate','--launcher','work/bin/density-dense_chunk_benchmark','--output',str(out/('training-dense-'+mode)),'--mode',mode,'--callbacks','128','--buffer','32','--repeats','1','--dense','--scenarios','idle','play','record','grab']))
 for name,cmd in jobs:
  with (out/f'train-{name}.log').open('w') as f:subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT,check=True)
  print('trained',name,flush=True)
 profiles=sorted(raw.glob('host-training-*.profraw'));assert len(profiles)==36,len(profiles)
 sysroot=subprocess.check_output(['rustc','--print','sysroot'],text=True).strip();profdata=Path(sysroot)/'lib/rustlib/x86_64-unknown-linux-gnu/bin/llvm-profdata'
 merged=out/'normal-host.profdata';subprocess.run([str(profdata),'merge','-o',str(merged)]+[str(p) for p in profiles],check=True)
 (out/'training.json').write_text(json.dumps(dict(commands=jobs,profiles={str(p):h(p) for p in profiles},merged_sha256=h(merged),timings='instrumented; excluded from rankings'),indent=2)+'\n')
elif sys.argv[1]=='use':
 profile=out/'normal-host.profdata';assert profile.exists();build('balanced','-Cprofile-use='+str(profile))
else:raise ValueError(sys.argv[1])
