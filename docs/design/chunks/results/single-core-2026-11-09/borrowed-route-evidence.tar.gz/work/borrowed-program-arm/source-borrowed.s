
work/bin/arm-borrowed-program:	file format elf64-littleaarch64

Disassembly of section .text:

00000000002d2280 <_RINvMNtNtCs7ys7bBRmuYo_10rt_runtime8executor13compact_audioNtB3_7Program6sourceNtNtB7_11host_buffer13BufferedAudioECscZZpAVW0qT6_15shoop_rt_engine>:
  2d2280: d10243ff     	sub	sp, sp, #0x90
  2d2284: a9037bfd     	stp	x29, x30, [sp, #0x30]
  2d2288: a9046ffc     	stp	x28, x27, [sp, #0x40]
  2d228c: a90567fa     	stp	x26, x25, [sp, #0x50]
  2d2290: a9065ff8     	stp	x24, x23, [sp, #0x60]
  2d2294: a90757f6     	stp	x22, x21, [sp, #0x70]
  2d2298: a9084ff4     	stp	x20, x19, [sp, #0x80]
  2d229c: 9100c3fd     	add	x29, sp, #0x30
  2d22a0: eb020076     	subs	x22, x3, x2
  2d22a4: 540000e3     	b.lo	0x2d22c0 <_RINvMNtNtCs7ys7bBRmuYo_10rt_runtime8executor13compact_audioNtB3_7Program6sourceNtNtB7_11host_buffer13BufferedAudioECscZZpAVW0qT6_15shoop_rt_engine+0x40>
  2d22a8: eb01007f     	cmp	x3, x1
  2d22ac: 54000c22     	b.hs	0x2d2430 <_RINvMNtNtCs7ys7bBRmuYo_10rt_runtime8executor13compact_audioNtB3_7Program6sourceNtNtB7_11host_buffer13BufferedAudioECscZZpAVW0qT6_15shoop_rt_engine+0x1b0>
  2d22b0: 52800c09     	mov	w9, #0x60               // =96
  2d22b4: 9b09007a     	madd	x26, x3, x9, x0
  2d22b8: f9402b49     	ldr	x9, [x26, #0x50]
  2d22bc: b4000209     	cbz	x9, 0x2d22fc <_RINvMNtNtCs7ys7bBRmuYo_10rt_runtime8executor13compact_audioNtB3_7Program6sourceNtNtB7_11host_buffer13BufferedAudioECscZZpAVW0qT6_15shoop_rt_engine+0x7c>
  2d22c0: eb01007f     	cmp	x3, x1
  2d22c4: 54000982     	b.hs	0x2d23f4 <_RINvMNtNtCs7ys7bBRmuYo_10rt_runtime8executor13compact_audioNtB3_7Program6sourceNtNtB7_11host_buffer13BufferedAudioECscZZpAVW0qT6_15shoop_rt_engine+0x174>
  2d22c8: 2a1f03e9     	mov	w9, wzr
  2d22cc: 52800c0a     	mov	w10, #0x60              // =96
  2d22d0: 9b0a006a     	madd	x10, x3, x10, x0
  2d22d4: f900050a     	str	x10, [x8, #0x8]
  2d22d8: 39000109     	strb	w9, [x8]
  2d22dc: a9484ff4     	ldp	x20, x19, [sp, #0x80]
  2d22e0: a94757f6     	ldp	x22, x21, [sp, #0x70]
  2d22e4: a9465ff8     	ldp	x24, x23, [sp, #0x60]
  2d22e8: a94567fa     	ldp	x26, x25, [sp, #0x50]
  2d22ec: a9446ffc     	ldp	x28, x27, [sp, #0x40]
  2d22f0: a9437bfd     	ldp	x29, x30, [sp, #0x30]
  2d22f4: 910243ff     	add	sp, sp, #0x90
  2d22f8: d65f03c0     	ret
  2d22fc: aa0503f8     	mov	x24, x5
  2d2300: aa0603fc     	mov	x28, x6
  2d2304: a90103e1     	stp	x1, x0, [sp, #0x10]
  2d2308: f90007e3     	str	x3, [sp, #0x8]
  2d230c: aa0803fb     	mov	x27, x8
  2d2310: d10043a8     	sub	x8, x29, #0x10
  2d2314: aa0403f4     	mov	x20, x4
  2d2318: aa0403e0     	mov	x0, x4
  2d231c: aa0703f9     	mov	x25, x7
  2d2320: aa0703e1     	mov	x1, x7
  2d2324: 9403f7df     	bl	0x3d02a0 <_RNvMs2_NtCs7ys7bBRmuYo_10rt_runtime10audio_refsNtB5_11RenderArena8allocate>
  2d2328: 385f03a8     	ldurb	w8, [x29, #-0x10]
  2d232c: 340000c8     	cbz	w8, 0x2d2344 <_RINvMNtNtCs7ys7bBRmuYo_10rt_runtime8executor13compact_audioNtB3_7Program6sourceNtNtB7_11host_buffer13BufferedAudioECscZZpAVW0qT6_15shoop_rt_engine+0xc4>
  2d2330: 385f13a9     	ldurb	w9, [x29, #-0xf]
  2d2334: aa1b03e8     	mov	x8, x27
  2d2338: 39000769     	strb	w9, [x27, #0x1]
  2d233c: 52800029     	mov	w9, #0x1                // =1
  2d2340: 17ffffe6     	b	0x2d22d8 <_RINvMNtNtCs7ys7bBRmuYo_10rt_runtime8executor13compact_audioNtB3_7Program6sourceNtNtB7_11host_buffer13BufferedAudioECscZZpAVW0qT6_15shoop_rt_engine+0x58>
  2d2344: f85f83b3     	ldur	x19, [x29, #-0x8]
  2d2348: aa1403e0     	mov	x0, x20
  2d234c: aa1303e1     	mov	x1, x19
  2d2350: aa1903e2     	mov	x2, x25
  2d2354: 9403f72f     	bl	0x3d0010 <_RNvMs2_NtCs7ys7bBRmuYo_10rt_runtime10audio_refsNtB5_11RenderArena6output>
  2d2358: aa0003f5     	mov	x21, x0
  2d235c: aa0103f7     	mov	x23, x1
  2d2360: aa1803e0     	mov	x0, x24
  2d2364: aa1603e1     	mov	x1, x22
  2d2368: 9404115a     	bl	0x3d68d0 <_RNvXs_NtCs7ys7bBRmuYo_10rt_runtime11host_bufferNtB4_13BufferedAudioNtB4_7AudioIo5input>
  2d236c: aa0003e9     	mov	x9, x0
  2d2370: aa0103e2     	mov	x2, x1
  2d2374: ab1c0321     	adds	x1, x25, x28
  2d2378: 1a9f37eb     	cset	w11, hs
  2d237c: eb02003f     	cmp	x1, x2
  2d2380: 1a9f97ea     	cset	w10, hi
  2d2384: 3700040b     	tbnz	w11, #0x0, 0x2d2404 <_RINvMNtNtCs7ys7bBRmuYo_10rt_runtime8executor13compact_audioNtB3_7Program6sourceNtNtB7_11host_buffer13BufferedAudioECscZZpAVW0qT6_15shoop_rt_engine+0x184>
  2d2388: 3700042a     	tbnz	w10, #0x0, 0x2d240c <_RINvMNtNtCs7ys7bBRmuYo_10rt_runtime8executor13compact_audioNtB3_7Program6sourceNtNtB7_11host_buffer13BufferedAudioECscZZpAVW0qT6_15shoop_rt_engine+0x18c>
  2d238c: eb1902ff     	cmp	x23, x25
  2d2390: 54000461     	b.ne	0x2d241c <_RINvMNtNtCs7ys7bBRmuYo_10rt_runtime8executor13compact_audioNtB3_7Program6sourceNtNtB7_11host_buffer13BufferedAudioECscZZpAVW0qT6_15shoop_rt_engine+0x19c>
  2d2394: d37ef722     	lsl	x2, x25, #2
  2d2398: 8b1c0921     	add	x1, x9, x28, lsl #2
  2d239c: aa1503e0     	mov	x0, x21
  2d23a0: 94054804     	bl	0x4243b0 <memcpy>
  2d23a4: 3dc01680     	ldr	q0, [x20, #0x50]
  2d23a8: 4e080f21     	dup	v1.2d, x25
  2d23ac: 52800028     	mov	w8, #0x1                // =1
  2d23b0: f9001359     	str	x25, [x26, #0x20]
  2d23b4: b9002b5f     	str	wzr, [x26, #0x28]
  2d23b8: f0fff9a9     	adrp	x9, 0x209000 <GCC_except_table27+0x30>
  2d23bc: b9000348     	str	w8, [x26]
  2d23c0: 4ee18400     	add	v0.2d, v0.2d, v1.2d
  2d23c4: 3dc15921     	ldr	q1, [x9, #0x560]
  2d23c8: 3d801680     	str	q0, [x20, #0x50]
  2d23cc: f9401688     	ldr	x8, [x20, #0x28]
  2d23d0: a900a353     	stp	x19, x8, [x26, #0x8]
  2d23d4: 3c848341     	stur	q1, [x26, #0x48]
  2d23d8: 0f03f600     	fmov	v0.2s, #1.00000000
  2d23dc: fd002f40     	str	d0, [x26, #0x58]
  2d23e0: aa1b03e8     	mov	x8, x27
  2d23e4: a94087e3     	ldp	x3, x1, [sp, #0x8]
  2d23e8: f9400fe0     	ldr	x0, [sp, #0x18]
  2d23ec: eb01007f     	cmp	x3, x1
  2d23f0: 54fff6c3     	b.lo	0x2d22c8 <_RINvMNtNtCs7ys7bBRmuYo_10rt_runtime8executor13compact_audioNtB3_7Program6sourceNtNtB7_11host_buffer13BufferedAudioECscZZpAVW0qT6_15shoop_rt_engine+0x48>
  2d23f4: d0000ba2     	adrp	x2, 0x448000 <anon.bcafb2c4894b3d61fa60275ecf34fff3.2.llvm.12558883938082668761>
  2d23f8: 9100c042     	add	x2, x2, #0x30
  2d23fc: aa0303e0     	mov	x0, x3
  2d2400: 94056266     	bl	0x42ad98 <_RNvNtCs8l20omZJ7ql_4core9panicking18panic_bounds_check>
  2d2404: 5280002a     	mov	w10, #0x1               // =1
  2d2408: 3607fc2a     	tbz	w10, #0x0, 0x2d238c <_RINvMNtNtCs7ys7bBRmuYo_10rt_runtime8executor13compact_audioNtB3_7Program6sourceNtNtB7_11host_buffer13BufferedAudioECscZZpAVW0qT6_15shoop_rt_engine+0x10c>
  2d240c: d0000ba3     	adrp	x3, 0x448000 <anon.bcafb2c4894b3d61fa60275ecf34fff3.2.llvm.12558883938082668761>
  2d2410: 91006063     	add	x3, x3, #0x18
  2d2414: aa1c03e0     	mov	x0, x28
  2d2418: 940565d9     	bl	0x42bb7c <_RNvNtNtCs8l20omZJ7ql_4core5slice5index16slice_index_fail>
  2d241c: d0000ba2     	adrp	x2, 0x448000 <anon.bcafb2c4894b3d61fa60275ecf34fff3.2.llvm.12558883938082668761>
  2d2420: 91000042     	add	x2, x2, #0x0
  2d2424: aa1703e0     	mov	x0, x23
  2d2428: aa1903e1     	mov	x1, x25
  2d242c: 940570cd     	bl	0x42e760 <_RNvNvNtCs8l20omZJ7ql_4core5slice20copy_from_slice_impl17len_mismatch_fail>
  2d2430: b0000ba2     	adrp	x2, 0x447000 <anon.64567ba28f81483a79abd500bbbbd9e0.4.llvm.14380489237398986088+0x5b8>
  2d2434: 913fa042     	add	x2, x2, #0xfe8
  2d2438: aa0303e0     	mov	x0, x3
  2d243c: 94056257     	bl	0x42ad98 <_RNvNtCs8l20omZJ7ql_4core9panicking18panic_bounds_check>
