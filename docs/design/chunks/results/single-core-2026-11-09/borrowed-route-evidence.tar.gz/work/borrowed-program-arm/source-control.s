
work/pi5-audio-bench/audio-bench-packed-descriptors:	file format elf64-littleaarch64

Disassembly of section .text:

00000000002f7a60 <_RINvMNtNtCs7ys7bBRmuYo_10rt_runtime8executor13compact_audioNtB3_7Program6sourceNtNtB7_11host_buffer13BufferedAudioECscZZpAVW0qT6_15shoop_rt_engine>:
  2f7a60: d10243ff     	sub	sp, sp, #0x90
  2f7a64: a9037bfd     	stp	x29, x30, [sp, #0x30]
  2f7a68: a9046ffc     	stp	x28, x27, [sp, #0x40]
  2f7a6c: a90567fa     	stp	x26, x25, [sp, #0x50]
  2f7a70: a9065ff8     	stp	x24, x23, [sp, #0x60]
  2f7a74: a90757f6     	stp	x22, x21, [sp, #0x70]
  2f7a78: a9084ff4     	stp	x20, x19, [sp, #0x80]
  2f7a7c: 9100c3fd     	add	x29, sp, #0x30
  2f7a80: a9472413     	ldp	x19, x9, [x0, #0x70]
  2f7a84: eb090036     	subs	x22, x1, x9
  2f7a88: 54000103     	b.lo	0x2f7aa8 <_RINvMNtNtCs7ys7bBRmuYo_10rt_runtime8executor13compact_audioNtB3_7Program6sourceNtNtB7_11host_buffer13BufferedAudioECscZZpAVW0qT6_15shoop_rt_engine+0x48>
  2f7a8c: eb13003f     	cmp	x1, x19
  2f7a90: 54000ca2     	b.hs	0x2f7c24 <_RINvMNtNtCs7ys7bBRmuYo_10rt_runtime8executor13compact_audioNtB3_7Program6sourceNtNtB7_11host_buffer13BufferedAudioECscZZpAVW0qT6_15shoop_rt_engine+0x1c4>
  2f7a94: f9403409     	ldr	x9, [x0, #0x68]
  2f7a98: 52800c0a     	mov	w10, #0x60              // =96
  2f7a9c: 9b0a243b     	madd	x27, x1, x10, x9
  2f7aa0: f9402b69     	ldr	x9, [x27, #0x50]
  2f7aa4: b4000289     	cbz	x9, 0x2f7af4 <_RINvMNtNtCs7ys7bBRmuYo_10rt_runtime8executor13compact_audioNtB3_7Program6sourceNtNtB7_11host_buffer13BufferedAudioECscZZpAVW0qT6_15shoop_rt_engine+0x94>
  2f7aa8: eb13003f     	cmp	x1, x19
  2f7aac: 540009c2     	b.hs	0x2f7be4 <_RINvMNtNtCs7ys7bBRmuYo_10rt_runtime8executor13compact_audioNtB3_7Program6sourceNtNtB7_11host_buffer13BufferedAudioECscZZpAVW0qT6_15shoop_rt_engine+0x184>
  2f7ab0: f9403409     	ldr	x9, [x0, #0x68]
  2f7ab4: 52800c0a     	mov	w10, #0x60              // =96
  2f7ab8: 9b0a2429     	madd	x9, x1, x10, x9
  2f7abc: ad420520     	ldp	q0, q1, [x9, #0x40]
  2f7ac0: ad020500     	stp	q0, q1, [x8, #0x40]
  2f7ac4: ad400520     	ldp	q0, q1, [x9]
  2f7ac8: ad000500     	stp	q0, q1, [x8]
  2f7acc: ad410520     	ldp	q0, q1, [x9, #0x20]
  2f7ad0: ad010500     	stp	q0, q1, [x8, #0x20]
  2f7ad4: a9484ff4     	ldp	x20, x19, [sp, #0x80]
  2f7ad8: a94757f6     	ldp	x22, x21, [sp, #0x70]
  2f7adc: a9465ff8     	ldp	x24, x23, [sp, #0x60]
  2f7ae0: a94567fa     	ldp	x26, x25, [sp, #0x50]
  2f7ae4: a9446ffc     	ldp	x28, x27, [sp, #0x40]
  2f7ae8: a9437bfd     	ldp	x29, x30, [sp, #0x30]
  2f7aec: 910243ff     	add	sp, sp, #0x90
  2f7af0: d65f03c0     	ret
  2f7af4: aa0303f9     	mov	x25, x3
  2f7af8: aa0403f7     	mov	x23, x4
  2f7afc: a90103e1     	stp	x1, x0, [sp, #0x10]
  2f7b00: aa0803fc     	mov	x28, x8
  2f7b04: d10043a8     	sub	x8, x29, #0x10
  2f7b08: aa0203f5     	mov	x21, x2
  2f7b0c: aa0203e0     	mov	x0, x2
  2f7b10: aa0503fa     	mov	x26, x5
  2f7b14: aa0503e1     	mov	x1, x5
  2f7b18: 9403629a     	bl	0x3d0580 <_RNvMs2_NtCs7ys7bBRmuYo_10rt_runtime10audio_refsNtB5_11RenderArena8allocate>
  2f7b1c: 385f03a8     	ldurb	w8, [x29, #-0x10]
  2f7b20: 340000c8     	cbz	w8, 0x2f7b38 <_RINvMNtNtCs7ys7bBRmuYo_10rt_runtime8executor13compact_audioNtB3_7Program6sourceNtNtB7_11host_buffer13BufferedAudioECscZZpAVW0qT6_15shoop_rt_engine+0xd8>
  2f7b24: 385f13a8     	ldurb	w8, [x29, #-0xf]
  2f7b28: 39001388     	strb	w8, [x28, #0x4]
  2f7b2c: 12800008     	mov	w8, #-0x1               // =-1
  2f7b30: b9000388     	str	w8, [x28]
  2f7b34: 17ffffe8     	b	0x2f7ad4 <_RINvMNtNtCs7ys7bBRmuYo_10rt_runtime8executor13compact_audioNtB3_7Program6sourceNtNtB7_11host_buffer13BufferedAudioECscZZpAVW0qT6_15shoop_rt_engine+0x74>
  2f7b38: f85f83b4     	ldur	x20, [x29, #-0x8]
  2f7b3c: aa1503e0     	mov	x0, x21
  2f7b40: aa1403e1     	mov	x1, x20
  2f7b44: aa1a03e2     	mov	x2, x26
  2f7b48: 940361ea     	bl	0x3d02f0 <_RNvMs2_NtCs7ys7bBRmuYo_10rt_runtime10audio_refsNtB5_11RenderArena6output>
  2f7b4c: f90007e0     	str	x0, [sp, #0x8]
  2f7b50: aa0103f8     	mov	x24, x1
  2f7b54: aa1903e0     	mov	x0, x25
  2f7b58: aa1603e1     	mov	x1, x22
  2f7b5c: 94037c15     	bl	0x3d6bb0 <_RNvXs_NtCs7ys7bBRmuYo_10rt_runtime11host_bufferNtB4_13BufferedAudioNtB4_7AudioIo5input>
  2f7b60: aa0003e9     	mov	x9, x0
  2f7b64: aa0103e2     	mov	x2, x1
  2f7b68: ab170341     	adds	x1, x26, x23
  2f7b6c: 1a9f37eb     	cset	w11, hs
  2f7b70: eb02003f     	cmp	x1, x2
  2f7b74: 1a9f97ea     	cset	w10, hi
  2f7b78: 3700040b     	tbnz	w11, #0x0, 0x2f7bf8 <_RINvMNtNtCs7ys7bBRmuYo_10rt_runtime8executor13compact_audioNtB3_7Program6sourceNtNtB7_11host_buffer13BufferedAudioECscZZpAVW0qT6_15shoop_rt_engine+0x198>
  2f7b7c: 3500042a     	cbnz	w10, 0x2f7c00 <_RINvMNtNtCs7ys7bBRmuYo_10rt_runtime8executor13compact_audioNtB3_7Program6sourceNtNtB7_11host_buffer13BufferedAudioECscZZpAVW0qT6_15shoop_rt_engine+0x1a0>
  2f7b80: eb1a031f     	cmp	x24, x26
  2f7b84: 54000461     	b.ne	0x2f7c10 <_RINvMNtNtCs7ys7bBRmuYo_10rt_runtime8executor13compact_audioNtB3_7Program6sourceNtNtB7_11host_buffer13BufferedAudioECscZZpAVW0qT6_15shoop_rt_engine+0x1b0>
  2f7b88: d37ef742     	lsl	x2, x26, #2
  2f7b8c: 8b170921     	add	x1, x9, x23, lsl #2
  2f7b90: f94007e0     	ldr	x0, [sp, #0x8]
  2f7b94: 9404b2bf     	bl	0x424690 <memcpy>
  2f7b98: 3dc016a0     	ldr	q0, [x21, #0x50]
  2f7b9c: 4e080f41     	dup	v1.2d, x26
  2f7ba0: d0fff888     	adrp	x8, 0x209000 <GCC_except_table27+0x24>
  2f7ba4: 3dc15d02     	ldr	q2, [x8, #0x570]
  2f7ba8: 4ee18400     	add	v0.2d, v0.2d, v1.2d
  2f7bac: f94016a8     	ldr	x8, [x21, #0x28]
  2f7bb0: 3d8016a0     	str	q0, [x21, #0x50]
  2f7bb4: 52800029     	mov	w9, #0x1                // =1
  2f7bb8: b9000369     	str	w9, [x27]
  2f7bbc: a900a374     	stp	x20, x8, [x27, #0x8]
  2f7bc0: f900137a     	str	x26, [x27, #0x20]
  2f7bc4: b9002b7f     	str	wzr, [x27, #0x28]
  2f7bc8: 3c848362     	stur	q2, [x27, #0x48]
  2f7bcc: 0f03f600     	fmov	v0.2s, #1.00000000
  2f7bd0: fd002f60     	str	d0, [x27, #0x58]
  2f7bd4: aa1c03e8     	mov	x8, x28
  2f7bd8: a94103e1     	ldp	x1, x0, [sp, #0x10]
  2f7bdc: eb13003f     	cmp	x1, x19
  2f7be0: 54fff683     	b.lo	0x2f7ab0 <_RINvMNtNtCs7ys7bBRmuYo_10rt_runtime8executor13compact_audioNtB3_7Program6sourceNtNtB7_11host_buffer13BufferedAudioECscZZpAVW0qT6_15shoop_rt_engine+0x50>
  2f7be4: b0000a82     	adrp	x2, 0x448000 <anon.83ecedf443f527829d2a3570e9703806.1.llvm.8297356532008781232+0x50>
  2f7be8: 912ea042     	add	x2, x2, #0xba8
  2f7bec: aa0103e0     	mov	x0, x1
  2f7bf0: aa1303e1     	mov	x1, x19
  2f7bf4: 9404cd21     	bl	0x42b078 <_RNvNtCs8l20omZJ7ql_4core9panicking18panic_bounds_check>
  2f7bf8: 5280002a     	mov	w10, #0x1               // =1
  2f7bfc: 34fffc2a     	cbz	w10, 0x2f7b80 <_RINvMNtNtCs7ys7bBRmuYo_10rt_runtime8executor13compact_audioNtB3_7Program6sourceNtNtB7_11host_buffer13BufferedAudioECscZZpAVW0qT6_15shoop_rt_engine+0x120>
  2f7c00: b0000a83     	adrp	x3, 0x448000 <anon.83ecedf443f527829d2a3570e9703806.1.llvm.8297356532008781232+0x50>
  2f7c04: 912e4063     	add	x3, x3, #0xb90
  2f7c08: aa1703e0     	mov	x0, x23
  2f7c0c: 9404d094     	bl	0x42be5c <_RNvNtNtCs8l20omZJ7ql_4core5slice5index16slice_index_fail>
  2f7c10: b0000a82     	adrp	x2, 0x448000 <anon.83ecedf443f527829d2a3570e9703806.1.llvm.8297356532008781232+0x50>
  2f7c14: 912de042     	add	x2, x2, #0xb78
  2f7c18: aa1803e0     	mov	x0, x24
  2f7c1c: aa1a03e1     	mov	x1, x26
  2f7c20: 9404db88     	bl	0x42ea40 <_RNvNvNtCs8l20omZJ7ql_4core5slice20copy_from_slice_impl17len_mismatch_fail>
  2f7c24: b0000a82     	adrp	x2, 0x448000 <anon.83ecedf443f527829d2a3570e9703806.1.llvm.8297356532008781232+0x50>
  2f7c28: 912d8042     	add	x2, x2, #0xb60
  2f7c2c: aa0103e0     	mov	x0, x1
  2f7c30: aa1303e1     	mov	x1, x19
  2f7c34: 9404cd11     	bl	0x42b078 <_RNvNtCs8l20omZJ7ql_4core9panicking18panic_bounds_check>
		...
