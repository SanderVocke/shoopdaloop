from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();base=json.loads(Path('work/pgo-host/balanced.json').read_text())
hashes={p:h(p) for p in base['all_workspace_rust_hashes']};changed=[p for p,sha in base['all_workspace_rust_hashes'].items() if hashes[p]!=sha];assert changed==['src/rust/rt_runtime/src/executor_compact.rs'],changed
assert h('Cargo.lock')==base['cargo_lock_sha256'];assert subprocess.check_output(['rustc','-Vv'],text=True)==base['rustc'];assert not os.environ.get('RUSTFLAGS')
profile=Path('work/pgo-host/normal-host.profdata');training=json.loads(Path('work/pgo-host/training.json').read_text());assert h(profile)==training['merged_sha256']
env={**os.environ,**{k:v for k,v in base['flags'].items() if v}};env.pop('CARGO_ENCODED_RUSTFLAGS',None);assert env['RUSTFLAGS'].startswith('-Cprofile-use=')
for c in ['rt_runtime','shoop_loops','shoop_rt_engine','shoop_host']:os.utime(f'src/rust/{c}/src/lib.rs',None)
out=Path('work/host-borrowed-program-pgo');out.mkdir(exist_ok=True);start=time.monotonic()
with (out/'build.log').open('w') as f:subprocess.run(base['command'],env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
assert hashes=={p:h(p) for p in hashes};dest=Path('work/bin/host-borrowed-program-pgo-v2');assert not dest.exists();shutil.copyfile('target/release/shoop_host',dest);shutil.copymode('target/release/shoop_host',dest)
info=dict(base,variant='borrowed-program-pgo',all_workspace_rust_hashes=hashes,all_crate_rust_hashes={p:hashes[p] for p in base['all_crate_rust_hashes']},source_hashes={p:h(p) for p in set(base['source_hashes'])|set(changed)},binary=str(dest),binary_sha256=h(dest),binary_bytes=dest.stat().st_size,build_seconds=time.monotonic()-start,profile_sha256=h(profile),profile_note='Same training data as control, not retrained for this source change')
(out/'build.json').write_text(json.dumps(info,indent=2)+'\n');print(info['binary_sha256'],info['binary_bytes'],flush=True)
