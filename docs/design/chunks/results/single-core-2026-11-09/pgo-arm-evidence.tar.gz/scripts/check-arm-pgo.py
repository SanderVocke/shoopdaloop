import csv,hashlib,json,math,os,subprocess
from pathlib import Path
os.sched_setaffinity(0,{0});out=Path('work/pgo-arm');manifest=json.loads((out/'balanced.json').read_text());control=json.loads(Path('work/pi5-audio-bench/builds.json').read_text())['variants']['packed-thin-one']
bins={'control':Path('work/pi5-audio-bench')/control['binary'],'pgo':Path(manifest['binary'])}
assert hashlib.sha256(bins['pgo'].read_bytes()).hexdigest()==manifest['binary_sha256']
assert hashlib.sha256(bins['control'].read_bytes()).hexdigest()==control['binary_sha256']
rows=[]
for mode in ['current','chunks','chunks-descriptors','compact']:
 for scenario in ['idle','play','record']:
  for buffer in [32,256]:
   checks=[]
   for name,binary in bins.items():
    args=['work/qemu/qemu-aarch64','-cpu','cortex-a76',str(binary),mode,scenario,str(buffer),'1','4','48000']
    r=next(csv.DictReader(subprocess.check_output(args,text=True).splitlines()))
    r={k:r[k] for k in ['mode','scenario','buffer','tracks','callbacks','checksum','arena_materializations']}
    checks.append(r);rows.append(dict(r,candidate=name))
   assert checks[0]==checks[1],checks
   print('ARM correctness matched',mode,scenario,buffer,flush=True)
(out/'correctness.json').write_text(json.dumps(dict(purpose='ARM functional equivalence only; all emulator timing fields discarded',cases=24,binary_sha256={n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in bins.items()},rows=rows),indent=2)+'\n')
