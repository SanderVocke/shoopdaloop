from pathlib import Path
import hashlib,json,shutil,tarfile
root=Path.cwd();out=Path('work/pi5-audio-bench');m=json.loads((out/'builds.json').read_text());control=m['variants']['packed-thin-one'];h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
pgo=json.loads(Path('work/pgo-arm/balanced.json').read_text());checks=json.loads(Path('work/pgo-arm/correctness.json').read_text());train=json.loads(Path('work/pgo-arm/training.json').read_text())
assert checks['cases']==24 and checks['binary_sha256']['pgo']==pgo['binary_sha256']
assert all(h(p)==v for p,v in pgo['all_crate_rust_hashes'].items())
assert h(pgo['binary'])==pgo['binary_sha256']
assert h('work/pgo-arm/balanced.profdata')==train['merged_sha256']
name='packed-pgo';dst=out/('audio-bench-'+name);assert not dst.exists()
shutil.copyfile(pgo['binary'],dst);shutil.copymode(pgo['binary'],dst)
b=dst.read_bytes();assert b[:6]==b'\x7fELF\x02\x01' and int.from_bytes(b[18:20],'little')==183
start=int.from_bytes(b[32:40],'little');size=int.from_bytes(b[54:56],'little');count=int.from_bytes(b[56:58],'little');assert all(int.from_bytes(b[start+i*size:start+i*size+4],'little')!=3 for i in range(count))
profile=out/'profiles/packed-pgo.profdata';profile.parent.mkdir(exist_ok=True);shutil.copyfile('work/pgo-arm/balanced.profdata',profile)
shutil.copyfile('work/pgo-arm/training.json',out/'PGO_TRAINING.json');shutil.copyfile('work/pgo-arm/correctness.json',out/'PGO_ARM_CHECKS.json')
m['variants'][name]=dict(control,binary=dst.name,binary_sha256=h(dst),binary_bytes=len(b),rustflags=pgo['flags']['RUSTFLAGS'],pgo_profile='profiles/packed-pgo.profdata',pgo_profile_sha256=h(profile),pgo_training='PGO_TRAINING.json',pgo_correctness='PGO_ARM_CHECKS.json',measurement_status='No real Pi performance measurement; ARM execution counts trained under QEMU; emulator timings discarded')
(out/'builds.json').write_text(json.dumps(m,indent=2)+'\n')
p=out/'README.txt';p.write_text(p.read_text()+'''
packed-pgo uses the same packed source and ThinLTO/CGU1 with a separately trained
ARM PGO profile. Its execution counts came from 24 Cortex-A76 emulated training
cases across all four modes and three scenarios at buffers32/256. Emulator timings
are discarded. 24 further ARM checks match the previous thin/one sample/capture
results at an untrained track density. No real Pi speedup has been measured.
The target profile and its training hashes are included for reproduction; adjust
-Cprofile-use to the included profiles/packed-pgo.profdata when rebuilding.
Native x86 PGO improved offline medians but does not establish this ARM ranking.
''')
with tarfile.open('work/pi5-audio-bench.tar.gz','w:gz') as tar:tar.add(out,arcname='pi5-audio-bench')
print(name,h(dst),len(b),flush=True)
