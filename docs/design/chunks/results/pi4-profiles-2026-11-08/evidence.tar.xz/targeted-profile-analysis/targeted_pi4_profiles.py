#!/usr/bin/env python3
import argparse, csv, hashlib, json, math, os, platform, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'scripts'))
from benchmark_audio_chunks import configure_render, render_thread, summarize

MODES = ('current', 'chunks', 'chunks-descriptors')


def read(path):
    try: return Path(path).read_text().strip()
    except OSError: return None


def run_text(cmd):
    return subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT).stdout


def snapshot(out, perf):
    cg = Path('/sys/fs/cgroup')
    rel = read('/proc/self/cgroup').split(':')[-1] if read('/proc/self/cgroup') else '/'
    current = cg / rel.lstrip('/')
    ancestors=[]
    p=current
    while True:
        item={'path':str(p)}
        for name in ('cpu.max','cpu.stat','cpu.weight','cpu.rt_runtime_us','cpu.rt_period_us','cpuset.cpus','cpuset.cpus.effective'):
            item[name]=read(p/name)
        ancestors.append(item)
        if p == cg: break
        p=p.parent
    settings={
      'captured_utc': run_text(['date','-u','+%Y-%m-%dT%H:%M:%SZ']).strip(),
      'uname': run_text(['uname','-a']).strip(), 'platform':platform.platform(),
      'affinity':sorted(os.sched_getaffinity(0)), 'proc_cgroup':read('/proc/self/cgroup'),
      'sched_rt_runtime_us':read('/proc/sys/kernel/sched_rt_runtime_us'),
      'sched_rt_period_us':read('/proc/sys/kernel/sched_rt_period_us'),
      'perf_event_paranoid':read('/proc/sys/kernel/perf_event_paranoid'),
      'kptr_restrict':read('/proc/sys/kernel/kptr_restrict'),
      'isolated':read('/sys/devices/system/cpu/isolated'),
      'realtime':read('/sys/kernel/realtime'), 'cgroup_ancestors':ancestors,
      'cpu_governors':{str(i):read(f'/sys/devices/system/cpu/cpu{i}/cpufreq/scaling_governor') for i in range(4)},
      'cpu_frequency_khz':{str(i):read(f'/sys/devices/system/cpu/cpu{i}/cpufreq/scaling_cur_freq') for i in range(4)},
    }
    (out/'settings.json').write_text(json.dumps(settings,indent=2)+'\n')
    for name,cmd in {
      'perf-version.txt':[perf,'--version'], 'perf-list.txt':[perf,'list'],
      'lscpu.txt':['lscpu'], 'proc-cmdline.txt':['sh','-c','cat /proc/cmdline'],
      'interrupts.txt':['sh','-c','cat /proc/interrupts'],
    }.items(): (out/name).write_text(run_text(cmd))


def stop_host(pid, host, directory):
    if not pid:return
    try:
        if (Path('/proc')/str(pid)/'exe').resolve()==host and str(directory/'config.json').encode() in (Path('/proc')/str(pid)/'cmdline').read_bytes(): os.kill(pid,15)
    except (OSError,ProcessLookupError): pass


def one(args, kind, mode, scenario, buffer, memory, duration):
    label=f'{scenario}-b{buffer}-{"memory" if memory else "none"}'
    d=args.output/kind/label/mode; d.mkdir(parents=True,exist_ok=False)
    worker=None; proc=None; host_pid=None
    if memory:
        worker=subprocess.Popen([sys.executable,str(ROOT/'scripts/benchmark_audio_chunks.py'),'--worker','memory','--load-cpu','2'])
    callbacks=math.ceil((args.settle+duration+6)*48000/buffer)
    launch=['taskset','-c','0',str(args.launcher),'--host',str(args.host),'--mode',mode,
      '--scenario',scenario,'--input','signal','--callbacks',str(callbacks),'--warmup','0.5',
      '--output',str(d),'--buffer',str(buffer),'--quantum','32','--voices','4','--loops','16','--tracks','4']
    meta={'kind':kind,'mode':mode,'scenario':scenario,'buffer':buffer,'memory_pressure':memory,
          'duration_s':duration,'launcher_command':launch}
    try:
      with (d/'launcher.log').open('w') as log:
        started=time.monotonic(); proc=subprocess.Popen(launch,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        host_pid,tid=render_thread(proc.pid,started+40)
        meta['scheduling']=configure_render(host_pid,tid,d,1,80); meta['host_pid']=host_pid;meta['render_tid']=tid
        time.sleep(max(0,args.settle-(time.monotonic()-started)))
        if proc.poll() is not None: raise RuntimeError('launcher ended before profiling')
        env=os.environ.copy();env['DEBUGINFOD_URLS']=''
        if kind=='dwarf':
          cmd=['taskset','-c','0',args.perf,'record','--per-thread','--no-inherit','--no-bpf-event',
               '--no-kernel-callchains','--user-callchains','-e','cpu-clock:u','-F',str(args.frequency),'-T',
               '--call-graph',f'dwarf,{args.stack_bytes}','-t',str(tid),'-o',str(d/'perf.data'),'--','sleep',str(duration)]
        elif kind=='sched':
          cmd=['taskset','-c','0',args.perf,'sched','record','-a','-C','1','-o',str(d/'perf-sched.data'),'--','sleep',str(duration)]
        else:
          cmd=['taskset','-c','0',args.perf,'stat','-x,','--no-big-num','-e',args.events,'-t',str(tid),'-o',str(d/'perf-stat.csv'),'--','sleep',str(duration)]
        meta['profile_command']=cmd;meta['profile_start_monotonic']=time.monotonic();
        with (d/'perf.log').open('w') as plog: subprocess.run(cmd,env=env,stdout=plog,stderr=subprocess.STDOUT,check=True)
        meta['profile_end_monotonic']=time.monotonic()
        rc=proc.wait(timeout=240)
        if rc: raise RuntimeError(f'launcher exited {rc}')
        summary=summarize(d);meta['validation']={k:summary[k] for k in ('callbacks','p50_us','p99_us','max_us','overruns','dropped')}
        if kind=='dwarf':
          script=[args.perf,'script','-i',str(d/'perf.data'),'--no-demangle','-F','comm,tid,time,period,ip,sym,dso']
          with (d/'perf-script.txt').open('w') as f: subprocess.run(script,env=env,stdout=f,stderr=subprocess.PIPE,text=True,check=True)
          report=[args.perf,'report','-i',str(d/'perf.data'),'--stdio','--no-children','--percent-limit','0.1']
          with (d/'perf-report.txt').open('w') as f: subprocess.run(report,env=env,stdout=f,stderr=subprocess.STDOUT,text=True,check=True)
        elif kind=='sched':
          with (d/'sched-timehist.txt').open('w') as f: subprocess.run([args.perf,'sched','timehist','-i',str(d/'perf-sched.data'),'--state'],stdout=f,stderr=subprocess.STDOUT,text=True,check=True)
          with (d/'sched-script.txt').open('w') as f: subprocess.run([args.perf,'script','-i',str(d/'perf-sched.data'),'-F','time,cpu,comm,pid,tid,event,trace'],stdout=f,stderr=subprocess.STDOUT,text=True,check=True)
        (d/'profile.json').write_text(json.dumps(meta,indent=2)+'\n')
        print(kind,label,mode,'OK',flush=True)
    finally:
      if proc and proc.poll() is None:
        try: os.killpg(proc.pid,15);proc.wait(timeout=8)
        except Exception:
          try: os.killpg(proc.pid,9);proc.wait()
          except Exception: pass
      stop_host(host_pid,args.host,d)
      if worker:
        worker.terminate()
        try:worker.wait(timeout=5)
        except subprocess.TimeoutExpired:worker.kill();worker.wait()


def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--host',type=Path,required=True);p.add_argument('--launcher',type=Path,required=True);p.add_argument('--perf',default='/usr/bin/perf');p.add_argument('--settle',type=float,default=8);p.add_argument('--frequency',type=int,default=997);p.add_argument('--stack-bytes',type=int,default=32768);p.add_argument('--events',default='cycles,instructions,armv8_cortex_a72/l1d_cache_refill/,armv8_cortex_a72/l2d_cache_refill/');a=p.parse_args()
 a.output=a.output.resolve();a.host=a.host.resolve();a.launcher=a.launcher.resolve();a.output.mkdir(parents=True,exist_ok=False);snapshot(a.output,a.perf)
 # Timestamped render-thread DWARF stacks.
 for mode in MODES:
  one(a,'dwarf',mode,'shared',256,False,20)
  one(a,'dwarf',mode,'play',256,False,15)
  one(a,'dwarf',mode,'play',256,True,15)
 # Scheduler traces for the 32-frame ~50 ms stalls.
 for mode in MODES: one(a,'sched',mode,'play',32,True,10)
 # Separate PMU runs so counter collection does not contaminate timing or DWARF captures.
 for mode in MODES:
  one(a,'stat',mode,'shared',256,False,15)
  one(a,'stat',mode,'play',256,False,15)
  one(a,'stat',mode,'play',256,True,15)

if __name__=='__main__':main()
