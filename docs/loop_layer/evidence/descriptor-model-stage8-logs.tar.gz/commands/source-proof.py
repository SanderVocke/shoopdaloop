import hashlib
import json
from pathlib import Path
import subprocess

root = Path.cwd()
out = root / "target/loop-layer-descriptor-model-stage8"
base = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
assert base == "275d58cd3c1c055311e35bb5547a775bfcbb73aa"
scoped = [
    "scripts/run_rt_runtime_miri.py",
    "scripts/tests/test_rt_runtime_miri.py",
    "scripts/tests/test_rt_runtime_miri_batches.py",
    "tests/loop_engine_host/README.md",
    "tests/loop_engine_host/src/graph_transfer.rs",
]
new = "tests/loop_engine_host/src/graph_transfer/model.rs"
patch = subprocess.check_output(["git", "diff", "--binary", base, "--", *scoped])
addition = subprocess.run(["git", "diff", "--no-index", "--binary", "/dev/null", new], capture_output=True)
assert addition.returncode == 1 and not addition.stderr
(out / "implementation.patch").write_bytes(patch + addition.stdout)
for path in ["src/rust/rt_runtime/src", "src/rust/shoop_loop_engine/src"]:
    subprocess.run(["git", "diff", "--exit-code", base, "--", path], check=True, capture_output=True)
parent = "tests/loop_engine_host/src/graph_transfer.rs"
old = subprocess.check_output(["git", "show", f"{base}:{parent}"], text=True)
now = Path(parent).read_text()
assert now == old.replace("#[cfg(test)]\npub(crate) mod tests;", "#[cfg(test)]\nmod model;\n#[cfg(test)]\npub(crate) mod tests;")
status = json.loads((out / "consolidated-miri-status.json").read_text())
assert status["status"] == "running" and status["commit"] == "3bf1dbca7c93f486be50cd7359555172dad723f3"
files = scoped + [new]
proof = {
    "base": base,
    "dirty": True,
    "reproducible_patch": "implementation.patch",
    "patch_sha256": hashlib.sha256((out / "implementation.patch").read_bytes()).hexdigest(),
    "runtime_and_loop_production_sources_unchanged": True,
    "fixture_parent_change": "Only cfg(test) module registration; no production callback body changed.",
    "files": {path: hashlib.sha256(Path(path).read_bytes()).hexdigest() for path in files},
    "miri_checkpoint": {**status, "observed_at": "2026-10-28T17:05:49Z"},
    "limitations": "Native model/source/inventory evidence only. No new interpreter, Wasm build/unit, actual-worklet, benchmark, or remote acceptance claimed.",
}
(out / "source-proof.json").write_text(json.dumps(proof, indent=2) + "\n")
print(json.dumps(proof, indent=2))
