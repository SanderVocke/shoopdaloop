import hashlib
import json
from pathlib import Path
import re
from collections import Counter
from datetime import datetime, timezone

out = Path('target/loop-layer-callback-audit-stage8')
source = json.loads((out / 'source-and-assets.json').read_text())
native_log = (out / 'native-gates.log').read_text()
summaries = [tuple(map(int, row)) for row in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', native_log)]
assert summaries and all(row[1:] == (0, 0, 0, 0) for row in summaries)
assert sum(row[0] for row in summaries) >= 2 * (191 + 153 + 59)
assert 'Ran 72 tests' in native_log and '\nOK\n' in native_log
assert 'Tracing coverage inventory: 207 modules' in native_log
assert 'Shoop test attribute policy: ok' in native_log
assert native_log.count('production/build boundary: ok') == 8
cases = {}
for name, expected in [('native', {'rt_runtime': 191, 'shoop_loop_engine': 153}),
                       ('fixture', {'loop_engine_host_fixture': 59})]:
    document = json.loads((out / f'{name}-discovery.json').read_text())
    counts = Counter()
    for suite in document['rust-suites'].values():
        for test, properties in suite['testcases'].items():
            assert properties['ignored'] is False
            counts[suite['package-name']] += 1
            cases.setdefault(suite['package-name'], []).append(f"{suite['binary-name']}::{test}")
    assert dict(counts) == expected
    assert document['test-count'] == sum(expected.values())

required = {
    'rt_runtime': [
        'dense_planning_uses_one_callback_envelope_without_subrange_quota',
        'ingress_and_recycled_results_wait_until_the_next_callback_not_next_interval',
        'resource_allowances_are_not_replenished_by_planning_or_internal_intervals',
        'required_render_access_and_diagnostics_share_one_callback_envelope',
        'malformed_intervals_and_changed_view_storage_fault_before_consumers',
        'invalid_completion_returns_the_owned_retirement_bundle',
        'control_disconnect_retains_payloads_until_non_render_shutdown',
        'render_disconnect_rejects_new_ownership_and_reclaims_every_queue_on_stop',
        'two_thread_stress_keeps_completion_and_state_publication_coherent',
        'prepared_executor_ingress_recycles_owning_chunk_buffers_without_heap_operations',
        'refused_permits_stale_catalog_epochs_and_stage_generations_preserve_both_owners',
        'incremental_validation_and_malformed_or_cancelled_envelopes_never_publish_early',
        'unread_results_and_retired_graphs_do_not_gate_music_and_recovery_cannot_activate',
        'generated_capture_ownership_matches_independent_pool_and_content_model',
        'indexed_reads_match_flat_bytes_for_all_offsets_and_seeded_wraps_without_budget',
        'foreign_and_released_indexes_and_cursors_cannot_alias_reused_slots',
        'unread_normal_results_do_not_block_recovery_or_automatic_intervals',
        'payload_limits_malformed_operations_and_domain_refusal_return_distinct_outcomes'],
    'shoop_loop_engine': [
        'owner_batch_refusals_preserve_every_input_and_do_not_reserve_generation_or_capacity',
        'seeded_owner_activation_model_checks_references_generations_and_retained_media_after_every_edit',
        'malformed_foreign_duplicate_and_unindexed_inputs_return_owners_without_publication',
        'seeded_ownership_model_preserves_every_live_export_and_all_fixed_pool_credits',
        'configuration_refusals_and_final_resolver_failure_leave_all_three_owners_ready',
        'batch_capacity_is_preflighted_without_reusing_retirement_credits_or_publishing_a_prefix',
        'disconnect_and_fault_cleanup_recover_source_receivers_partial_batches_and_published_capture_claims',
        'paired_retirement_unread_results_recovery_disconnect_and_render_fault_preserve_ownership',
        'nested_seek_stop_restart_and_direct_priority_preserve_media_cuts_and_pending_outcomes',
        'heap_guards_are_live_in_optimized_and_wasm_tests'],
    'loop_engine_host_fixture': [
        'unexpected_owning_completion_is_returned_intact_without_recycling_or_fabricating_a_reply',
        'cancelled_owning_chunks_and_128_program_reuses_preserve_real_buffers_and_generations',
        'cancelled_reads_eof_stalls_and_128_export_reuses_return_real_owners',
        'busy_stale_foreign_and_malformed_records_do_not_advance_or_destroy_owners',
        'ingress_refusal_stalled_returns_and_disconnect_keep_all_graph_owners_explicit',
        'all_event_variants_preserve_full_width_fields_and_canonical_padding',
        'loss_is_sticky_saturating_and_empty_callback_cuts_do_not_consume_records']}
correlation = {}
for package, names in required.items():
    correlation[package] = []
    for name in names:
        matched = [case for case in cases[package] if case.rsplit('::', 1)[-1] == name]
        assert len(matched) == 1, (package, name, matched)
        correlation[package].append(matched[0])

commands = json.loads((out / 'guard-commands.json').read_text())
assert len(commands) == 15
canaries = {}
for profile in ('debug', 'release'):
    canaries[profile] = {}
    for index, kind in enumerate(('allocation', 'reallocation', 'deallocation')):
        name = f'canary-{profile}-{kind}.log'
        command = next(command for command in commands if command['log'] == name)
        assert command['expected_failure'] is True and command['exit'] == 101
        text = (out / name).read_text()
        match = re.search(r'left: Counts \{ allocations: (\d+), reallocations: (\d+), deallocations: (\d+) \}', text)
        assert match and 'heap operation during rendering' in text
        counts = list(map(int, match.groups()))
        assert counts[index] > 0 and all(value == 0 for i, value in enumerate(counts) if i != index)
        canaries[profile][kind] = counts

families = ('reports', 'graphReports', 'exportReports', 'stagingReports', 'denseReports',
            'stallReports', 'mediaReports', 'plannerReports')
expected = {'processor': (10, 1, 0, [0, 0, 0], None, None),
            'rust-heap': (4294901761, 2, 0, [4, 20, 4], None, None),
            'graph-processor': (10, 1, 0, [0, 0, 0], None, None),
            'graph-rust-heap': (4294901761, 2, 0, [1, 5, 1], None, None),
            'planner': (10, 0, 3, [0, 0, 0], 1, 0),
            'planner-rust-heap': (4294901761, 0, 4, [1, 5, 1], 128, 128)}
profiles = {}
for profile in ('debug', 'release'):
    result = json.loads((out / f'host-reports/{profile}/result.json').read_text())
    assert result['passed'] is True and result['cross_origin_isolated'] is False
    assert result['source_head'] == source['head'] and result['source_dirty'] is False
    assert result['wasm_sha256'] == source['reused_wasm'][profile]['wasm_sha256']
    assert len(result['bindingChecks']['checks']) == len(result['node']['checks']) == 20
    assert sum(len(result[family]) for family in families) == 16
    assert all(sorted(report['mode'] for report in result[family]) == ['live', 'offline'] for family in families)
    failures = result['failure_canaries']
    assert len(failures) == len(expected) and {f['kind'] for f in failures} == set(expected)
    for failure in failures:
        witness = failure['witness']
        code, processor, planner, heap, plans, finishes = expected[failure['kind']]
        assert failure['exit_code'] == 1
        assert witness['code'] == code and witness['processor'] == processor and witness['planner'] == planner
        assert witness['heap'] == heap and witness['plans'] == plans and witness['finishes'] == finishes
        assert witness['bytes'] > 0 and witness['bytes'] == witness['finalBytes']
    replay = json.loads((out / f'host-reports/native-{profile}/result.json').read_text())
    assert replay['passed'] is True and replay['kind'] == 'native-replay'
    profiles[profile] = {'successful_actual_contexts': 16, 'binding_groups_each_node_chromium': 20,
                         'failure_canaries': failures, 'tools': result['tools'],
                         'wasm_sha256': result['wasm_sha256'],
                         'scope': 'Fresh native/binding/actual execution; verified bulk-candidate Wasm reused, not rebuilt.'}

checkpoint = json.loads(Path('target/loop-layer-consolidated-recovery-stage7/audit-checkpoint-3-status.json').read_text())
assert checkpoint['id'] == '20261028T153110-784d2380c0' and checkpoint['commit'] == source['active_miri_frozen_commit']
assert checkpoint['status'] == 'running'
proof = {'verified_at': datetime.now(timezone.utc).isoformat(), 'head': source['head'],
         'implementation_commit': source['implementation_commit'],
         'native_discovery': {'rt_runtime': 191, 'shoop_loop_engine': 153, 'loop_engine_host_fixture': 59},
         'native_passed_summaries_including_doctests_both_profiles': sum(row[0] for row in summaries),
         'native_ignored_failed_filtered': 0, 'helper_tests': 72,
         'source_identity_inputs': source['input_count'], 'native_heap_canaries': canaries,
         'guard_correlation': correlation, 'profiles': profiles, 'miri_checkpoint': checkpoint,
         'scope': 'Closes the callback source-audit/guard row only. No model-row, consolidated Miri, remote CI, deadline, arbitrary-user-callback or final-plan certification.'}
(out / 'verification.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps({'verified': True, 'native_passed_summaries': proof['native_passed_summaries_including_doctests_both_profiles'],
                  'source_inputs': source['input_count'], 'native_heap_canaries': canaries,
                  'successful_actual_contexts_each_profile': 16, 'actual_failure_gates_each_profile': 6,
                  'miri_status': checkpoint['status']}, indent=2))
