import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone

root = Path.cwd()
out = root / 'target/loop-layer-callback-audit-stage8'
env = os.environ.copy()
env['RUSTFLAGS'] = '-D warnings'
env['RUSTDOCFLAGS'] = '-D warnings'
commands = []

def run(args, name, timeout=600, negative=False):
    start = datetime.now(timezone.utc).isoformat()
    tick = time.monotonic()
    log = out / name
    with log.open('w') as stream:
        stream.write('$ ' + ' '.join(map(str, args)) + '\n')
        stream.flush()
        result = subprocess.run(list(map(str, args)), cwd=root, env=env, stdout=stream,
                                stderr=subprocess.STDOUT, timeout=timeout)
    record = {'command': list(map(str, args)), 'started_at': start,
              'wall_seconds': time.monotonic() - tick, 'exit': result.returncode,
              'log': name, 'expected_failure': negative}
    commands.append(record)
    (out / 'guard-commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    if negative:
        text = log.read_text()
        assert result.returncode != 0 and 'heap operation during rendering' in text, record
        assert 'heap guard did not detect violation' not in text, record
    else:
        assert result.returncode == 0, record
    print(json.dumps(record), flush=True)

for args, name in [(['rustc', '--version'], 'rustc-version.log'),
                   (['cargo', '--version'], 'cargo-version.log'),
                   (['node', '--version'], 'node-version.log'),
                   (['chromium', '--version'], 'chromium-version.log'),
                   (['chromedriver', '--version'], 'chromedriver-version.log')]:
    run(args, name)

binaries = {}
for profile in ('debug', 'release'):
    binary = root / f'target/{profile}/examples/benchmark_loop'
    binaries[profile] = hashlib.sha256(binary.read_bytes()).hexdigest()
    for kind in ('allocation', 'reallocation', 'deallocation'):
        run([binary, '--fail-canary', kind], f'canary-{profile}-{kind}.log', negative=True)
    for native in (True, False):
        kind = 'native-' + profile if native else profile
        current = root / f'target/loop-engine-host/reports/{kind}'
        if current.exists():
            previous = out / f'previous-host-reports/{kind}'
            assert not previous.exists(), previous
            previous.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(current, previous)
        args = [sys.executable, 'scripts/run_loop_engine_hosts.py', '--no-build', '--profile', profile]
        args += ['--native-only'] if native else ['--verify-failures']
        run(args, f'hosts-{kind}.log', timeout=3600)
        target = out / f'host-reports/{kind}'
        assert not target.exists(), target
        shutil.copytree(current, target)
        result = json.loads((target / 'result.json').read_text())
        if not native:
            source = json.loads((out / 'source-and-assets.json').read_text())
            assert result['wasm_sha256'] == source['reused_wasm'][profile]['wasm_sha256']
            assert len(result['failure_canaries']) == 6
            assert len(result['node']['checks']) == 20
        print(json.dumps({'reports': str(target.relative_to(root)), 'keys': list(result)}), flush=True)

(out / 'native-canary-binaries.json').write_text(json.dumps(binaries, indent=2) + '\n')
print('All six native heap canaries and both-profile native/binding/actual-worklet controls passed.', flush=True)
