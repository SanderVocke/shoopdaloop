import hashlib
import json
from pathlib import Path
import subprocess
from datetime import datetime, timezone

root = Path.cwd()
out = root / 'target/loop-layer-callback-audit-stage8'
out.mkdir(parents=True, exist_ok=True)
base = subprocess.check_output(['git', 'rev-parse', '3d10c7a0'], text=True).strip()
frozen = subprocess.check_output(['git', 'rev-parse', '3bf1dbca'], text=True).strip()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
paths = ['Cargo.toml', 'Cargo.lock', '.cargo/config.toml', 'flake.nix',
         'src/rust/rt_runtime/Cargo.toml', 'src/rust/shoop_loop_engine/Cargo.toml',
         'tests/loop_engine_host/Cargo.toml', 'tests/loop_engine_host/Cargo.lock',
         'src/rust/shoop_wasm_test_support/Cargo.toml',
         'scripts/run_loop_engine_hosts.py', 'scripts/run_rt_runtime_hosts.py',
         'scripts/run_rt_runtime_miri.py', 'scripts/run_rt_runtime_miri_jobs.py']
scopes = ['src/rust/rt_runtime/src', 'src/rust/rt_runtime/tests', 'src/rust/rt_runtime/examples',
          'src/rust/shoop_loop_engine/src', 'src/rust/shoop_loop_engine/tests',
          'src/rust/shoop_loop_engine/examples', 'tests/loop_engine_host/src',
          'tests/loop_engine_host/web', 'src/rust/shoop_wasm_test_support/src',
          'src/rust/shoop_test_macros/src']
paths += subprocess.check_output(['git', 'ls-files', '--', *scopes], text=True).splitlines()
assert not subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--', *scopes], text=True).strip()
checks = {}
for name in sorted(set(paths)):
    data = (root / name).read_bytes()
    for ref in (base, frozen, head):
        assert data == subprocess.check_output(['git', 'show', f'{ref}:{name}']), (ref, name)
    checks[name] = hashlib.sha256(data).hexdigest()
assets = {}
for profile in ('debug', 'release'):
    wasm = root / f'target/loop-engine-host/{profile}/pkg/fixture_bg.wasm'
    digest = hashlib.sha256(wasm.read_bytes()).hexdigest()
    prior = json.loads((root / f'target/loop-layer-bulk-midi-stage8/loop-host-reports/{profile}/result.json').read_text())
    assert digest == prior['wasm_sha256'], profile
    assets[profile] = {'wasm_sha256': digest, 'bytes': wasm.stat().st_size,
                       'reuse_authority': f'target/loop-layer-bulk-midi-stage8/loop-host-reports/{profile}/result.json',
                       'binding_js_sha256': hashlib.sha256((wasm.parent / 'fixture.js').read_bytes()).hexdigest()}
proof = {'checked_at': datetime.now(timezone.utc).isoformat(), 'head': head,
         'implementation_commit': base, 'active_miri_frozen_commit': frozen,
         'matching_implementation_test_dependency_runner_inputs': checks,
         'input_count': len(checks), 'reused_wasm': assets,
         'scope': 'Current implementation/test/configuration identity; actual new guard executions are recorded separately. No new build or Miri pass follows from these hashes.'}
(out / 'source-and-assets.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps({'matching_inputs': len(checks), 'head': head, 'reused_wasm': assets}, indent=2))
