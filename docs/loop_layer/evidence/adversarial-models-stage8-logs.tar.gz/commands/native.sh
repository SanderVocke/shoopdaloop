#!/usr/bin/env bash
set -euo pipefail
set -x
export RUSTFLAGS="-D warnings" RUSTDOCFLAGS="-D warnings"
export PATH="$HOME/.cache/rt-runtime-nextest-0.9.116/bin:$PATH"
date -u '+%Y-%m-%dT%H:%M:%SZ'
rustc --version
cargo --version
cargo nextest --version
cargo fmt --all
cargo fmt --all -- --check
cargo fmt --manifest-path tests/loop_engine_host/Cargo.toml -- --check
cargo build --locked --workspace
cargo build --locked --manifest-path tests/loop_engine_host/Cargo.toml
cargo build --locked --manifest-path tests/loop_engine_host/Cargo.toml --release
cargo test --locked -p rt_runtime -p shoop_loop_engine
cargo test --locked -p rt_runtime -p shoop_loop_engine --release
cargo test --locked --manifest-path tests/loop_engine_host/Cargo.toml
cargo test --locked --manifest-path tests/loop_engine_host/Cargo.toml --release
cargo doc --locked -p rt_runtime -p shoop_loop_engine --no-deps
cargo test --locked -p rt_runtime -p shoop_loop_engine --doc
python3 -m unittest scripts.tests.test_loop_benchmark scripts.tests.test_rt_runtime_miri scripts.tests.test_rt_runtime_miri_jobs scripts.tests.test_rt_runtime_miri_batches scripts.tests.test_loop_engine_hosts scripts.tests.test_loop_host_native_runner
python3 scripts/check_shoop_test_usage.py
python3 scripts/check_tracing_coverage.py --require-closed
python3 scripts/check_rt_runtime_boundary.py
python3 scripts/check_loop_engine_boundary.py
python3 scripts/check_wasm_test_dependencies.py --package rt_runtime --package shoop_loop_engine
SHOOP_ALLOW_MISSING_BACKENDS=1 cargo nextest run --locked --workspace --features shoop_engine/app_backend --profile ci
cargo nextest list --locked -p rt_runtime -p shoop_loop_engine --message-format json > target/loop-layer-adversarial-models-stage8/discovery.json
python3 scripts/run_rt_runtime_miri.py --list > target/loop-layer-adversarial-models-stage8/inventory-after.json
date -u '+%Y-%m-%dT%H:%M:%SZ'
