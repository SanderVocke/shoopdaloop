"""One-off verification of the adversarial-model milestone's actual execution inputs/results."""
import collections
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import types

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT))
from scripts import run_rt_runtime_miri as runner
OUT = ROOT / 'target/loop-layer-adversarial-models-stage8'
BASE = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert BASE == 'dfd610d90c3484dc7ec7ffaa86d1cf80f861c6d6'
def normalized(value):
    return json.loads(json.dumps(value))
def sha(data):
    return hashlib.sha256(data).hexdigest()
def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

old = types.ModuleType('recorded_base_runner')
old.__file__ = str(ROOT / 'scripts/run_rt_runtime_miri.py')
exec(compile(subprocess.check_output(['git', 'show', BASE + ':scripts/run_rt_runtime_miri.py']), old.__file__, 'exec'), old.__dict__)
before = json.loads((OUT / 'inventory-before.json').read_text())
after = json.loads((OUT / 'inventory-after.json').read_text())
assert before == normalized(old.inventory())
assert after == normalized(runner.inventory())
assert len(before['cases']) == 147 and sum(case[3] for case in before['cases']) == 300
assert len(after['cases']) == 151 and sum(case[3] for case in after['cases']) == 304
assert after['cases'][:-4] == before['cases']
assert {key: value for key, value in before.items() if key not in ('cases', 'full_inventory_sha256')} == {key: value for key, value in after.items() if key not in ('cases', 'full_inventory_sha256')}
assert collections.Counter({owner: sum(case[3] for case in after['cases'] if case[0] == owner) for owner in ['rt_runtime', 'shoop_loop_engine', runner.HOST_PACKAGE]}) == {'rt_runtime': 138, 'shoop_loop_engine': 102, runner.HOST_PACKAGE: 64}

sources = ['Cargo.toml', 'Cargo.lock', '.cargo/config.toml', '.config/nextest.toml', 'flake.nix', 'flake.lock', 'src/rust/rt_runtime/Cargo.toml', 'src/rust/shoop_loop_engine/Cargo.toml', 'src/rust/shoop_wasm_test_support/Cargo.toml', 'src/rust/shoop_test_macros/Cargo.toml', 'src/rust/rt_runtime/src', 'src/rust/rt_runtime/tests', 'src/rust/rt_runtime/examples', 'src/rust/shoop_loop_engine/src', 'src/rust/shoop_loop_engine/tests', 'src/rust/shoop_loop_engine/examples', 'src/rust/shoop_wasm_test_support/src', 'src/rust/shoop_test_macros/src', 'tests/loop_engine_host/Cargo.toml', 'tests/loop_engine_host/Cargo.lock', 'tests/loop_engine_host/src', 'tests/loop_engine_host/web', 'scripts/run_wasm_tests.py']
tracked = subprocess.check_output(['git', 'ls-files', '-z', '--', *sources]).decode().strip('\0').split('\0')
new = ['src/rust/rt_runtime/tests/adversarial_capture.rs', 'src/rust/rt_runtime/tests/adversarial_delivery.rs', 'src/rust/shoop_loop_engine/tests/adversarial_timeline.rs']
assert set(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--', *sources]).decode().splitlines()) == set(new)
manifest = {}
for path in tracked:
    data = (ROOT / path).read_bytes()
    original = subprocess.check_output(['git', 'show', BASE + ':' + path])
    assert data == original, path
    manifest[path] = {'bytes': len(data), 'sha256': sha(data), 'unchanged_from_base': True}
for path in new:
    data = (ROOT / path).read_bytes()
    assert 'cfg(miri)' not in data.decode()
    manifest[path] = {'bytes': len(data), 'sha256': sha(data), 'new': True}
changed = ['scripts/run_rt_runtime_miri.py', 'scripts/tests/test_rt_runtime_miri.py', 'scripts/tests/test_rt_runtime_miri_batches.py']
patch = subprocess.check_output(['git', 'diff', '--binary', BASE, '--', *changed])
for path in new:
    result = subprocess.run(['git', 'diff', '--no-index', '--', '/dev/null', path], capture_output=True)
    assert result.returncode == 1
    patch += result.stdout
(OUT / 'implementation.patch').write_bytes(patch)
for path in changed:
    data = (ROOT / path).read_bytes()
    manifest[path] = {'bytes': len(data), 'sha256': sha(data), 'changed': True}
save('source-proof.json', {'base': BASE, 'unchanged_existing_inputs': len(tracked), 'new_rust_files': new, 'changed_runner_files': changed, 'inputs': manifest, 'patch_sha256': sha(patch)})

native = json.loads((OUT / 'discovery.json').read_text())
counts = collections.Counter()
for suite in native['rust-suites'].values():
    counts[suite['package-name']] += len(suite['testcases'])
assert counts == {'rt_runtime': 193, 'shoop_loop_engine': 155}, counts
for owner, target, name in runner.STAGE8_MODELS:
    suites = [suite for suite in native['rust-suites'].values() if suite['package-name'] == owner and suite['binary-name'] == target]
    assert len(suites) == 1 and name in suites[0]['testcases']

executions = []
env = {**os.environ, 'RUSTFLAGS': '-D warnings', 'RUSTDOCFLAGS': '-D warnings'}
for profile in ['debug', 'release']:
    for number, (owner, target, name) in enumerate(runner.STAGE8_MODELS):
        command = ['cargo', 'test', '--locked', '-p', owner, '--test', target]
        if profile == 'release':
            command.append('--release')
        command += [name, '--', '--exact']
        log = OUT / f'exact-{profile}-{number}.log'
        started = time.monotonic()
        with log.open('w') as output:
            result = subprocess.run(command, env=env, stdout=output, stderr=subprocess.STDOUT, timeout=120)
        seconds = time.monotonic() - started
        text = log.read_text()
        assert result.returncode == 0 and re.search(r'test result: ok\. 1 passed; 0 failed; 0 ignored;', text), log
        assert f'test {name} ... ok' in text
        executions.append({'command': command, 'profile': profile, 'returncode': result.returncode, 'seconds': seconds, 'log': log.name, 'sha256': sha(log.read_bytes())})
save('native-exact.json', executions)

wasm = {}
for runtime in ['node', 'chrome']:
    source = ROOT / f'target/wasm-tests/dev/reports/{runtime}'
    destination = OUT / 'wasm-reports' / runtime
    shutil.copytree(source, destination, dirs_exist_ok=True)
    data = json.loads((destination / 'summary.json').read_text())
    assert data['filters'] == [] and data['package_timeout'] == 600 and data['global_timeout'] == 3600
    for package in data['packages']:
        count = {'rt_runtime': 189, 'shoop_loop_engine': 155}[package['package']]
        assert package['listed'] == package['executed'] == package['passed'] == count
        assert package['returncode'] == package['failed'] == package['ignored'] == 0 and package['malformed'] == [] and package['success']
        assert all(test['status'] == 'passed' for test in package['testcases'])
        names = {test['name'] for test in package['testcases']}
        assert all(name in names for owner, _, name in runner.STAGE8_MODELS if owner == package['package'])
    wasm[runtime] = {'packages': {package['package']: package['passed'] for package in data['packages']}, 'summary_sha256': sha((destination / 'summary.json').read_bytes())}
text = (OUT / 'native-gates.log').read_text()
assert 'Ran 73 tests' in text and '2148 passed, 4 skipped' in text
for line in re.findall(r'test result: ok\.[^\n]+', text):
    assert '; 0 failed; 0 ignored;' in line, line
save('verification.json', {'base': BASE, 'native_discovery': dict(counts), 'fixture_per_profile': 60, 'native_exact_dispatches': len(executions), 'helper_tests': 73, 'workspace_passed': 2148, 'workspace_existing_skips': 4, 'wasm': wasm, 'inventory_before': {'commands':147, 'executions':300}, 'inventory_after': {'commands':151, 'executions':304}, 'all_prior_cases_counts_seeds_order_retained': True, 'new_model_miri_executions': 0, 'no_production_api_dependency_changes': True})
print(json.dumps(json.loads((OUT / 'verification.json').read_text()), indent=2))
