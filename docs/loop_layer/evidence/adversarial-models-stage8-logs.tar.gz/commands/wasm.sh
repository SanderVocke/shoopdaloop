#!/usr/bin/env bash
set -euo pipefail
set -x
export RUSTFLAGS="-D warnings" RUSTDOCFLAGS="-D warnings"
export PATH="/nix/store/qbj1w0y8ilv183jhdv2ws6dfhzph680p-nodejs-22.22.2/bin:/nix/store/z902vg8lk7gqwafn7anq7blmrymf2r0s-chromium-147.0.7727.137/bin:/nix/store/s6vs54z82hiz6d8sc63g4ckavl6fax4z-chromedriver-unwrapped-147.0.7727.137/bin:$PATH"
export CHROME_BIN="/nix/store/z902vg8lk7gqwafn7anq7blmrymf2r0s-chromium-147.0.7727.137/bin/chromium"
date -u '+%Y-%m-%dT%H:%M:%SZ'
node --version
chromium --version
chromedriver --version
wasm-pack --version
python3 scripts/run_wasm_tests.py --runtime node --package rt_runtime --package shoop_loop_engine
python3 scripts/run_wasm_tests.py --runtime chrome --package rt_runtime --package shoop_loop_engine
date -u '+%Y-%m-%dT%H:%M:%SZ'
