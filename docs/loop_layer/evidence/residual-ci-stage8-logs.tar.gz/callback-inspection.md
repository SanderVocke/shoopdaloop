# Initial callback source inspection — incomplete audit

Source: committed 0b853b4a; the interpreted runtime/loop/fixture implementation matches 802833f4. No production changes are made in this milestone.

Inspected entry points include `GraphRuntime::{process,run_scheduled,run_graph_range}`, `Engine::process`, loop `Node::process`, planner graph validation/activation and transport `RenderEndpoint::{begin_cycle,next_operation,complete}`. The raw lexical scan has 149 matching lines, including preparation and stopped-cleanup code; this is not a count of callback paths or completed audit coverage.

- Transport snapshots queue availability in `begin_cycle`; `next_operation` uses the snapshot plus fixed operation/publication budgets. A held normal packet is parked for recovery rather than destroyed. A full reliable-return push retains its packet and blocks further dequeue; there is no push-until-success loop.
- The facade/node paths separate planner decisions, DSP/media execution and observations. Existing one-frame tests and the benchmark deliberately use subranges=0 while internal progression continues. This source inspection does not replace those tests or prove all descendant paths.
- Reviewed role cancellation validates source snapshots before draining changes and releasing their explicit leases; recycle clears prepared edit/change vectors. A full audit still needs element-type/ownership and reachability classification across every staging, publication, retirement and failure path, not just a search for `clear`/`pop`.
- MIDI routing operates on prepared event/byte arenas, with stable insertion and explicit overflow/reset behavior. Its measured cost is substantial despite finite storage; optimization must preserve ordering, per-packet content, window rebasing, reset semantics and refusal behavior.
- MIDI-buffer construction is preparation, not rendering. Full pre-touch remains required; the residual profile distinguishes generic Event cloning/filling from byte-slice bulk initialization.

Still open: exhaustive reachability-based owner/destructor, lock/I/O/retry, hidden-content-scan and quota-refresh audit; complete correlation to the successful/error/heap guard controls; broader seeded models and current/final Miri/remote acceptance. No callback-audit row is checked by this initial inspection.
