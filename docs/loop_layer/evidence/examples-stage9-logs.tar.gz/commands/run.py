"""Execute public examples and API documentation gates; no documentation inventory."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from datetime import datetime, timezone

ROOT = Path.cwd()
OUT = ROOT / 'target/loop-layer-final-examples-stage9'
sys.path.insert(0, str(ROOT))
from scripts.run_rt_runtime_miri_jobs import digest

if (OUT / 'result.json').exists() or (OUT / 'logs').exists():
    raise RuntimeError('refusing to overwrite prior execution evidence')
(OUT / 'logs').mkdir()
env = dict(os.environ, RUSTFLAGS='-D warnings', RUSTDOCFLAGS='-D warnings')
source_commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
job = ROOT / 'target/loop-layer-miri-jobs/20261028T190146-abeee2e59e'
expected = json.loads((ROOT / 'target/loop-layer-adversarial-models-stage8/source-proof.json').read_text())['inputs']
for name, record in expected.items():
    assert digest(ROOT / name) == digest(job / 'source' / name) == record['sha256'], name
metadata = json.loads(subprocess.check_output(['cargo', 'metadata', '--locked', '--no-deps', '--format-version', '1'], env=env))
examples = []
for package in metadata['packages']:
    if package['name'] not in ['rt_runtime', 'shoop_loop_engine']:
        continue
    for target in package['targets']:
        if 'example' in target['kind']:
            relative = str(Path(target['src_path']).relative_to(ROOT))
            assert relative in expected, relative
            examples.append({'package':package['name'], 'name':target['name'], 'source':relative})
assert len(examples) == 23 and sum(e['package'] == 'rt_runtime' for e in examples) == 18
(OUT / 'discovery.json').write_text(json.dumps(examples, indent=2)+'\n')
records = []

def run(command, label, timeout=600):
    log = OUT / 'logs' / (label+'.log')
    start = time.monotonic()
    record = {'command':command, 'log':str(log.relative_to(OUT)), 'started_at':datetime.now(timezone.utc).isoformat()}
    with log.open('wb') as stream:
        try:
            result = subprocess.run(command, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=timeout)
            record['exit_code'] = result.returncode
        except subprocess.TimeoutExpired:
            record['exit_code'] = None
            record['timed_out'] = True
    record['wall_seconds'] = time.monotonic()-start
    record['log_sha256'] = digest(log)
    records.append(record)
    (OUT / 'progress.json').write_text(json.dumps(records, indent=2)+'\n')
    print(label, record['exit_code'], round(record['wall_seconds'], 3), flush=True)
    if record['exit_code'] != 0:
        raise RuntimeError('gate failed; preserve raw log: '+str(log))

for profile in ['debug', 'release']:
    for example in examples:
        command = ['cargo', 'run', '--locked', '-p', example['package']]
        if profile == 'release':
            command += ['--release']
        command += ['--example', example['name']]
        if example['name'] in ['bounded_runtime', 'benchmark_loop']:
            iterations = 1024 if example['name'] == 'bounded_runtime' else 8
            command += ['--', '--iterations', str(iterations), '--raw-dir', str(OUT / 'raw' / profile / example['name'])]
        run(command, profile+'-'+example['package']+'-'+example['name'])
run(['cargo', 'doc', '--locked', '-p', 'rt_runtime', '-p', 'shoop_loop_engine', '--no-deps'], 'rustdoc')
run(['cargo', 'test', '--locked', '-p', 'rt_runtime', '-p', 'shoop_loop_engine', '--doc'], 'doctests')
for name, record in expected.items():
    assert digest(ROOT / name) == record['sha256'], name
for profile in ['debug', 'release']:
    for name, count, iterations in [('bounded_runtime',7,1024),('benchmark_loop',14,8)]:
        files = list((OUT / 'raw' / profile / name).glob('*.csv'))
        assert len(files) == count
        for path in files:
            assert len(path.read_text().splitlines()) == iterations+1, path
proof = {'source_commit':source_commit, 'frozen_interpreter_candidate':'8633d0f0754a2f4445c3d0febb1f1ae2d7e9572e', 'execution_inputs_unchanged':len(expected), 'profiles':['debug','release'], 'examples_per_profile':len(examples), 'example_executions':46, 'gate_commands':len(records), 'status':'passed', 'environment':{'RUSTFLAGS':env['RUSTFLAGS'],'RUSTDOCFLAGS':env['RUSTDOCFLAGS']}, 'versions':{tool:subprocess.check_output([tool,'--version'],text=True).strip() for tool in ['rustc','cargo']}, 'records':records, 'limits':'Executable/API checks only; benchmark example invocations are not final benchmark trials, device timing, fresh browser, remote CI or interpreter acceptance.'}
(OUT / 'result.json').write_text(json.dumps(proof, indent=2)+'\n')
print(json.dumps({key:value for key,value in proof.items() if key != 'records'}, indent=2))
