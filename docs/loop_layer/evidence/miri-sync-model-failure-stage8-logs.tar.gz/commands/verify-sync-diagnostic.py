"""Verify finalized interrupted diagnosis, then analyze only a separate profile copy."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts import run_rt_runtime_miri_jobs as jobs
OUT=ROOT/'target/loop-layer-final-stage10/sync-diagnostic';OUT.mkdir(exist_ok=False)
job=Path(json.loads((OUT.parent/'sync-diagnostic-launch.json').read_text())['job'])
data=json.loads((job/'job.json').read_text());state=jobs.status(job);jobs.verify_source(job,data)
assert state['status']=='failed' and state['exit_code']==1 and data['measureme'] is True
assert data['commit']=='8633d0f0754a2f4445c3d0febb1f1ae2d7e9572e' and len(data['source_manifest'])==890
assert data['source_archive_sha256']=='8c009c30678bbb9d11653b4f0699be7c4e2f9b6f3c4c4bc887f9f4b9f0aa525f'
progress=json.loads((job/'reports/progress.json').read_text());assert progress['status']=='failed' and progress['completed']==[]
assert progress['current']['miri_flags']=='-Zmiri-seed=0 -Zmiri-measureme='+str(job/'reports/measureme')
log=job/'reports'/progress['current']['log'];assert not re.search(r'test result: ok\.',log.read_text())
processes={}
for name in ['process.json','child.json']:
 p=json.loads((job/name).read_text());assert not jobs.alive(p);processes[name]={**p,'current_identity':jobs.identity(p['pid']),'recorded_process_alive':False}
profiles=list((job/'reports/measureme').glob('*.mm_profdata'));assert len(profiles)==1
profile=profiles[0]
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for value in iter(lambda:f.read(1024*1024),b''):h.update(value)
 return h.hexdigest()
sha=digest(profile);assert profile.stat().st_size>0
for name in ['job.json','state.json','process.json','child.json','supervisor.py','runner.log','supervisor.log']:shutil.copy2(job/name,OUT/name)
shutil.copytree(job/'reports',OUT/'reports',ignore=shutil.ignore_patterns('measureme'))
collected=subprocess.run([sys.executable,'scripts/run_rt_runtime_miri_jobs.py','collect',str(job)],capture_output=True,text=True)
(OUT/'collect.stdout.log').write_text(collected.stdout);(OUT/'collect.stderr.log').write_text(collected.stderr)
assert collected.returncode!=0 and 'Cannot collect passing evidence: failed' in collected.stderr
proof={'job':data['id'],'source_commit':data['commit'],'status':'failed','reason':'Identity/ancestry/flags checked SIGINT finalized censored profile after natural compiler-gate checkpoint.','started_at':state['started_at'],'ended_at':state['ended_at'],'supervisor_monotonic_seconds':state['seconds'],'source_entries':890,'profile':str(profile),'profile_sha256':sha,'profile_bytes':profile.stat().st_size,'processes':processes,'executions_passed':0,'supported_collection_refused':True,'terminal_pass_claimed':False}
(OUT/'verification.json').write_text(json.dumps(proof,indent=2)+'\n')
analysis=OUT/'analysis';analysis.mkdir();copy=analysis/'sync.mm_profdata';shutil.copy2(profile,copy);assert digest(copy)==sha
analyzer=Path.home()/'.cache/loop-layer-measureme-9aeaf4d0/bin/summarize'
for label,args in [('text',[]),('json',['--json'])]:
 with (analysis/('summary-'+label+'.stdout.log')).open('wb') as out,(analysis/('summary-'+label+'.stderr.log')).open('wb') as err:
  result=subprocess.run([str(analyzer),'summarize',*args,str(copy)],stdout=out,stderr=err,timeout=180)
 assert result.returncode==0,label
assert digest(profile)==sha
print(json.dumps(proof,indent=2))
