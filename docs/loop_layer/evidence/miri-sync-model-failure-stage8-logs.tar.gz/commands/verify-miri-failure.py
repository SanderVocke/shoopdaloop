"""Verify the frozen terminal timeout; partial passes never certify the full campaign."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import types
ROOT=Path.cwd(); sys.path.insert(0,str(ROOT))
from scripts import run_rt_runtime_miri_jobs as jobs
JOB=ROOT/'target/loop-layer-miri-jobs/20261028T190146-abeee2e59e'
OUT=ROOT/'target/loop-layer-final-stage10/miri-failed'; OUT.mkdir(exist_ok=False)
SHA='8633d0f0754a2f4445c3d0febb1f1ae2d7e9572e'
data=json.loads((JOB/'job.json').read_text()); state=jobs.status(JOB)
assert data['commit']==SHA and state['status']=='failed' and state['exit_code']==1
assert jobs.digest(JOB/'job.json')=='a139dfecc8735b5fdeab5f752d22364b06acb599fbc67a25576b2dd792075100'
assert data['source_archive_sha256']=='8c009c30678bbb9d11653b4f0699be7c4e2f9b6f3c4c4bc887f9f4b9f0aa525f'
assert data['supervisor_sha256']=='75dfb8fdc9b45957a2bfd01e679216e0f5ce28be2dffafdf8aba5b938a36fa1d'
jobs.verify_source(JOB,data)
assert len(data['source_manifest'])==890 and not any(p=='.pi' or p.startswith('.pi/') for p in data['source_manifest'])
assert data['package'] is None and data['shard'] is None and data['measureme'] is False
assert data['environment']['RUSTFLAGS']==data['environment']['RUSTDOCFLAGS']=='-D warnings'
assert data['environment']['MIRI_SOURCE_COMMIT']==SHA and data['environment']['CARGO_TARGET_DIR']==str(JOB/'build')
module=types.ModuleType('frozen_stage8_runner'); module.__file__=str(JOB/'source/scripts/run_rt_runtime_miri.py')
exec(compile(Path(module.__file__).read_bytes(),module.__file__,'exec'),module.__dict__)
inventory=json.loads(json.dumps(module.inventory())); assert inventory==data['inventory']
assert len(inventory['cases'])==151 and sum(c[3] for c in inventory['cases'])==304
progress=json.loads((JOB/'reports/progress.json').read_text())
assert progress['status']=='failed' and progress['inventory']==inventory['cases']
completed=progress['completed']; assert len(completed)==150
artifacts={}
for record,expected in zip(completed,inventory['cases']):
    package,target,arguments,count,seed=expected
    assert (record['package'],record['target'],record['arguments'],record['passed'],record['seed'])==(package,target,arguments,count,seed)
    assert record['miri_flags']==f'-Zmiri-seed={seed}'
    log=JOB/'reports'/record['log']; summaries=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed',log.read_text())
    assert summaries and sum(int(n) for n,_ in summaries)==count and not any(int(n) for _,n in summaries)
    artifacts['reports/'+record['log']]=jobs.digest(log)
assert sum(r['passed'] for r in completed)==303
failed=inventory['cases'][-1]
assert failed[2]==['seeded_sync_components_deliver_each_occurrence_once_with_saturated_results_and_optional_journals','--','--exact']
partial=JOB/'reports'/progress['current']['log']; assert not re.search(r'test result:',partial.read_text())
assert progress['current']['miri_flags']=='-Zmiri-seed=0'
assert progress['current']['command']==module.case_command(*failed[:3])
assert 'timed out after 900 seconds' in (JOB/'runner.log').read_text()
assert not (JOB/'reports/result.json').exists() and not (JOB/'collected.json').exists()
processes={}
for name in ['process.json','child.json']:
    p=json.loads((JOB/name).read_text()); assert not jobs.alive(p)
    processes[name]={**p,'current_identity':jobs.identity(p['pid']),'recorded_process_alive':False}
paths=subprocess.check_output(['git','ls-tree','-z','--name-only',SHA]).decode().split('\0')
paths=[f':(literal){p}' for p in paths if p and p!='.pi']
archive=OUT/'source-reexport.tar'
with archive.open('wb') as out: subprocess.run(['git','archive','--format=tar',SHA,'--',*paths],stdout=out,check=True)
assert jobs.digest(archive)==data['source_archive_sha256']; archive.unlink()
collected=subprocess.run([sys.executable,'scripts/run_rt_runtime_miri_jobs.py','collect',str(JOB)],capture_output=True,text=True)
(OUT/'collect.stdout.log').write_text(collected.stdout); (OUT/'collect.stderr.log').write_text(collected.stderr)
assert collected.returncode!=0 and 'Cannot collect passing evidence: failed' in collected.stderr
for name in ['job.json','state.json','process.json','child.json','supervisor.py','runner.log','supervisor.log']:
    shutil.copy2(JOB/name,OUT/name)
shutil.copytree(JOB/'reports',OUT/'reports')
for path in (OUT/'reports').iterdir():
    if path.is_file(): artifacts['reports/'+path.name]=jobs.digest(path)
proof={'job':data['id'],'source_commit':SHA,'status':'failed','source_snapshot_entries':890,'source_archive_reexport_matches':True,'commands':151,'intended_executions':304,'completed_commands':150,'completed_executions':303,'failed_case':failed,'failure':'Unchanged full sync-component model exceeded 900s; no final passing summary.','started_at':state['started_at'],'ended_at':state['ended_at'],'supervisor_monotonic_seconds':state['seconds'],'processes':processes,'supported_collection_refused':True,'artifact_sha256':artifacts,'terminal_pass_claimed':False}
(OUT/'verification.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({k:v for k,v in proof.items() if k!='artifact_sha256'},indent=2))
