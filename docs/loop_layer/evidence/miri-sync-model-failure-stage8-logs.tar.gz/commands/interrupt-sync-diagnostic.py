"""Finalize a censored failure diagnostic only after exact process/source identity checks."""
import json
import os
from pathlib import Path
import signal
import sys
from datetime import datetime,timezone
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts import run_rt_runtime_miri_jobs as jobs
root=ROOT/'target/loop-layer-final-stage10';job=Path(json.loads((root/'sync-diagnostic-launch.json').read_text())['job'])
data=json.loads((job/'job.json').read_text());jobs.verify_source(job,data)
assert jobs.status(job)['status']=='running' and data['measureme'] is True
recorded=json.loads((job/'child.json').read_text());supervisor=json.loads((job/'process.json').read_text())
assert jobs.alive(recorded) and jobs.alive(supervisor)
flag='-Zmiri-measureme='+str(job/'reports/measureme');found=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:
  argv=[v.decode() for v in (proc/'cmdline').read_bytes().split(b'\0') if v]
  if argv and Path(argv[0]).name=='miri' and flag in argv:found.append((int(proc.name),argv))
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
assert len(found)==1
pid,argv=found[0];identity=jobs.identity(pid);assert identity is not None
assert '-Zmiri-seed=0' in argv and '-D' in argv and argv[argv.index('-D')+1]=='warnings'
assert [a for a in argv if a.startswith('-Zmiri-')]==['-Zmiri-seed=0',flag]
assert argv[-3:]==['--','seeded_sync_components_deliver_each_occurrence_once_with_saturated_results_and_optional_journals','--exact']
cwd=(Path('/proc')/str(pid)/'cwd').resolve()
assert cwd==job/'source/src/rust/shoop_loop_engine'
ancestry=[pid];current=pid
while current!=supervisor['pid']:
 fields=(Path('/proc')/str(current)/'stat').read_text().rsplit(')',1)[1].split();current=int(fields[1]);ancestry.append(current)
 assert len(ancestry)<10
assert recorded['pid'] in ancestry
proof={'at':datetime.now(timezone.utc).isoformat(),'job':str(job),'pid':pid,'identity':identity,'ancestry':ancestry,'cwd':str(cwd),'command':argv,'corrected_preflight':'Initial stdin helper refused before signalling because it expected repository-root cwd. Cargo actually uses this exact frozen package directory; source/flags/ancestry checks remain intact.','reason':'Finalize censored diagnostic after useful compiler checks. Original full command already exceeded unchanged900s. Not acceptance.'}
(root/'sync-diagnostic-interruption.json').write_text(json.dumps(proof,indent=2)+'\n')
assert jobs.identity(pid)==identity
os.kill(pid,signal.SIGINT)
print(json.dumps(proof,indent=2))
