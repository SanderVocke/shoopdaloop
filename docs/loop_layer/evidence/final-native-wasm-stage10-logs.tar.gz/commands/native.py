"""Run final native suites and applicable policies with source-scoped evidence."""
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
from datetime import datetime, timezone

ROOT = Path.cwd()
OUT = ROOT / 'target/loop-layer-final-stage10/native'
if OUT.exists():
    raise RuntimeError('refusing to overwrite native gate evidence')
OUT.mkdir(parents=True)
sys.path.insert(0, str(ROOT))
from scripts.run_rt_runtime_miri_jobs import digest
job = ROOT / 'target/loop-layer-miri-jobs/20261028T190146-abeee2e59e'
meta = json.loads((job / 'job.json').read_text())
source_commit = subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip()
roots = ('src/','tests/','scripts/','.cargo/','.config/','.github/')
def relevant(name):
    path = Path(name)
    return (name.startswith(roots) or name in ['Cargo.toml','Cargo.lock','flake.nix','flake.lock']) and path.suffix != '.md' and not any(part.startswith('docs') for part in path.parts)
inputs = {}
for name in meta['source_manifest']:
    if relevant(name):
        value = digest(ROOT / name)
        assert value == digest(job / 'source' / name), name
        inputs[name] = value
tracked = subprocess.check_output(['git','ls-files','-z'],text=True).split('\0')
untracked = subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],text=True).split('\0')
assert not [name for name in tracked if name and relevant(name) and name not in inputs]
assert not [name for name in untracked if name and relevant(name)]
(OUT / 'execution-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
env = dict(os.environ,RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',CARGO_TERM_COLOR='never')
nextest_binary = Path.home()/'.cache/rt-runtime-nextest-0.9.116/cargo-nextest'
env['PATH'] = str(nextest_binary.parent)+os.pathsep+env['PATH']
version = subprocess.check_output(['cargo','nextest','--version'],env=env,text=True).strip()
assert version.split()[1] == '0.9.116', version
assert digest(nextest_binary) == 'fa5177e947cd7949cbe0626623e155fb289f78d19a9c0ad7c034f5ca8196c5fe'
records=[]

def run(label, command, extra=None):
    stdout=OUT/(label+'.stdout.log'); stderr=OUT/(label+'.stderr.log')
    entry={'label':label,'command':command,'started_at':datetime.now(timezone.utc).isoformat(),'environment':extra or {}}
    start=time.monotonic()
    with stdout.open('wb') as out, stderr.open('wb') as err:
        result=subprocess.run(command,env={**env,**(extra or {})},stdout=out,stderr=err,timeout=1200)
    entry.update(exit_code=result.returncode,wall_seconds=time.monotonic()-start,stdout_sha256=digest(stdout),stderr_sha256=digest(stderr))
    records.append(entry)
    (OUT/'progress.json').write_text(json.dumps(records,indent=2)+'\n')
    print(label,result.returncode,round(entry['wall_seconds'],3),flush=True)
    if result.returncode:
        raise RuntimeError('failed final gate; preserve '+str(stderr))
    return stdout.read_text()+stderr.read_text()

run('fmt-workspace',['cargo','fmt','--all','--','--check'])
for fixture in ['rt_runtime_host','loop_engine_host']:
    run('fmt-'+fixture,['cargo','fmt','--manifest-path','tests/'+fixture+'/Cargo.toml','--','--check'])
run('workspace-build',['cargo','build','--locked','--workspace'])
counts={}
for profile in ['debug','release']:
    args=[] if profile=='debug' else ['--release']
    for label,command in [
        ('libraries',['cargo','test','--locked','-p','rt_runtime','-p','shoop_loop_engine',*args]),
        ('loop-fixture',['cargo','test','--locked','--manifest-path','tests/loop_engine_host/Cargo.toml',*args]),
        ('generic-fixture',['cargo','test','--locked','--manifest-path','tests/rt_runtime_host/Cargo.toml',*args]),
    ]:
        text=run(label+'-'+profile,command)
        summaries=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',text)
        assert summaries,(label,profile)
        totals=[sum(int(row[i]) for row in summaries) for i in range(5)]
        assert totals[1:]==[0,0,0,0],(label,profile,totals)
        if label=='libraries': assert totals[0]==348,totals
        if label=='loop-fixture': assert totals[0]==60,totals
        counts[label+'-'+profile]=dict(zip(['passed','failed','ignored','measured','filtered'],totals))
run('rustdoc',['cargo','doc','--locked','-p','rt_runtime','-p','shoop_loop_engine','--no-deps'])
run('doctests',['cargo','test','--locked','-p','rt_runtime','-p','shoop_loop_engine','--doc'])
run('library-discovery',['cargo','nextest','list','--locked','-p','rt_runtime','-p','shoop_loop_engine','--message-format','json'])
discovery=json.loads((OUT/'library-discovery.stdout.log').read_text())
package_counts={}
for suite in discovery['rust-suites'].values():
    package=suite['package-name']; package_counts[package]=package_counts.get(package,0)+len(suite['testcases'])
assert package_counts=={'rt_runtime':193,'shoop_loop_engine':155},package_counts
workspace=run('workspace-nextest',['cargo','nextest','run','--locked','--workspace','--features','shoop_engine/app_backend','--profile','ci'],{'SHOOP_ALLOW_MISSING_BACKENDS':'1'})
assert re.search(r'2148 passed.*4 skipped',workspace),workspace[-1500:]
counts['workspace']={'passed':2148,'skipped':4,'skip_lines':[line for line in workspace.splitlines() if 'SKIP' in line]}
helpers=run('applicable-helper-tests',['python3','-m','unittest',
'scripts.tests.test_loop_benchmark','scripts.tests.test_rt_runtime_miri','scripts.tests.test_rt_runtime_miri_jobs','scripts.tests.test_rt_runtime_miri_batches','scripts.tests.test_loop_engine_hosts','scripts.tests.test_loop_host_native_runner','scripts.tests.test_rt_runtime_boundary','scripts.tests.test_loop_engine_boundary','scripts.tests.test_wasm_test_report'])
assert '\nOK\n' in helpers
counts['helpers']=int(re.search(r'Ran (\d+) tests',helpers).group(1))
for label,command in [
('test-attribute-policy',['python3','scripts/check_shoop_test_usage.py']),
('runtime-boundary',['python3','scripts/check_rt_runtime_boundary.py']),
('loop-boundary',['python3','scripts/check_loop_engine_boundary.py']),
('wasm-dependency-policy',['python3','scripts/check_wasm_test_dependencies.py','--package','rt_runtime','--package','shoop_loop_engine']),
('worklet-client-boundary',['python3','scripts/check_worklet_client_dependencies.py','--target','wasm32-unknown-unknown']),
('tracing-closure',['python3','scripts/check_tracing_coverage.py','--require-closed']),
]: run(label,command)
for name,value in inputs.items(): assert digest(ROOT/name)==value,name
proof={'source_commit':source_commit,'status':'passed','frozen_interpreter_candidate':meta['commit'],'unchanged_execution_inputs':len(inputs),'nextest_version':version,'nextest_binary_sha256':digest(nextest_binary),'environment':{'RUSTFLAGS':env['RUSTFLAGS'],'RUSTDOCFLAGS':env['RUSTDOCFLAGS']},'package_discovery':package_counts,'counts':counts,'commands':records,'versions':{tool:subprocess.check_output([tool,'--version'],env=env,text=True).strip() for tool in ['rustc','cargo','python3']},'limitations':'Native/application suites and applicable policies only. Backend-allowance is limited to the prescribed workspace command. No browser/remote/interpreter pass or deadline claim. Historical documentation-administration tests are outside the accepted documentation workflow.'}
(OUT/'result.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({key:value for key,value in proof.items() if key!='commands'},indent=2))
