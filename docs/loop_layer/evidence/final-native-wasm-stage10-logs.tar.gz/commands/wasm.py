"""Run complete package-Wasm suites with pinned tools and preserved raw reports."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone

ROOT=Path.cwd()
OUT=ROOT/'target/loop-layer-final-stage10/wasm'
if OUT.exists(): raise RuntimeError('refusing to overwrite Wasm gate evidence')
OUT.mkdir(parents=True)
sys.path.insert(0,str(ROOT))
from scripts.run_rt_runtime_miri_jobs import digest
inputs=json.loads((ROOT/'target/loop-layer-final-stage10/native/execution-inputs.json').read_text())
for name,value in inputs.items(): assert digest(ROOT/name)==value,name
source_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
node='/nix/store/qbj1w0y8ilv183jhdv2ws6dfhzph680p-nodejs-22.22.2/bin'
chrome='/nix/store/z902vg8lk7gqwafn7anq7blmrymf2r0s-chromium-147.0.7727.137/bin'
driver='/nix/store/s6vs54z82hiz6d8sc63g4ckavl6fax4z-chromedriver-unwrapped-147.0.7727.137/bin'
env=dict(os.environ,RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',CARGO_TERM_COLOR='never',CHROME_BIN=chrome+'/chromium')
env['PATH']=os.pathsep.join([node,chrome,driver,env['PATH']])
assert subprocess.check_output(['node','--version'],env=env,text=True).strip()=='v22.22.2'
metadata=json.loads(subprocess.check_output(['cargo','metadata','--locked','--no-deps','--format-version','1'],env=env))
packages=sorted(package['name'] for package in metadata['packages'] if (package.get('metadata') or {}).get('shoop-wasm-test',{}).get('enabled',False))
assert {'rt_runtime','shoop_loop_engine'}<=set(packages)
(OUT/'package-discovery.json').write_text(json.dumps(packages,indent=2)+'\n')
records=[]
for runtime in ['node','chrome']:
    reports=ROOT/'target/wasm-tests/dev/reports'/runtime
    if reports.exists():
        old=ROOT/'target/loop-layer-final-stage10/previous-wasm-reports'/runtime
        old.parent.mkdir(exist_ok=True)
        assert not old.exists()
        shutil.move(str(reports),str(old))
    command=['python3','scripts/run_wasm_tests.py','--runtime',runtime,'--profile','dev']
    record={'runtime':runtime,'command':command,'started_at':datetime.now(timezone.utc).isoformat()}
    start=time.monotonic()
    with (OUT/(runtime+'.stdout.log')).open('wb') as stdout,(OUT/(runtime+'.stderr.log')).open('wb') as stderr:
        result=subprocess.run(command,env=env,stdout=stdout,stderr=stderr,timeout=3660)
    record.update(exit_code=result.returncode,wall_seconds=time.monotonic()-start)
    if reports.exists(): shutil.copytree(reports,OUT/'reports'/runtime)
    records.append(record)
    (OUT/'progress.json').write_text(json.dumps(records,indent=2)+'\n')
    print(runtime,result.returncode,round(record['wall_seconds'],3),flush=True)
    if result.returncode: raise RuntimeError('Wasm gate failed; preserve '+str(OUT/runtime))
    summary=json.loads((OUT/'reports'/runtime/'summary.json').read_text())
    assert summary['success'] and summary['filters']==[] and summary['features']==[]
    assert summary['package_timeout']==600 and summary['global_timeout']==3600
    assert sorted(package['package'] for package in summary['packages'])==packages
    ignored=[]
    for package in summary['packages']:
        assert package['success'] and package['returncode']==0 and package['failed']==0 and package['malformed']==[],package['package']
        cases=package['testcases']
        assert len({case['name'] for case in cases})==len(cases)
        assert len(cases)==package['passed']+package['ignored']
        assert package['executed']==package['passed'] and package['listed']==len(cases)
        ignored.extend({'package':package['package'],**case} for case in cases if case['status']=='ignored')
        if package['package'] in ['rt_runtime','shoop_loop_engine']:
            assert package['passed']==({'rt_runtime':189,'shoop_loop_engine':155}[package['package']]) and package['ignored']==0
    assert len(ignored)==2 and all(case['name'].endswith(('shared_failure_canary_is_ignored_by_default','shared_result_failure_canary_is_ignored_by_default')) for case in ignored),ignored
    record.update(passed=sum(package['passed'] for package in summary['packages']),ignored=ignored,packages=len(packages),summary_sha256=digest(OUT/'reports'/runtime/'summary.json'),asset_manifest=summary['asset_manifest'],tool_versions=summary['tool_versions'])
    (OUT/'progress.json').write_text(json.dumps(records,indent=2)+'\n')
for name,value in inputs.items(): assert digest(ROOT/name)==value,name
proof={'source_commit':source_commit,'status':'passed','unchanged_execution_inputs':len(inputs),'packages':packages,'runs':records,'scope':'Complete opt-in repository Node/Chromium dev suites, including exact runtime/loop package results. No independent loop AudioWorklet or remote/Miri/deadline acceptance. Staged production worklet reuse retains its actual source/input/binary identity.'}
(OUT/'result.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'status':proof['status'],'source_commit':source_commit,'packages':len(packages),'totals':[{key:record[key] for key in ['runtime','passed','ignored','wall_seconds']} for record in records]},indent=2))
