"""One-off terminal collection proof for the immutable consolidated Stage 7 recovery."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import types

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT))
from scripts import run_rt_runtime_miri_jobs as jobs
OUT = ROOT / 'target/loop-layer-consolidated-collected-stage7'
JOB = ROOT / 'target/loop-layer-miri-jobs/20261028T153110-784d2380c0'
SHA = '3bf1dbca7c93f486be50cd7359555172dad723f3'
def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(chunk)
    return result.hexdigest()
def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')
data = json.loads((JOB / 'job.json').read_text())
state = jobs.status(JOB)
assert data['commit'] == SHA and state['status'] == 'passed' and state['exit_code'] == 0
assert digest(JOB / 'job.json') == '2ef0873da407abdeb054ecdd5e8c595d3f6fa36ab1fb10af3cd7400ea83bfc2b'
assert data['source_archive_sha256'] == '20d8a871153e2f37c871360738b5125344d00fc7402fe3ffa49415c7b369780c'
assert digest(JOB / 'supervisor.py') == data['supervisor_sha256'] == '75dfb8fdc9b45957a2bfd01e679216e0f5ce28be2dffafdf8aba5b938a36fa1d'
assert len(data['source_manifest']) == 878
assert not any(path == '.pi' or path.startswith('.pi/') for path in data['source_manifest'])
assert data['package'] is None and data['shard'] is None and data['measureme'] is False
assert data['environment']['RUSTFLAGS'] == data['environment']['RUSTDOCFLAGS'] == '-D warnings'
assert data['environment']['MIRI_SOURCE_COMMIT'] == SHA
assert data['environment']['CARGO_TARGET_DIR'] == str(JOB / 'build')
jobs.verify_source(JOB, data)
checked = jobs.verify_report(JOB, data)
assert checked['executions'] == state['executions'] == 299
assert checked['artifact_sha256'] == state['artifact_sha256'] and len(checked['artifact_sha256']) == 147
module = types.ModuleType('frozen_stage7_runner')
module.__file__ = str(JOB / 'source/scripts/run_rt_runtime_miri.py')
exec(compile(Path(module.__file__).read_bytes(), module.__file__, 'exec'), module.__dict__)
assert json.loads(json.dumps(module.inventory())) == data['inventory']
assert len(data['inventory']['cases']) == 146
report = json.loads((JOB / 'reports/result.json').read_text())
assert report['source_commit'] == SHA and report['run_attempt'] is None
assert report['toolchain'] == 'nightly-2026-05-04' and 'ad3a598ca4' in report['miri']
processes = {}
for name in ['process.json', 'child.json']:
    process = json.loads((JOB / name).read_text())
    assert not jobs.alive(process), name
    processes[name] = {**process, 'current_identity': jobs.identity(process['pid']), 'recorded_process_alive': False}
paths = subprocess.check_output(['git', 'ls-tree', '-z', '--name-only', SHA]).decode().split('\0')
paths = [f':(literal){name}' for name in paths if name and name != '.pi']
archive = OUT / 'source-reexport.tar'
with archive.open('wb') as stream:
    subprocess.run(['git', 'archive', '--format=tar', SHA, '--', *paths], stdout=stream, check=True)
assert digest(archive) == data['source_archive_sha256']
archive.unlink()
collected = json.loads((JOB / 'collected.json').read_text())
assert collected['job'] == data and collected['result'] == state
for name in ['job.json', 'state.json', 'process.json', 'child.json', 'collected.json', 'supervisor.py', 'runner.log', 'supervisor.log']:
    shutil.copy2(JOB / name, OUT / name)
shutil.copytree(JOB / 'reports', OUT / 'reports', dirs_exist_ok=True)
summary = {'job': data['id'], 'source_commit': SHA, 'status': 'passed', 'source_snapshot_entries': 878, 'source_archive_reexport_matches': True, 'commands':146, 'executions':299, 'packages':{owner:sum(case[3] for case in data['inventory']['cases'] if case[0] == owner) for owner in ['rt_runtime', 'shoop_loop_engine', 'loop_engine_host_fixture']}, 'started_at':state['started_at'], 'ended_at':state['ended_at'], 'supervisor_monotonic_seconds':state['seconds'], 'processes':processes, 'job_sha256':digest(JOB / 'job.json'), 'source_archive_sha256':data['source_archive_sha256'], 'supervisor_sha256':data['supervisor_sha256'], 'report_sha256':digest(JOB / 'reports/result.json'), 'collected_sha256':digest(JOB / 'collected.json'), 'artifact_sha256':checked['artifact_sha256'], 'new_descriptor_timeline_delivery_capture_models_covered':False, 'final_head_ci_or_review_approval':False}
save('verification.json', summary)
print(json.dumps({key:value for key,value in summary.items() if key != 'artifact_sha256'}, indent=2))
