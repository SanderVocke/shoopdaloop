# Callback transaction review — partial, not the completed LL-A6 audit

Reviewed implementation: 3d10c7a0, unchanged in bookkeeping HEAD 2db979ad. This review adds no source changes and cannot mutate the active frozen Miri job.

## Graph owner publication

`rt_runtime/src/graph/activation.rs`: scope allocation (`fetch_update`), Vec/Box allocation and pre-touch occur in preparation. Callback stage lookup/capacity/current-epoch checks only borrow fixed storage. `GraphActivation` contains exclusive references, not an owning allocation or a custom Drop. Commit takes the ready candidate out of its slot, replaces the active plan and stores the displaced plan into that now-empty slot. It does not overwrite a live owner. Release returns the taken owner; call-site reliable-return/quarantine reachability remains part of the wider audit. Stage/generation/epoch exhaustion refuses before owner mutation.

## Timing owner banks

`runtime/topology.rs`: prepared banks retain ready/retired owners. Candidate activation checks retirement emptiness before taking Ready. Both resolver refusal and stager recycle refusal restore the exact returned owner; successful replacement retains the old topology. Program staging similarly removes Ready only into a resolver owning transaction and restores it on refusal. Taken stager state prevents a new Begin from overwriting a pending owner; collection transfers the returned old/candidate owner into its empty retirement/ready position. The initial unbounded-looking validation loop is preparation, not callback work.

Record/validation allowances are initialized by `Topologies::callback`, keyed by `context.callback_start` in both operation and plan entry points. Internal musical interval frames do not replenish them. Operation failure conservatively exhausts that callback's applicable allowance. This is not a musical progression quota.

## Flat staging clear/reuse

`topology/staging.rs`: prepared vectors contain LoopSpec/Trigger, ProgramRecord/TargetRecord/Segment, TableRange and LoopId flat records rather than nested owning programs. Begin clears lengths while retaining allocated capacities; validation scratch is reset in place. Scope reservation and initialized/pre-touched vector construction are outside callbacks. The rest of codec/validator/reset/recycle descendant paths still need the complete reachability audit.

## Role/source cancellation and publication

`runtime/roles.rs`: scope reservation and banks/slot allocation are preparation. `Edit` is Copy; `OwnerChange` contains plain metadata and optional Input/Source handles, not heap owners. Logical snapshot leases are nevertheless owned and must be explicitly released or transferred. Appending validates receiving count/unique target/source readiness/packet bounds and ledger preflight before taking source handles. `received < expected <= loops` bounds prepared vector pushes. Taking a source clears its slot and advances/retires its generation; it does not free a Rust allocation.

Cancellation first checks every retained source snapshot, then drains changes and explicitly releases those unique acquired leases. Applied banks have transferred inputs (`take`) to the ledger; recycle only clears flat metadata/edit vectors. Source validation consumes a callback-shared packet-header allowance; `Roles::callback` is keyed by operation `callback_start`, not interval time. It is background source readiness, not a cap on playback or transitions.

`media/activation.rs` and `runtime/configuration.rs`: owner preflight validates old/new identity, strictly newer generations, unique edits/source leases and metadata available now, without anticipating retirement credits. Its permit borrows the ledger/I/O/change batch exclusively and has no custom Drop. Unused authority leaves inputs unchanged. The configuration path performs row/capture-idle, topology, graph/binding and owner preflight before publication. Topology refusal returns before media commit; successful topology replacement is followed by infallible media/row/graph publication. Initial inputs are consumed exactly once into fixed ledger slots, while older pins/exports retain their own leases. These ordinary errors are not rollback after rendering.

## Still open

This selected ownership/quota review is not the exhaustive callback audit. Complete the resolver/preflight progress argument, resource group/render/index descendants, reliable-return/executor and fixture bridge call-site chains, failure/panic invariants, stopped cleanup boundary and all relevant guard controls. No LL-A6 or callback-audit row is closed by this partial review.
