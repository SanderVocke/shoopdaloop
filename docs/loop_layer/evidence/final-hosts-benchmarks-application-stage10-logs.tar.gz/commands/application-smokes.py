"""Build fresh packaged application outputs and run retained physical AudioWorklet smokes."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time
ROOT=Path.cwd(); APP=ROOT/'src/rust/shoopdaloop'; OUT=ROOT/'target/loop-layer-final-stage10/application'
sys.path.insert(0,str(ROOT))
from scripts.run_rt_runtime_miri_jobs import digest
assert (OUT/'compile-result.json').exists() and not (OUT/'smoke-progress.json').exists()
inputs=json.loads((ROOT/'target/loop-layer-final-stage10/native/execution-inputs.json').read_text())
for name,value in inputs.items(): assert digest(ROOT/name)==value,name
node='/nix/store/qbj1w0y8ilv183jhdv2ws6dfhzph680p-nodejs-22.22.2/bin'
chrome='/nix/store/z902vg8lk7gqwafn7anq7blmrymf2r0s-chromium-147.0.7727.137/bin'
gecko='/nix/store/3mkvamj2hlh48rir4fp69akqqbk6sx3l-geckodriver-0.36.0/bin'
env=dict(os.environ,RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',CARGO_TERM_COLOR='never',CHROME_BIN=chrome+'/chromium',FIREFOX_BIN='/run/current-system/sw/bin/firefox')
env['PATH']=os.pathsep.join([node,chrome,gecko,env['PATH']]);env.pop('SHOOP_ALLOW_MISSING_BACKENDS',None)
records=[];assets={}
def run(label,command,extra=None):
 e=dict(env,**(extra or {}));start=time.monotonic()
 with (OUT/(label+'.stdout.log')).open('wb') as out,(OUT/(label+'.stderr.log')).open('wb') as err:
  result=subprocess.run(command,cwd=APP,env=e,stdout=out,stderr=err,timeout=1800)
 record={'label':label,'command':command,'cwd':str(APP),'extra_environment':extra or {},'exit_code':result.returncode,'wall_seconds':time.monotonic()-start}
 records.append(record);(OUT/'smoke-progress.json').write_text(json.dumps(records,indent=2)+'\n')
 print(label,result.returncode,record['wall_seconds'],flush=True)
 if result.returncode:raise RuntimeError('application gate failed; preserve '+label)
def freeport():
 with socket.socket() as s:s.bind(('127.0.0.1',0));return str(s.getsockname()[1])
def filehash(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for data in iter(lambda:f.read(1024*1024),b''):h.update(data)
 return h.hexdigest()
if (APP/'dist').exists():shutil.move(str(APP/'dist'),str(OUT/'previous-dist'))
for profile in ['debug','release']:
 run('trunk-'+profile,['trunk','build']+(['--release'] if profile=='release' else []))
 run('chrome-hosted-'+profile,['node','--experimental-websocket','browser_smoke.mjs'],{'OUTPUT_ONLY':'1','BROWSER_SIZE':'900,600','WEB_PORT':freeport(),'DEBUG_PORT':freeport()})
 assert 'hosted output-only audio passed' in (OUT/('chrome-hosted-'+profile+'.stdout.log')).read_text()
 if profile=='release':
  run('single-file',['python3','build_single_file_app.py','dist'])
  run('chrome-single-file',['node','--experimental-websocket','browser_smoke.mjs'],{'SELF_CONTAINED':'1','OUTPUT_ONLY':'1','SELF_CONTAINED_PATH':str(APP/'dist/shoopdaloop.html'),'BROWSER_SIZE':'900,600','WEB_PORT':freeport(),'DEBUG_PORT':freeport()})
  assert 'direct-file output-only audio passed' in (OUT/'chrome-single-file.stdout.log').read_text()
  run('firefox-hosted-release',['xvfb-run','-a','python3','browser_firefox_smoke.py'])
  assert 'Firefox AudioWorklet smoke passed:' in (OUT/'firefox-hosted-release.stdout.log').read_text()
 assets[profile]={str(p.relative_to(APP/'dist')):{'bytes':p.stat().st_size,'sha256':filehash(p)} for p in sorted((APP/'dist').rglob('*')) if p.is_file()}
 shutil.move(str(APP/'dist'),str(OUT/('dist-'+profile)))
for name,value in inputs.items():assert digest(ROOT/name)==value,name
proof={'status':'passed','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'unchanged_execution_inputs':len(inputs),'commands':records,'assets':assets,'scope':'Fresh Trunk debug/release, hosted Chrome both profiles, release direct-file Chrome and hosted Firefox genuine AudioWorklet startup/callback/teardown. Not loop-library migration or hard-real-time/device compatibility evidence.'}
(OUT/'smoke-result.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:v for k,v in proof.items() if k!='assets'},indent=2))
