"""Execute fresh native/actual host controls with immutable input comparison."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
ROOT=Path.cwd(); OUT=ROOT/'target/loop-layer-final-stage10/hosts'
if OUT.exists(): raise RuntimeError('refusing to overwrite host evidence')
OUT.mkdir(parents=True)
sys.path.insert(0,str(ROOT))
from scripts.run_rt_runtime_miri_jobs import digest
inputs=json.loads((ROOT/'target/loop-layer-final-stage10/native/execution-inputs.json').read_text())
for name,value in inputs.items(): assert digest(ROOT/name)==value,name
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
node='/nix/store/qbj1w0y8ilv183jhdv2ws6dfhzph680p-nodejs-22.22.2/bin'
chrome='/nix/store/z902vg8lk7gqwafn7anq7blmrymf2r0s-chromium-147.0.7727.137/bin'
driver='/nix/store/s6vs54z82hiz6d8sc63g4ckavl6fax4z-chromedriver-unwrapped-147.0.7727.137/bin'
env=dict(os.environ,RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',CARGO_TERM_COLOR='never',CHROME_BIN=chrome+'/chromium')
env['PATH']=os.pathsep.join([node,chrome,driver,env['PATH']])
env.pop('SHOOP_ALLOW_MISSING_BACKENDS',None)
records=[]
for profile in ['debug','release']:
    for fixture in ['rt_runtime','loop_engine']:
        for native in [True,False]:
            label=fixture+'-'+profile+('-native' if native else '-actual')
            report=ROOT/('target/rt-runtime-host/reports' if fixture=='rt_runtime' else 'target/loop-engine-host/reports/'+('native-'+profile if native else profile))
            if report.exists():
                previous=ROOT/'target/loop-layer-final-stage10/previous-host-reports'/label
                previous.parent.mkdir(exist_ok=True)
                assert not previous.exists()
                shutil.move(str(report),str(previous))
            command=['python3','scripts/run_'+fixture+'_hosts.py','--profile',profile,'--native-only' if native else '--verify-failures']
            record={'label':label,'command':command,'started_at':datetime.now(timezone.utc).isoformat(),'scope':'native-replay' if native else 'actual-offline-live-plus-native-and-specific-failures'}
            start=time.monotonic()
            with (OUT/(label+'.stdout.log')).open('wb') as out,(OUT/(label+'.stderr.log')).open('wb') as err:
                result=subprocess.run(command,env=env,stdout=out,stderr=err,timeout=1800)
            record.update(exit_code=result.returncode,wall_seconds=time.monotonic()-start)
            if report.exists(): shutil.copytree(report,OUT/'reports'/label)
            records.append(record)
            (OUT/'progress.json').write_text(json.dumps(records,indent=2)+'\n')
            print(label,result.returncode,round(record['wall_seconds'],3),flush=True)
            if result.returncode: raise RuntimeError('host gate failed; preserve '+str(OUT/label))
            name=('native-'+profile+'-result.json') if fixture=='rt_runtime' and native else 'result.json'
            data=json.loads((OUT/'reports'/label/name).read_text())
            assert data['passed'],label
            record['report_sha256']=digest(OUT/'reports'/label/name)
            record['report_keys']=list(data)
            (OUT/'progress.json').write_text(json.dumps(records,indent=2)+'\n')
for name,value in inputs.items(): assert digest(ROOT/name)==value,name
proof={'source_commit':source,'status':'passed','unchanged_execution_inputs':len(inputs),'records':records,'environment':{'RUSTFLAGS':env['RUSTFLAGS'],'RUSTDOCFLAGS':env['RUSTDOCFLAGS'],'backend_allowance':False},'scope':'Fresh default-build native and real non-isolated offline/live fixture gates with all existing content/ownership/memory and exact failure verifiers. No remote CI, Miri or deadline acceptance.'}
(OUT/'result.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'source_commit':source,'status':'passed','commands':len(records),'unchanged_execution_inputs':len(inputs)},indent=2))
