"""Compile the existing application/worklet for both WebAssembly profiles."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
ROOT=Path.cwd(); OUT=ROOT/'target/loop-layer-final-stage10/application'
OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT))
from scripts.run_rt_runtime_miri_jobs import digest
inputs=json.loads((ROOT/'target/loop-layer-final-stage10/native/execution-inputs.json').read_text())
for name,value in inputs.items(): assert digest(ROOT/name)==value,name
records=[]
env=dict(os.environ,RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',CARGO_TERM_COLOR='never')
env.pop('SHOOP_ALLOW_MISSING_BACKENDS',None)
for profile in ['debug','release']:
 for package in ['shoopdaloop','shoop_audio_worklet']:
  label=package+'-'+profile
  command=['cargo','check' if package=='shoopdaloop' else 'build','--locked','-p',package,'--target','wasm32-unknown-unknown']
  if package=='shoopdaloop': command.append('--no-default-features')
  if profile=='release': command.append('--release')
  start=time.monotonic()
  with (OUT/(label+'.stdout.log')).open('wb') as out,(OUT/(label+'.stderr.log')).open('wb') as err:
   result=subprocess.run(command,env=env,stdout=out,stderr=err,timeout=900)
  record={'label':label,'command':command,'exit_code':result.returncode,'wall_seconds':time.monotonic()-start}
  records.append(record);(OUT/'compile-progress.json').write_text(json.dumps(records,indent=2)+'\n')
  print(label,result.returncode,record['wall_seconds'],flush=True)
  if result.returncode: raise RuntimeError('application compiler gate failed: '+label)
for name,value in inputs.items(): assert digest(ROOT/name)==value,name
proof={'status':'passed','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'unchanged_execution_inputs':len(inputs),'commands':records,'scope':'Compiler-only UI check and dedicated worklet build, both profiles; not packaged execution.'}
(OUT/'compile-result.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
