"""Run full default benchmark campaigns without source/binary drift or reused reports."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
ROOT=Path.cwd(); OUT=ROOT/'target/loop-layer-final-stage10/benchmarks'
if OUT.exists(): raise RuntimeError('refusing to overwrite benchmark evidence')
OUT.mkdir(parents=True)
sys.path.insert(0,str(ROOT))
from scripts.run_rt_runtime_miri_jobs import digest
inputs=json.loads((ROOT/'target/loop-layer-final-stage10/native/execution-inputs.json').read_text())
for name,value in inputs.items(): assert digest(ROOT/name)==value,name
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
env=dict(os.environ,RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings',CARGO_TERM_COLOR='never')
env.pop('SHOOP_ALLOW_MISSING_BACKENDS',None)
assert not env.get('CARGO_TARGET_DIR') or Path(env['CARGO_TARGET_DIR']).resolve()==ROOT/'target'
old=ROOT/'target/rt-runtime-bench'
if old.exists():
    previous=ROOT/'target/loop-layer-final-stage10/previous-generic-benchmark'
    assert not previous.exists()
    shutil.move(str(old),str(previous))
records=[]; binaries={}
for label,command,report,example in [
 ('generic',['python3','scripts/benchmark_rt_runtime.py'],old,'bounded_runtime'),
 ('loop',['python3','scripts/benchmark_loop_engine.py','--report-dir',str(OUT/'loop')],OUT/'loop','benchmark_loop')]:
    record={'label':label,'command':command,'started_at':datetime.now(timezone.utc).isoformat()}
    start=time.monotonic()
    with (OUT/(label+'.stdout.log')).open('wb') as out,(OUT/(label+'.stderr.log')).open('wb') as err:
        result=subprocess.run(command,env=env,stdout=out,stderr=err,timeout=1800)
    record.update(exit_code=result.returncode,wall_seconds=time.monotonic()-start)
    if label=='generic' and report.exists(): shutil.copytree(report,OUT/'generic')
    records.append(record)
    (OUT/'progress.json').write_text(json.dumps(records,indent=2)+'\n')
    print(label,result.returncode,record['wall_seconds'],flush=True)
    if result.returncode: raise RuntimeError('benchmark failed; preserve '+label+' evidence')
    saved=OUT/label/'result.json'; data=json.loads(saved.read_text()); assert data['passed']
    record['report_sha256']=digest(saved)
    for profile in ['debug','release']:
        name='target/'+profile+'/examples/'+example
        binaries[name]=digest(ROOT/name)
for name,value in inputs.items(): assert digest(ROOT/name)==value,name
for name,value in binaries.items(): assert digest(ROOT/name)==value,name
proof={'status':'passed','source_commit':head,'unchanged_execution_inputs':len(inputs),'commands':records,'binary_sha256':binaries,'limits':'Existing 300s generic and 600s loop per-command watchdogs unchanged. Default full counts; timing/deadline misses descriptive. Isolated background Miri concurrent; no paired performance or cold/device/browser guarantee.'}
(OUT/'result.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof,indent=2))
