"""Recheck actual final gate content, raw timing, positive controls and unchanged source."""
import csv
import json
from pathlib import Path
import re
import sys
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));BASE=ROOT/'target/loop-layer-final-stage10'
from scripts import benchmark_loop_engine as loop_bench
from scripts.run_rt_runtime_miri_jobs import digest
inputs=json.loads((BASE/'native/execution-inputs.json').read_text())
for name,value in inputs.items():assert digest(ROOT/name)==value,name
hosts=json.loads((BASE/'hosts/result.json').read_text());assert hosts['status']=='passed' and len(hosts['records'])==8
contexts=0;failures=0;bindings=0;native_commands=0
matrix={'processor':(10,1,0,[0,0,0],None,None),'rust-heap':(4294901761,2,0,[4,20,4],None,None),'graph-processor':(10,1,0,[0,0,0],None,None),'graph-rust-heap':(4294901761,2,0,[1,5,1],None,None),'planner':(10,0,3,[0,0,0],1,0),'planner-rust-heap':(4294901761,0,4,[1,5,1],128,128)}
for record in hosts['records']:
 label=record['label'];folder=BASE/'hosts/reports'/label
 name='native-'+label.split('-')[1]+'-result.json' if label.startswith('rt_runtime-') and label.endswith('-native') else 'result.json'
 assert digest(folder/name)==record['report_sha256'] and record['exit_code']==0
 data=json.loads((folder/name).read_text());assert data['passed']
 if label.endswith('-native'):
  if label.startswith('loop_engine-'):
   assert set(data['native'])=={'primitive','graph','exports','staging','dense','stalls','media','planner'}
   logs=['native.json','native-planner.json','direct.log','wire.log','two-thread.log']+[f'native-{family}{suffix}.json' for family in ['graph','exports','staging','dense','stalls','media'] for suffix in ['', '-two-thread']]
   assert len(logs)==17 and all((folder/name).stat().st_size>0 for name in logs)
   native_commands+=len(logs)
  else:native_commands+=len(data['native'])
  continue
 if label.startswith('rt_runtime-'):
  assert len(data['reports'])==2 and len(data['failure_canaries'])==2
  for r in data['reports']:
   assert r['cross_origin_isolated'] is False and r['independent_instances'] is True
   assert r['bytes']==r['finalBytes']==1703936
  assert {r['mode'] for r in data['reports']}=={'offline','live'}
  for r in data['failure_canaries']:assert r['expected_failure_observed'] is True and r['exit_code']==1
  contexts+=2;failures+=2
 else:
  assert data['cross_origin_isolated'] is False and data['node']['passed'] is True
  assert len(data['node']['checks'])==len(data['bindingChecks']['checks'])==20
  bindings+=40
  for key in ['reports','graphReports','exportReports','stagingReports','denseReports','stallReports','mediaReports','plannerReports']:
   assert len(data[key])==2 and {r['mode'] for r in data[key]}=={'offline','live'},key
   contexts+=2
  assert len(data['failure_canaries'])==6
  for r in data['failure_canaries']:
   assert r['exit_code']==1;w=r['witness'];expected=matrix[r['kind']]
   assert (w['code'],w['processor'],w['planner'],w['heap'],w['plans'],w['finishes'])==expected
   assert w['bytes']==w['finalBytes'] and w['bytes']>0 and w['callbacks']=='1'
   failures+=1
assert contexts==36 and failures==16 and bindings==80 and native_commands==38
benchmarks=json.loads((BASE/'benchmarks/result.json').read_text());assert benchmarks['status']=='passed'
bench_summary={};native_controls=0
for record in benchmarks['commands']:
 label=record['label'];folder=BASE/'benchmarks'/label;assert digest(folder/'result.json')==record['report_sha256']
 data=json.loads((folder/'result.json').read_text());assert data['passed'] and len(data['trials'])==3
 iterations=20000 if label=='generic' else 4096;cases=7 if label=='generic' else 14
 for canary in data['canaries']:
  assert canary['exit_code']==101
  text=(folder/f"canary-{canary['profile']}-{canary['kind']}.log").read_text()
  expected={'allocation':(1,0,0),'reallocation':(0,7,0),'deallocation':(0,0,1)}[canary['kind']]
  found=re.search(r'left: Counts \{ allocations: (\d+), reallocations: (\d+), deallocations: (\d+) \}',text)
  assert found and tuple(map(int,found.groups()))==expected
  assert 'heap operation during rendering' in text;native_controls+=1
 all_records=[]
 for trial in data['trials']:
  assert len(trial['records'])==cases;raw=folder/f"trial-{trial['trial']}-raw"
  if label=='loop':loop_bench.verify_records((folder/f"trial-{trial['trial']}.log").read_text(),raw,iterations)
  for r in trial['records']:
   assert r['callbacks']==iterations and r['rust_heap_operations']==0
   with (raw/(r['case']+'.csv')).open() as f:rows=[{k:int(v) for k,v in row.items()} for row in csv.DictReader(f)]
   assert len(rows)==iterations and [v['callback'] for v in rows]==list(range(iterations))
   times=sorted(v['nanoseconds'] for v in rows)
   assert (r['p50_ns'],r['p99_ns'],r['p999_ns'],r['max_ns'])==(times[(iterations-1)*500//1000],times[(iterations-1)*990//1000],times[(iterations-1)*999//1000],times[-1])
   assert r['deadline_misses']==sum(t>r['deadline_ns'] for t in times)
   all_records.append(r)
 bench_summary[label]={'callbacks':sum(r['callbacks'] for r in all_records),'misses':sum(r['deadline_misses'] for r in all_records),'cascade_starts':sum(r.get('cascade_starts',0) for r in all_records),'cases':cases,'trials':3,'iterations':iterations}
assert native_controls==12
assert bench_summary['generic']['callbacks']==420000 and bench_summary['generic']['misses']==0
assert bench_summary['loop']['callbacks']==172032 and bench_summary['loop']['misses']==201 and bench_summary['loop']['cascade_starts']==49152
compile=json.loads((BASE/'application/compile-result.json').read_text());smoke=json.loads((BASE/'application/smoke-result.json').read_text())
assert compile['status']==smoke['status']=='passed' and len(compile['commands'])==4 and len(smoke['commands'])==7
assert all(c['exit_code']==0 for c in compile['commands']+smoke['commands'])
for label,needle in [('chrome-hosted-debug','hosted output-only audio passed'),('chrome-hosted-release','hosted output-only audio passed'),('chrome-single-file','direct-file output-only audio passed'),('firefox-hosted-release','Firefox AudioWorklet smoke passed:')]:
 assert needle in (BASE/'application'/(label+'.stdout.log')).read_text()
for name,value in inputs.items():assert digest(ROOT/name)==value,name
proof={'source_commit':hosts['source_commit'],'status':'passed','unchanged_execution_inputs':len(inputs),'host_top_level_commands':8,'native_only_subcommands':38,'actual_success_contexts':contexts,'actual_specific_failure_controls':failures,'node_chromium_binding_groups':bindings,'benchmark_campaigns':bench_summary,'native_exact_heap_controls':native_controls,'application_compiler_commands':4,'application_packaging_smoke_commands':7,'miri_or_remote_final_acceptance_claimed':False}
(BASE/'hosts-benchmarks-application-verification.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
