#!/usr/bin/env python3
import csv
import statistics
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
BASE = Path(r"C:\dev\compact-perf-results\baseline")
FINAL = Path(r"C:\dev\compact-perf-results\final")
SCENARIOS = ["idle", "play", "record", "grab"]
LABELS = ["Idle", "Playback", "Record", "Grab"]
BG, INK, MUTED, GRID = "#F6F8FB", "#17212B", "#5F6B76", "#D8DEE6"
BASE_COLOR, FINAL_COLOR = "#9AA6B2", "#16A085"

mpl.rcParams.update({
    "figure.facecolor": BG,
    "axes.facecolor": "white",
    "axes.edgecolor": GRID,
    "axes.labelcolor": INK,
    "axes.titlecolor": INK,
    "xtick.color": MUTED,
    "ytick.color": MUTED,
    "text.color": INK,
    "font.family": "DejaVu Sans",
    "font.size": 10,
    "axes.grid": True,
    "grid.color": GRID,
    "grid.alpha": 0.7,
    "axes.axisbelow": True,
    "savefig.facecolor": BG,
    "savefig.bbox": "tight",
})


def rows(path):
    with path.open(encoding="utf-8") as source:
        return list(csv.DictReader(source))


def aggregate(data, scenario, key):
    selected = [float(row[key]) for row in data if row["scenario"] == scenario]
    return statistics.median(selected)


def overruns(data, scenario):
    return sum(int(row["overruns"]) for row in data if row["scenario"] == scenario)


def main():
    q32_base = rows(BASE / "baseline-q32" / "summary.csv")
    q32_final = rows(FINAL / "final-q32" / "summary.csv")
    q256_base = rows(BASE / "baseline-q256" / "summary.csv")
    q256_final = rows(FINAL / "final-q256" / "summary.csv")
    fig, axes = plt.subplots(1, 3, figsize=(19, 7.8), gridspec_kw={"width_ratios": [1, 1, .85]})
    fig.subplots_adjust(left=.055, right=.98, top=.78, bottom=.14, wspace=.27)
    fig.suptitle("Compact optimization: matched Pi 4 dense workload", x=.055, y=.985,
                 ha="left", va="top", fontsize=22, fontweight="bold")
    fig.text(.055, .925, "8 tracks × 4 active loops; four matched repetitions. Lower is better; dashed lines are callback deadlines.",
             va="top", color=MUTED)
    x = np.arange(len(SCENARIOS))
    width = .36
    for ax, base, final, title, budget in [
        (axes[0], q32_base, q32_final, "Q=32 · p50", 666.667),
        (axes[1], q256_base, q256_final, "Q=256 · p50", 5333.333),
    ]:
        before = [aggregate(base, scenario, "p50_us") for scenario in SCENARIOS]
        after = [aggregate(final, scenario, "p50_us") for scenario in SCENARIOS]
        b1 = ax.bar(x - width / 2, before, width, color=BASE_COLOR, label="Baseline")
        b2 = ax.bar(x + width / 2, after, width, color=FINAL_COLOR, label="Optimized")
        ax.bar_label(b1, labels=[f"{value:,.0f}" for value in before], padding=3, fontsize=8)
        ax.bar_label(b2, labels=[f"{value:,.0f}" for value in after], padding=3, fontsize=8)
        ax.axhline(budget, color="#C0392B", linestyle="--", linewidth=1.4)
        ax.set_xticks(x, LABELS)
        ax.set_ylabel("Callback time (µs)")
        ax.set_title(title, loc="left", fontweight="bold")
        ax.spines[["top", "right"]].set_visible(False)
    axes[0].legend(loc="upper left")

    before = [overruns(q32_base, scenario) for scenario in SCENARIOS]
    after = [overruns(q32_final, scenario) for scenario in SCENARIOS]
    y = np.arange(len(SCENARIOS))
    axes[2].barh(y + .18, before, .34, color=BASE_COLOR, label="Baseline")
    axes[2].barh(y - .18, after, .34, color=FINAL_COLOR, label="Optimized")
    for yi, a, b in zip(y, before, after):
        axes[2].text(a + 6, yi + .18, str(a), va="center", fontsize=9)
        axes[2].text(b + 6, yi - .18, str(b), va="center", fontsize=9)
    axes[2].set_yticks(y, LABELS)
    axes[2].invert_yaxis()
    axes[2].set_xlabel("Overruns / 1,024 selected callbacks")
    axes[2].set_title("Q=32 · deadline overruns", loc="left", fontweight="bold")
    axes[2].spines[["top", "right"]].set_visible(False)
    axes[2].grid(axis="y", visible=False)
    axes[2].legend(loc="lower right")
    active_before = sum(before[1:])
    active_after = sum(after[1:])
    reduction = 100 * (1 - active_after / active_before)
    fig.text(.055, .055, f"Active-scenario overruns fell {active_before} → {active_after} (−{reduction:.1f}%); all 32 final runs had zero drops and render faults.", color=MUTED)
    fig.text(.99, .012, "Raspberry Pi 4 · PREEMPT_RT · CPU 1 SCHED_FIFO/80 · 48 kHz · final source 44241a05",
             ha="right", fontsize=8, color=MUTED)
    fig.savefig(ROOT / "09_compact_optimization.png", dpi=220)
    fig.savefig(ROOT / "09_compact_optimization.svg")


if __name__ == "__main__":
    main()
