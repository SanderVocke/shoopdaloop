#!/usr/bin/env python3
"""Create a visual report from pi4-fourth-results.zip."""
from __future__ import annotations

import argparse
import csv
import io
import json
import math
import statistics
import zipfile
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.ticker import FuncFormatter

MODES = ["current", "chunks", "chunks-descriptors", "compact"]
LABELS = {
    "current": "Current",
    "chunks": "Chunks",
    "chunks-descriptors": "Descriptors",
    "compact": "Compact",
}
COLORS = {
    "current": "#3977B7",
    "chunks": "#F28E2B",
    "chunks-descriptors": "#9C6ADE",
    "compact": "#16A085",
}
BG = "#F6F8FB"
INK = "#17212B"
MUTED = "#5F6B76"
GRID = "#D8DEE6"
ACCENT = "#0B7A75"

mpl.rcParams.update({
    "figure.facecolor": BG,
    "axes.facecolor": "white",
    "axes.edgecolor": GRID,
    "axes.labelcolor": INK,
    "axes.titlecolor": INK,
    "xtick.color": MUTED,
    "ytick.color": MUTED,
    "text.color": INK,
    "font.family": "DejaVu Sans",
    "font.size": 10,
    "axes.titleweight": "bold",
    "axes.titlesize": 13,
    "axes.grid": True,
    "grid.color": GRID,
    "grid.alpha": 0.7,
    "grid.linewidth": 0.8,
    "axes.axisbelow": True,
    "legend.frameon": False,
    "savefig.facecolor": BG,
    "savefig.bbox": "tight",
})


def read_csv(zf: zipfile.ZipFile, path: str) -> list[dict[str, str]]:
    text = zf.read(path).decode("utf-8")
    return list(csv.DictReader(io.StringIO(text)))


def median(rows: list[dict[str, str]], key: str) -> float:
    return statistics.median(float(r[key]) for r in rows)


def select(rows, scenario, mode, input_name=None):
    result = [r for r in rows if r["scenario"] == scenario and r["mode"] == mode]
    if input_name is not None:
        result = [r for r in result if r["input"] == input_name]
    return result


def aggregate(rows, scenario, mode, input_name=None):
    picked = select(rows, scenario, mode, input_name)
    return {
        "p50": median(picked, "p50_us"),
        "p95": median(picked, "p95_us"),
        "p99": median(picked, "p99_us"),
        "max": max(float(r["max_us"]) for r in picked),
        "late_max": max(float(r["late_max_us"]) for r in picked),
        "overruns": sum(int(r["overruns"]) for r in picked),
    }


def style_axis(ax, xgrid=False, ygrid=True):
    ax.grid(xgrid, axis="x")
    ax.grid(ygrid, axis="y")
    ax.spines[["top", "right"]].set_visible(False)


def mode_legend(ax, ncol=4, loc="upper center", bbox=(0.5, 1.14)):
    handles = [mpl.patches.Patch(color=COLORS[m], label=LABELS[m]) for m in MODES]
    ax.legend(handles=handles, ncol=ncol, loc=loc, bbox_to_anchor=bbox)


def grouped_bars(ax, categories, values, ylabel=None, budget=None, annotate=False):
    x = np.arange(len(categories))
    width = 0.19
    for i, mode in enumerate(MODES):
        ys = values[mode]
        bars = ax.bar(x + (i - 1.5) * width, ys, width * 0.92,
                      label=LABELS[mode], color=COLORS[mode], edgecolor="white", linewidth=0.5)
        if annotate:
            ax.bar_label(bars, labels=[f"{v:,.0f}" for v in ys], padding=2, fontsize=7,
                         color=MUTED, rotation=90)
    ax.set_xticks(x, categories)
    if ylabel:
        ax.set_ylabel(ylabel)
    if budget is not None:
        ax.axhline(budget, color="#C0392B", linewidth=1.5, linestyle="--",
                   label=f"Deadline {budget:,.0f} µs")
    style_axis(ax)
    return x


def fig_title(fig, title, subtitle):
    fig.suptitle(title, x=0.055, y=0.985, ha="left", fontsize=22, fontweight="bold", color=INK)
    fig.text(0.055, 0.946, subtitle, ha="left", va="top", fontsize=10.5, color=MUTED)


def add_footer(fig):
    fig.text(0.99, 0.012,
             "Raspberry Pi 4 · PREEMPT_RT · CPU 1 SCHED_FIFO/80 · 48 kHz · source cc954978",
             ha="right", va="bottom", fontsize=8, color=MUTED)


def save_figure(fig, out: Path, stem: str, pdf: PdfPages):
    fig.savefig(out / f"{stem}.png", dpi=220)
    fig.savefig(out / f"{stem}.svg")
    pdf.savefig(fig, bbox_inches="tight")
    plt.close(fig)


def dashboard(data, validation):
    t256, t32, mem, full = data["timing-256"], data["timing-32"], data["memory-256"], data["full-history"]
    workloads = [("256 idle", t256, "idle"), ("256 play", t256, "play"),
                 ("256 ramps", t256, "ramps"), ("32 idle", t32, "idle"),
                 ("32 play", t32, "play"), ("32 ramps", t32, "ramps")]
    fig = plt.figure(figsize=(18, 11))
    gs = fig.add_gridspec(2, 2, left=0.055, right=0.98, top=0.82, bottom=0.075,
                          hspace=0.38, wspace=0.22)
    fig_title(fig, "ShoopDaLoop Pi 4 benchmark — visual summary",
              "Compact leads every principal p50 and p99 comparison; all recorded callbacks stayed within deadline.")

    # KPI strip
    kpis = [
        (f"{validation['totals']['runs']}", "runs passed"),
        (f"{validation['totals']['selected_callbacks']:,}", "selected callbacks"),
        ("0", "overruns / drops / faults"),
        ("FIFO 80", "render thread on CPU 1"),
    ]
    for i, (big, small) in enumerate(kpis):
        x = 0.06 + i * 0.235
        fig.text(x, 0.875, big, fontsize=23, weight="bold", color=ACCENT)
        fig.text(x, 0.848, small, fontsize=10, color=MUTED)

    # Relative p50
    ax = fig.add_subplot(gs[0, 0])
    cats = [w[0] for w in workloads]
    vals = {m: [] for m in MODES}
    for _, rows, scenario in workloads:
        base = aggregate(rows, scenario, "current")["p50"]
        for mode in MODES:
            vals[mode].append(100 * aggregate(rows, scenario, mode)["p50"] / base)
    grouped_bars(ax, cats, vals, ylabel="p50 relative to Current (%)")
    ax.axhline(100, color=COLORS["current"], linewidth=1, linestyle=":")
    ax.set_ylim(0, 135)
    ax.set_title("Typical callback cost (lower is better)", loc="left")
    ax.legend(ncol=4, loc="upper right", fontsize=9)

    # Compact reductions
    ax = fig.add_subplot(gs[0, 1])
    labels = cats
    p50_gain, p99_gain = [], []
    for _, rows, scenario in workloads:
        c, k = aggregate(rows, scenario, "current"), aggregate(rows, scenario, "compact")
        p50_gain.append(100 * (1 - k["p50"] / c["p50"]))
        p99_gain.append(100 * (1 - k["p99"] / c["p99"]))
    y = np.arange(len(labels))
    ax.barh(y + 0.18, p50_gain, 0.34, color=COLORS["compact"], label="p50 reduction")
    ax.barh(y - 0.18, p99_gain, 0.34, color="#75C9B7", label="p99 reduction")
    for yi, a, b in zip(y, p50_gain, p99_gain):
        ax.text(a + 0.8, yi + 0.18, f"{a:.0f}%", va="center", fontsize=9)
        ax.text(b + 0.8, yi - 0.18, f"{b:.0f}%", va="center", fontsize=9)
    ax.set_yticks(y, labels)
    ax.invert_yaxis()
    ax.set_xlim(0, 60)
    ax.set_xlabel("Reduction versus Current (%)")
    ax.set_title("Compact improvement", loc="left")
    ax.legend(loc="lower right")
    style_axis(ax, xgrid=True, ygrid=False)

    # Stress comparison
    ax = fig.add_subplot(gs[1, 0])
    stress = [("Memory\npressure", mem, "play"), ("Full\nhistory", full, "shared")]
    x = np.arange(2)
    width = 0.19
    for i, mode in enumerate(MODES):
        ys = [aggregate(rows, scenario, mode)["p99"] for _, rows, scenario in stress]
        ax.bar(x + (i - 1.5) * width, ys, width * 0.92, color=COLORS[mode], label=LABELS[mode])
    ax.set_xticks(x, [s[0] for s in stress])
    ax.set_ylabel("p99 callback time (µs)")
    ax.set_title("Tail latency under harder conditions", loc="left")
    style_axis(ax)

    # Deadline headroom, worst observed callback per mode/matrix
    ax = fig.add_subplot(gs[1, 1])
    tests = [("Balanced\n256", t256, ["idle", "play", "ramps"], 5333.333),
             ("Balanced\n32", t32, ["idle", "play", "ramps"], 666.667),
             ("Memory\npressure", mem, ["play"], 5333.333),
             ("Full\nhistory", full, ["shared"], 5333.333)]
    vals = {m: [] for m in MODES}
    for _, rows, scenarios, budget in tests:
        for mode in MODES:
            mx = max(aggregate(rows, s, mode)["max"] for s in scenarios)
            vals[mode].append(100 * mx / budget)
    grouped_bars(ax, [t[0] for t in tests], vals, ylabel="Largest callback / deadline (%)")
    ax.axhline(100, color="#C0392B", linestyle="--", linewidth=1.5)
    ax.set_ylim(0, 105)
    ax.set_title("Observed deadline headroom", loc="left")
    add_footer(fig)
    return fig


def balanced_latency(data):
    fig, axs = plt.subplots(2, 2, figsize=(17, 11))
    fig.subplots_adjust(left=0.065, right=0.98, top=0.87, bottom=0.08, hspace=0.35, wspace=0.18)
    fig_title(fig, "Balanced callback latency",
              "Bars are medians of four run percentiles. Labels show µs; maxima and all outliers remain in the evidence archive.")
    for row, (name, budget) in enumerate([("timing-256", 5333.333), ("timing-32", 666.667)]):
        rows = data[name]
        for col, metric in enumerate(["p50", "p99"]):
            ax = axs[row, col]
            values = {m: [aggregate(rows, s, m)[metric] for s in ["idle", "play", "ramps"]] for m in MODES}
            grouped_bars(ax, ["Idle", "Play", "Ramps"], values, ylabel="Callback time (µs)", annotate=True)
            ax.set_title(f"{name.split('-')[1]} frames · {metric}", loc="left")
            ceiling = max(max(v) for v in values.values()) * 1.24
            ax.set_ylim(0, ceiling)
            if row == 0 and col == 0:
                mode_legend(ax)
            ax.text(0.99, 0.96, f"Deadline: {budget:,.0f} µs", transform=ax.transAxes,
                    ha="right", va="top", fontsize=9, color=MUTED)
    add_footer(fig)
    return fig


def speedup_heatmap(data):
    fig, axs = plt.subplots(1, 2, figsize=(16, 7))
    fig.subplots_adjust(left=0.13, right=0.95, top=0.82, bottom=0.16, wspace=0.3)
    fig_title(fig, "Compact latency reduction",
              "Percentage reduction in median run percentile; positive values favor Compact. All cells favor Compact.")
    workloads = [("256 · idle", data["timing-256"], "idle"),
                 ("256 · play", data["timing-256"], "play"),
                 ("256 · ramps", data["timing-256"], "ramps"),
                 ("32 · idle", data["timing-32"], "idle"),
                 ("32 · play", data["timing-32"], "play"),
                 ("32 · ramps", data["timing-32"], "ramps"),
                 ("Memory pressure", data["memory-256"], "play"),
                 ("Full history", data["full-history"], "shared")]
    cmap = LinearSegmentedColormap.from_list("gain", ["#E8F3F1", "#66BFB2", "#087F6F"])
    for ax, baseline in zip(axs, ["current", "chunks-descriptors"]):
        matrix = []
        for _, rows, scenario in workloads:
            b, k = aggregate(rows, scenario, baseline), aggregate(rows, scenario, "compact")
            matrix.append([100 * (1 - k["p50"] / b["p50"]), 100 * (1 - k["p99"] / b["p99"])])
        arr = np.array(matrix)
        im = ax.imshow(arr, cmap=cmap, vmin=0, vmax=65, aspect="auto")
        ax.set_xticks([0, 1], ["p50", "p99"])
        ax.set_yticks(np.arange(len(workloads)), [w[0] for w in workloads])
        ax.set_title(f"Versus {LABELS[baseline]}", loc="left")
        ax.grid(False)
        for i in range(arr.shape[0]):
            for j in range(arr.shape[1]):
                color = "white" if arr[i, j] > 38 else INK
                ax.text(j, i, f"{arr[i, j]:.0f}%", ha="center", va="center",
                        fontsize=11, fontweight="bold", color=color)
    cbar = fig.colorbar(im, ax=axs, location="bottom", fraction=0.06, pad=0.13, aspect=45)
    cbar.set_label("Latency reduction (%)")
    add_footer(fig)
    return fig


def stress_chart(data):
    fig, axs = plt.subplots(1, 2, figsize=(17, 7.5))
    fig.subplots_adjust(left=0.07, right=0.98, top=0.82, bottom=0.13, wspace=0.18)
    fig_title(fig, "Memory pressure and full-history latency",
              "Memory pressure continuously copied 64 MiB on CPU 2. Full history used a 31-second warmup.")
    for ax, (name, scenario, title) in zip(axs, [
        ("memory-256", "play", "Memory pressure · playback"),
        ("full-history", "shared", "Full 30-second history · shared grab"),
    ]):
        rows = data[name]
        x = np.arange(len(MODES))
        width = 0.25
        for i, metric in enumerate(["p50", "p99", "max"]):
            ys = [aggregate(rows, scenario, m)[metric] for m in MODES]
            shade = ["#78C6B7", "#2B9C89", "#146B60"][i]
            bars = ax.bar(x + (i - 1) * width, ys, width * 0.9, color=shade, label=metric)
            ax.bar_label(bars, labels=[f"{v:,.0f}" for v in ys], padding=2, fontsize=8, rotation=90)
        ax.set_xticks(x, [LABELS[m] for m in MODES])
        ax.set_ylabel("Callback time (µs)")
        ax.set_title(title, loc="left")
        ax.set_ylim(0, max(aggregate(rows, scenario, m)["max"] for m in MODES) * 1.24)
        ax.text(0.99, 0.96, "Deadline: 5,333 µs", transform=ax.transAxes,
                ha="right", va="top", fontsize=9, color=MUTED)
        style_axis(ax)
    axs[0].legend(ncol=3, loc="upper left")
    add_footer(fig)
    return fig


def workflow_chart(data):
    rows = data["looping"]
    scenarios = ["record", "record-play", "grab", "shared", "continue", "churn"]
    labels = ["Record*", "Record + play", "Grab", "Shared grab", "Continue", "Track churn"]
    fig, ax = plt.subplots(figsize=(15, 8.5))
    fig.subplots_adjust(left=0.14, right=0.98, top=0.82, bottom=0.11)
    fig_title(fig, "Looping workflow latency",
              "p50 callback time. *Record combines silent and signal-input runs; every workflow/state/readback check passed.")
    y = np.arange(len(scenarios))
    height = 0.18
    for i, mode in enumerate(MODES):
        vals = [aggregate(rows, s, mode)["p50"] for s in scenarios]
        bars = ax.barh(y + (i - 1.5) * height, vals, height * 0.92,
                       color=COLORS[mode], label=LABELS[mode])
        ax.bar_label(bars, labels=[f"{v:,.0f}" for v in vals], padding=3, fontsize=8, color=MUTED)
    ax.set_yticks(y, labels)
    ax.invert_yaxis()
    ax.set_xlabel("p50 callback time (µs)")
    ax.set_xlim(0, 1050)
    ax.set_title("Compact is lowest in every workflow", loc="left")
    ax.legend(ncol=4, loc="lower right")
    style_axis(ax, xgrid=True, ygrid=False)
    add_footer(fig)
    return fig


def headroom_chart(data):
    tests = [
        ("Balanced 256", "timing-256", ["idle", "play", "ramps"], 5333.333),
        ("Balanced 32", "timing-32", ["idle", "play", "ramps"], 666.667),
        ("Memory pressure", "memory-256", ["play"], 5333.333),
        ("Full history", "full-history", ["shared"], 5333.333),
        ("Workflows", "looping", ["record", "record-play", "grab", "shared", "continue", "churn"], 5333.333),
    ]
    fig, ax = plt.subplots(figsize=(16, 8))
    fig.subplots_adjust(left=0.08, right=0.98, top=0.82, bottom=0.14)
    fig_title(fig, "Deadline utilization from observed maxima",
              "Largest selected callback in each matrix, divided by its audio callback budget. This is observed headroom, not a WCET bound.")
    values = {m: [] for m in MODES}
    for _, name, scenarios, budget in tests:
        rows = data[name]
        for mode in MODES:
            mx = max(aggregate(rows, s, mode)["max"] for s in scenarios)
            values[mode].append(100 * mx / budget)
    grouped_bars(ax, [t[0] for t in tests], values, ylabel="Observed maximum / deadline (%)", annotate=True)
    ax.axhline(100, color="#C0392B", linestyle="--", linewidth=1.6, label="Deadline")
    ax.set_ylim(0, 105)
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:.0f}%"))
    ax.set_title("All maxima remained below the deadline", loc="left")
    mode_legend(ax)
    add_footer(fig)
    return fig


def architecture_chart(zf, data):
    rows = data["timing-256"]
    # Read one representative playback summary for counters/capacities per mode.
    summaries = {}
    for mode in MODES:
        candidates = [n for n in zf.namelist()
                      if n.startswith("results/timing-256/none/play-signal/")
                      and n.endswith(f"-{mode}/summary.json")]
        summaries[mode] = [json.loads(zf.read(n)) for n in candidates]

    copy_bytes = [statistics.median(s["counters"]["resource_copy_bytes"]["mean"] for s in summaries[m]) for m in MODES]
    steps = [statistics.median(s["counters"]["resource_steps"]["mean"] for s in summaries[m]) for m in MODES]
    reads = [statistics.median(s["counters"]["sample_reads"]["mean"] for s in summaries[m]) for m in MODES]
    metadata = []
    total_reserved = []
    for m in MODES:
        text = summaries[m][0]["memory"]
        fields = {}
        body = text.split("{", 1)[1].rsplit("}", 1)[0]
        for part in body.split(","):
            key, value = part.strip().split(": ", 1)
            try:
                fields[key] = int(value)
            except ValueError:
                pass
        metadata.append(fields["audio_metadata_bytes"] / 2**20)
        total_reserved.append(sum(fields[k] for k in ["ordinary_payload_bytes", "history_audio_bytes", "shared_audio_bytes", "audio_metadata_bytes"]) / 2**20)

    fig, axs = plt.subplots(1, 3, figsize=(18, 7.2))
    fig.subplots_adjust(left=0.065, right=0.98, top=0.8, bottom=0.16, wspace=0.28)
    fig_title(fig, "Why Compact is different: work and reservation tradeoffs",
              "Representative 256-frame playback. Counters are logical work—not measured DDR traffic; Current sample-read zero is uninstrumented.")
    x = np.arange(len(MODES))
    colors = [COLORS[m] for m in MODES]

    ax = axs[0]
    bars = ax.bar(x, copy_bytes, color=colors)
    ax.set_yscale("log")
    ax.set_xticks(x, [LABELS[m] for m in MODES], rotation=15)
    ax.set_ylabel("Logical bytes / callback (log scale)")
    ax.set_title("Resource copies", loc="left")
    ax.bar_label(bars, labels=[f"{v:,.0f}" for v in copy_bytes], padding=3, fontsize=8)
    style_axis(ax)

    ax = axs[1]
    width = 0.36
    b1 = ax.bar(x - width/2, steps, width, color="#E0A458", label="Resource steps")
    b2 = ax.bar(x + width/2, reads, width, color="#4C9FCE", label="Sample reads")
    ax.set_yscale("symlog", linthresh=1)
    ax.set_xticks(x, [LABELS[m] for m in MODES], rotation=15)
    ax.set_ylabel("Logical operations (symlog)")
    ax.set_title("Per-callback work", loc="left")
    ax.legend(loc="upper left")
    style_axis(ax)

    ax = axs[2]
    b1 = ax.bar(x, total_reserved, color=colors)
    b2 = ax.bar(x, metadata, color="#FFFFFF99", edgecolor=colors, linewidth=1.2, label="Audio metadata portion")
    ax.set_xticks(x, [LABELS[m] for m in MODES], rotation=15)
    ax.set_ylabel("Reserved capacity (MiB)")
    ax.set_title("Audio resource reservation", loc="left")
    ax.bar_label(b1, labels=[f"{v:.0f}" for v in total_reserved], padding=3, fontsize=8)
    ax.legend(loc="upper left")
    style_axis(ax)
    add_footer(fig)
    return fig


def dense_chart(rows, callback_frames):
    scenarios = ["idle", "play", "record", "grab"]
    scenario_labels = ["Idle", "Playback", "Record", "Grab"]
    run_callbacks = int(rows[0]["callbacks"])
    callbacks_per_cell = sum(int(r["callbacks"]) for r in select(rows, "idle", "current"))
    budget = callback_frames / 48_000 * 1_000_000
    worst = max(aggregate(rows, scenario, mode)["max"] for scenario in scenarios for mode in MODES)
    fig, axs = plt.subplots(1, 3, figsize=(19, 7.8), gridspec_kw={"width_ratios": [1, 1, 0.75]})
    fig.subplots_adjust(left=0.055, right=0.98, top=0.80, bottom=0.15, wspace=0.28)
    fig_title(
        fig,
        f"Dense workload: 8 tracks × 4 active loops · Q={callback_frames}",
        f"32 active stereo loops; 64 allocated grid cells + Sync. Two {run_callbacks}-callback runs per cell; "
        f"the dashed line is the {budget:,.0f} µs deadline.",
    )
    for ax, metric in zip(axs[:2], ["p50", "p99"]):
        values = {m: [aggregate(rows, s, m)[metric] for s in scenarios] for m in MODES}
        grouped_bars(ax, scenario_labels, values, ylabel="Callback time (µs)", budget=budget, annotate=True)
        ax.set_title(metric, loc="left")
        ax.set_ylim(0, worst * 1.18)
    mode_legend(axs[0], bbox=(1.08, 1.19))

    overruns = np.array([
        [aggregate(rows, scenario, mode)["overruns"] for mode in MODES]
        for scenario in scenarios
    ])
    im = axs[2].imshow(overruns / callbacks_per_cell * 100, cmap="Reds", vmin=0, vmax=100, aspect="auto")
    axs[2].set_xticks(np.arange(len(MODES)), [LABELS[m] for m in MODES], rotation=35, ha="right")
    axs[2].set_yticks(np.arange(len(scenarios)), scenario_labels)
    axs[2].set_title("Deadline overruns", loc="left")
    axs[2].grid(False)
    for i in range(len(scenarios)):
        for j in range(len(MODES)):
            count = overruns[i, j]
            axs[2].text(j, i, f"{count}/{callbacks_per_cell}", ha="center", va="center",
                        color="white" if count > callbacks_per_cell * 0.55 else INK, fontweight="bold")
    cbar = fig.colorbar(im, ax=axs[2], location="bottom", fraction=0.07, pad=0.20)
    cbar.set_label("Selected callbacks over deadline (%)")
    compact = [aggregate(rows, scenario, "compact")["overruns"] for scenario in scenarios]
    fig.text(0.055, 0.075,
             f"Compact overruns — idle {compact[0]}, playback {compact[1]}, record {compact[2]}, grab {compact[3]} "
             f"of {callbacks_per_cell} callbacks per cell; all modes had zero drops and render faults.",
             fontsize=10, color=MUTED)
    add_footer(fig)
    return fig


def write_html(out: Path, stems, dense_rows=None, dense_q32_rows=None):
    cards = "\n".join(
        f'<section><a href="{stem}.png"><img src="{stem}.png" alt="{stem}"></a>'
        f'<p><a href="{stem}.svg">Open scalable SVG</a></p></section>' for stem in stems
    )
    dense_detail = ""
    dense_q32_detail = ""
    subtitle = "PREEMPT_RT · 148 runs · 182,016 callbacks · zero overruns, drops, or faults"
    if dense_rows is not None:
        subtitle = ("Primary suite: 148 runs · 182,016 callbacks · zero overruns, drops, or faults · "
                    "Dense 8×4 follow-up: 32 runs · 2,048 callbacks")
        body = []
        for scenario in ["idle", "play", "record", "grab"]:
            for mode in MODES:
                a = aggregate(dense_rows, scenario, mode)
                body.append(
                    f"<tr><td>{scenario.title()}</td><td>{LABELS[mode]}</td>"
                    f"<td>{a['p50']:,.1f}</td><td>{a['p99']:,.1f}</td>"
                    f"<td>{a['max']:,.1f}</td><td>{a['overruns']}/128</td></tr>"
                )
        dense_detail = f"""<section class="detail"><h2>Dense 8 tracks × 4 active loops — measured results</h2>
<p><strong>Workload:</strong> eight stereo workload tracks with four active loops each (32 active voices).
The application grid allocates eight cells per track, so evidence contains 64 benchmark loop objects plus one Sync loop;
the unused 32 cells remain stopped. Idle allocates the same topology with no active loops.</p>
<p><strong>Method:</strong> Raspberry Pi 4 PREEMPT_RT, 48 kHz, 256-frame callback (5,333.3 µs deadline),
CPU 1 <code>SCHED_FIFO/80</code>, two repetitions, 64 selected callbacks (0.341 s) per run after 0.1 s warmup.
The engine was prepared for 9 tracks including Sync, 65 loop objects including Sync, and a 64 MiB ordinary loop-media arena.
Record used 32 simultaneous recordings. Grab used one settled four-loop transaction per track, then measured all 32 playing loops.</p>
<p><strong>Outcome:</strong> all 32 runs and state/media checks passed; 2,048 callbacks produced zero drops and zero render faults.
There were 1,188 deadline overruns. Compact met every playback and grab deadline and missed 3/128 record callbacks;
Current and both chunk variants exceeded the deadline throughout the active workloads.</p>
<div class="tablewrap"><table><thead><tr><th>Scenario</th><th>Mode</th><th>p50 µs</th><th>p99 µs</th><th>Max µs</th><th>Overruns</th></tr></thead>
<tbody>{''.join(body)}</tbody></table></div>
<p><a href="many-loops-8x4-results.tar.gz">Download raw dense-workload evidence</a>
(SHA-256 <code>94b1a898b3aee7ff3920bc7170e602e8e72bec580123be143020b7a1f175ecc7</code>) ·
<a href="many_loops_benchmark.rs">Adapted benchmark source</a>.</p>
<p class="note">This is a deliberately short saturation probe with two repetitions, not a WCET claim. Percentiles shown are medians of the two run percentiles.</p></section>"""
    if dense_q32_rows is not None:
        subtitle = ("Primary suite: 148 runs · 182,016 callbacks · zero overruns, drops, or faults · "
                    "Dense Q=256 and Q=32 follow-ups: 64 runs · 18,432 callbacks")
        body = []
        for scenario in ["idle", "play", "record", "grab"]:
            for mode in MODES:
                a = aggregate(dense_q32_rows, scenario, mode)
                body.append(
                    f"<tr><td>{scenario.title()}</td><td>{LABELS[mode]}</td>"
                    f"<td>{a['p50']:,.1f}</td><td>{a['p99']:,.1f}</td>"
                    f"<td>{a['max']:,.1f}</td><td>{a['overruns']}/1,024</td></tr>"
                )
        dense_q32_detail = f"""<section class="detail"><h2>Dense 8 tracks × 4 active loops — Q=32 results</h2>
<p><strong>Method:</strong> the same topology, media checks, four scenarios, four modes, two repetitions, CPU placement,
<code>SCHED_FIFO/80</code>, and 64 MiB loop-media arena as Q=256. The host callback and engine quantum were both 32 frames,
giving a 666.7 µs deadline. Each run selected 512 callbacks, preserving the same 0.341 s audio duration.</p>
<p><strong>Outcome:</strong> all 32 runs and state/media checks passed; 16,384 selected callbacks produced zero drops and zero render faults.
There were 11,486 deadline overruns. Compact was the only mode with useful headroom: it missed 1/1,024 idle,
176/1,024 playback, 491/1,024 record, and 103/1,024 grab callbacks.</p>
<div class="tablewrap"><table><thead><tr><th>Scenario</th><th>Mode</th><th>p50 µs</th><th>p99 µs</th><th>Max µs</th><th>Overruns</th></tr></thead>
<tbody>{''.join(body)}</tbody></table></div>
<p><a href="many-loops-8x4-q32-results.tar.gz">Download raw Q=32 dense-workload evidence</a>
(SHA-256 <code>ababe824aff3da47fd391bad6c11283c0db0118a4c51fa4b7928cfcf3123aa37</code>).</p>
<p class="note">This is a short saturation probe, not a WCET claim. Percentiles shown are medians of the two run percentiles.</p></section>"""
    html = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<title>ShoopDaLoop Pi 4 benchmark graphs</title><style>
body{{margin:0;background:{BG};color:{INK};font:16px system-ui,sans-serif}}main{{max-width:1500px;margin:auto;padding:32px}}
h1{{margin-bottom:4px}}h2{{margin:4px 8px 10px}}.sub,.note{{color:{MUTED}}}.sub{{margin-top:0}}section{{background:white;margin:28px 0;padding:14px;border-radius:12px;box-shadow:0 3px 14px #17212b12}}
img{{width:100%;height:auto;display:block}}a{{color:{ACCENT}}}p{{margin:10px 8px 2px}}code{{font-size:.88em;overflow-wrap:anywhere}}
.tablewrap{{overflow-x:auto;margin:16px 8px}}table{{width:100%;border-collapse:collapse;font-variant-numeric:tabular-nums}}th,td{{padding:8px 10px;border-bottom:1px solid {GRID};text-align:right}}th:first-child,td:first-child,th:nth-child(2),td:nth-child(2){{text-align:left}}thead{{background:{BG}}}
</style></head><body><main><h1>ShoopDaLoop Pi 4 benchmark graphs</h1>
<p class="sub">{subtitle}</p>{cards}{dense_detail}{dense_q32_detail}</main></body></html>"""
    (out / "index.html").write_text(html, encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("archive", type=Path)
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--dense-root", type=Path, help="Extracted many-loops-8x4 result directory")
    parser.add_argument("--dense-q32-root", type=Path, help="Extracted many-loops-8x4-q32 result directory")
    args = parser.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(args.archive) as zf:
        data = {name: read_csv(zf, f"results/{name}/summary.csv") for name in
                ["timing-256", "timing-32", "memory-256", "full-history", "looping", "smoke"]}
        validation = json.loads(zf.read("results/machine.json"))
        figures = [
            ("00_dashboard", dashboard(data, validation)),
            ("01_balanced_latency", balanced_latency(data)),
            ("02_compact_speedup", speedup_heatmap(data)),
            ("03_stress_and_history", stress_chart(data)),
            ("04_workflows", workflow_chart(data)),
            ("05_deadline_headroom", headroom_chart(data)),
            ("06_architecture_tradeoffs", architecture_chart(zf, data)),
        ]
        dense_rows = None
        dense_q32_rows = None
        if args.dense_root:
            dense_rows = list(csv.DictReader((args.dense_root / "summary.csv").open(encoding="utf-8")))
            figures.append(("07_dense_8x4", dense_chart(dense_rows, 256)))
        if args.dense_q32_root:
            dense_q32_rows = list(csv.DictReader((args.dense_q32_root / "summary.csv").open(encoding="utf-8")))
            figures.append(("08_dense_8x4_q32", dense_chart(dense_q32_rows, 32)))
        with PdfPages(out / "pi4-benchmark-visual-report.pdf") as pdf:
            for stem, fig in figures:
                save_figure(fig, out, stem, pdf)
    write_html(out, [stem for stem, _ in figures], dense_rows, dense_q32_rows)
    print(f"Wrote {len(figures)} charts, SVGs, HTML gallery, and PDF to {out}")


if __name__ == "__main__":
    main()
