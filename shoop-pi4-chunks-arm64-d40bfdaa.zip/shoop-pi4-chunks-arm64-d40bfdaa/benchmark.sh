#!/bin/sh
set -eu
bundle_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec python3 "$bundle_dir/scripts/benchmark_audio_chunks.py" --host "$bundle_dir/bin/shoop_host" --launcher "$bundle_dir/bin/chunk_benchmark" "$@"
